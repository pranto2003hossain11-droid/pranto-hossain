/**
 * Seed script — creates ONLY the minimum required admin account.
 * No products, categories, orders, or other demo data are seeded here
 * intentionally (per project spec). Products/categories/etc. are created
 * through the admin panel itself once it's wired to the database.
 *
 * Run with: npm run db:seed
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const email = process.env.SEED_ADMIN_EMAIL ?? "admin@basantiboutiques.com";
  const password = process.env.SEED_ADMIN_PASSWORD ?? "basanti@admin";
  const name = process.env.SEED_ADMIN_NAME ?? "Rahima Chowdhury";

  const passwordHash = await bcrypt.hash(password, 10);

  const admin = await prisma.admin.upsert({
    where: { email },
    update: {},
    create: {
      email,
      name,
      passwordHash,
      role: "OWNER",
    },
  });

  console.log(`Seeded admin account: ${admin.email}`);
  console.log(`Login with email "${email}" and the password from SEED_ADMIN_PASSWORD (or the default if unset).`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
