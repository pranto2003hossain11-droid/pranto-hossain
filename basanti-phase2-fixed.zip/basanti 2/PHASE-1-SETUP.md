# Phase 1 — Database & Schema Setup

Run these from inside `basanti 2/` (the project root, where `package.json` lives):

```bash
npm install
npx prisma migrate dev --name init
npm run db:seed
```

## What each command does

- `npm install` — installs the new dependencies added to `package.json`:
  `@prisma/client`, `prisma`, `bcryptjs`, `@types/bcryptjs`, `jose`, `tsx`.
- `npx prisma migrate dev --name init` — creates `prisma/dev.db` (SQLite file)
  and applies the schema in `prisma/schema.prisma`, generating the Prisma
  Client in the process.
- `npm run db:seed` — creates exactly one record: the admin account
  (`admin@basantiboutiques.com` / `basanti@admin` by default — see `.env`
  to change it before seeding). No products, orders, or other data are
  created; that all comes from real admin panel usage in later phases.

## How to verify it worked

```bash
npx prisma studio
```

This opens a local GUI at http://localhost:5555 — you should see all 13
tables (Admin, Product, Category, Collection, ProductCollection, Banner,
HomepageSection, Customer, Order, OrderItem, Coupon, Review, Media,
Setting) and exactly one row in `Admin`.

If `npm install` or `prisma migrate dev` throws an error, paste the exact
output back to me and I'll fix it before we move to Phase 2.

## What's NOT done yet (upcoming phases)

- No API routes yet — the app still reads from `src/lib/data.ts` /
  `src/lib/admin-data.ts` static arrays. Nothing is broken, but nothing is
  wired to the database yet either.
- No real admin authentication yet (still the Zustand demo-credential
  login).
- No image upload handling yet.
- No changes to any existing UI component.

## Schema summary (13 models)

| Model | Purpose |
|---|---|
| `Admin` | Admin panel login accounts (hashed passwords) |
| `Category` | Product categories, self-referencing for sub-categories |
| `Collection` / `ProductCollection` | Curated product groupings (e.g. homepage "Featured") |
| `Product` | Full catalog item; `images`/`sizes`/`colors`/`specifications` are JSON-encoded strings — always read/write via `src/lib/serializers.ts` |
| `Banner` | Hero slider slides |
| `HomepageSection` | On/off + order for each homepage section |
| `Customer` | Storefront customer accounts |
| `Order` / `OrderItem` | Orders and their line items |
| `Coupon` | Discount codes |
| `Review` | Product reviews, with admin moderation (`approved`) |
| `Media` | Uploaded file registry |
| `Setting` | Single-row store settings |

Every model has `createdAt`/`updatedAt` timestamps, proper foreign keys, and
indexes on the columns that will actually be queried (slugs, status,
category, etc.). Switching from SQLite to Postgres/MySQL later only requires
changing the `datasource` block in `schema.prisma` — no model changes.
