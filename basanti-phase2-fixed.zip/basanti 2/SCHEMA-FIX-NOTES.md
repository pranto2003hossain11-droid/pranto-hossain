# Schema Fix — Prisma Enums Are Not Supported on SQLite

## The bug

`prisma generate` failed on your machine with:

```
Error code: P1012
Prisma schema validation - The current connector does not support enums.
```

This was a real bug in `prisma/schema.prisma`, not an environment issue.
SQLite's Prisma connector genuinely does not support native `enum` blocks —
only Postgres, MySQL, and a few others do. The schema had six `enum` blocks
(`AdminRole`, `ProductStatus`, `ProductVisibility`, `OrderStatus`,
`CouponType`, `CustomerStatus`) used on a `sqlite` datasource, which is
invalid. My earlier verification couldn't catch this because it required
actually running `prisma generate`/`validate` against the real engine, which
needs network access I don't have in this sandbox — I flagged that
limitation at the time, and this is exactly the kind of issue it can let
through. Thank you for running it and reporting the exact error.

## The fix

- **`prisma/schema.prisma`** — removed all six `enum` blocks. Every field
  that referenced one (`Admin.role`, `Product.status`, `Product.visibility`,
  `Order.status`, `Coupon.type`, `Customer.status`) is now a plain `String`
  column with the same literal default (e.g. `status String @default("PUBLISHED")`).
  Each has a `///` doc-comment pointing to the canonical allowed values.
- **`src/lib/enums.ts`** (new) — the canonical list of allowed values for
  each of those six fields as TypeScript union types + `as const` arrays.
  This is now the single source of truth in application code (previously
  that was implicitly the Prisma-generated enum types, which no longer
  exist).
- **`src/lib/validators.ts`** — unaffected. Its Zod schemas already
  validated against literal string values (e.g. `z.enum(["PUBLISHED", "DRAFT"])`),
  not against Prisma's generated enum types, so write-path validation is
  unchanged and still strict.
- **`src/app/api/admin/orders/route.ts`** — the one file that imported the
  real `OrderStatus` type from `@prisma/client` (for a type cast on a query
  filter). Now imports the type from `@/lib/enums` instead.

Everywhere else in the codebase already treated these fields as plain
strings (the UI layer uses its own capitalized labels like `"Pending"` /
`"Cancelled"` via `src/lib/admin-mappers.ts`, converting to/from the
UPPERCASE DB values) — so this fix required touching only 3 files.

## Verification performed

Same disclosed limitation as before: I cannot run `npm install` or the real
`prisma` CLI in this sandbox (network is blocked), so I can't execute
`prisma generate`/`migrate dev` myself to give you a first-hand pass/fail.
What I could and did do:
- Manually re-read the entire corrected schema line by line for valid
  Prisma syntax (relations paired correctly, defaults valid for their
  column types, no leftover enum references).
- Grepped the entire `src` tree for any remaining reference to the removed
  Prisma-generated enum types — zero found, confirmed only one file needed
  a change.
- Re-ran the full TypeScript compiler and ESLint (borrowed toolchain, same
  method as before) against the whole project — **0 errors, 0 warnings**.

## What you need to run

```bash
npm install
npx prisma migrate dev --name init
npm run db:seed
npm run dev
```

If `prisma generate`/`migrate dev` still fails, please paste the exact error
again — I'll fix it the same way: real root-cause fix, not a workaround.
