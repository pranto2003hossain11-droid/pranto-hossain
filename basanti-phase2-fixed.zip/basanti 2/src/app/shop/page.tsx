import type { Metadata } from "next";
import { ShopPageClient } from "@/components/shop/shop-page-client";

export const metadata: Metadata = {
  title: "Shop All Products",
  description: "Browse the full Basanti Boutiques & House collection — sarees, fusion wear, accessories, and outerwear.",
};

export default function ShopPage({ searchParams }: { searchParams: { filter?: string } }) {
  return <ShopPageClient initialFilter={searchParams.filter} />;
}
