export default function Loading() {
  return (
    <div className="container-padded section-spacing space-y-6" aria-busy="true" aria-label="Loading page">
      <div className="skeleton h-8 w-1/3 rounded-sm" />
      <div className="skeleton h-4 w-2/3 rounded-sm" />
      <div className="skeleton h-4 w-1/2 rounded-sm" />
    </div>
  );
}
