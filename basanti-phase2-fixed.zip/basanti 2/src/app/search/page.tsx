"use client";

import { useEffect, useState } from "react";
import { Search as SearchIcon } from "lucide-react";
import type { Product } from "@/lib/types";
import { ProductCard } from "@/components/product/product-card";

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const trimmed = query.trim();
    if (!trimmed) {
      setResults([]);
      return;
    }

    setIsLoading(true);
    const timeout = setTimeout(() => {
      fetch(`/api/search?q=${encodeURIComponent(trimmed)}`)
        .then((res) => res.json())
        .then((data) => setResults(data.results ?? []))
        .catch(() => setResults([]))
        .finally(() => setIsLoading(false));
    }, 300); // debounce so every keystroke doesn't hit the database

    return () => clearTimeout(timeout);
  }, [query]);

  return (
    <div className="container-padded section-spacing">
      <div className="mx-auto max-w-xl">
        <div className="relative">
          <SearchIcon className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-charcoal-muted" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for sarees, kurtis, accessories..."
            className="w-full rounded-pill border border-beige-dark py-3.5 pl-12 pr-4 text-sm"
          />
        </div>
      </div>

      <div className="mt-10">
        {query.trim() === "" ? (
          <p className="text-center text-charcoal-muted">Start typing to search the catalog.</p>
        ) : isLoading ? (
          <p className="text-center text-charcoal-muted">Searching...</p>
        ) : results.length === 0 ? (
          <p className="text-center text-charcoal-muted">No results for &ldquo;{query}&rdquo;.</p>
        ) : (
          <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-4 lg:gap-x-6">
            {results.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
