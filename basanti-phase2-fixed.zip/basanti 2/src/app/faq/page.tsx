"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const faqs = [
  { q: "How long does delivery take?", a: "Delivery within Dhaka typically takes 1–2 business days. Outside Dhaka, expect 3–5 business days." },
  { q: "Do you offer Cash on Delivery?", a: "Yes, Cash on Delivery is available across Bangladesh, alongside bKash and card payments." },
  { q: "What is your return policy?", a: "We accept returns within 7 days of delivery for unused items in original packaging." },
  { q: "How do I track my order?", a: "Once your order ships, you'll receive a tracking link by SMS and email. You can also check status on the Order Tracking page." },
  { q: "Do you ship internationally?", a: "Currently we ship within Bangladesh only. International shipping is coming soon." },
];

export default function FAQPage() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="container-padded section-spacing">
      <div className="mx-auto max-w-2xl">
        <div className="mb-10 text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Help Center</p>
          <h1 className="mt-2 font-display text-display-sm md:text-display-md">Frequently Asked Questions</h1>
        </div>
        <div className="divide-y divide-beige-dark">
          {faqs.map((faq, i) => (
            <div key={faq.q}>
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center justify-between py-5 text-left"
                aria-expanded={open === i}
              >
                <span className="font-medium text-charcoal">{faq.q}</span>
                <ChevronDown className={cn("h-4 w-4 shrink-0 transition-transform", open === i && "rotate-180")} />
              </button>
              {open === i && <p className="pb-5 text-sm text-charcoal-light">{faq.a}</p>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
