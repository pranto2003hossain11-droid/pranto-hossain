import Image from "next/image";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About Us",
  description: "Learn about Basanti Boutiques & House and our commitment to craftsmanship.",
};

export default function AboutPage() {
  return (
    <div className="container-padded section-spacing">
      <div className="mx-auto max-w-2xl text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Our Story</p>
        <h1 className="mt-2 font-display text-display-sm md:text-display-md">
          Crafted with intention, worn with pride
        </h1>
        <p className="mt-5 text-charcoal-light">
          Basanti Boutiques &amp; House was founded with one purpose: to bring premium,
          thoughtfully made fashion to the modern Bangladeshi wardrobe, without losing the
          craftsmanship of traditional weaving and tailoring.
        </p>
      </div>

      <div id="story" className="mt-14 grid grid-cols-1 items-center gap-10 md:grid-cols-2">
        <div className="relative aspect-[4/5] overflow-hidden rounded-md">
          <Image
            src="https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=1000"
            alt="Artisan weaving fabric for Basanti Boutiques & House"
            fill
            sizes="(max-width: 768px) 100vw, 50vw"
            className="object-cover"
          />
        </div>
        <div>
          <h2 className="font-display text-display-sm">From Dhaka, for the world</h2>
          <p className="mt-4 text-charcoal-light">
            Every Basanti piece begins with a relationship — with the weavers of jamdani in
            Narayanganj, the tailors who hand-finish our blazers, and the embroiderers who
            spend days on a single shawl. We believe premium fashion shouldn&apos;t mean
            losing sight of who made it.
          </p>
          <p className="mt-4 text-charcoal-light">
            Today, Basanti serves customers across Bangladesh and abroad who want pieces that
            feel as good as they look — made to last, not to trend.
          </p>
        </div>
      </div>
    </div>
  );
}
