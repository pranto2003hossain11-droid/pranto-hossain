"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Link from "next/link";
import { useCartStore } from "@/store/cart-store";
import { formatPrice } from "@/lib/utils";
import { Button, buttonVariants } from "@/components/ui/button";
import { ShieldCheck, Truck } from "lucide-react";

const checkoutSchema = z.object({
  fullName: z.string().min(2, "Enter your full name"),
  phone: z.string().min(10, "Enter a valid phone number"),
  email: z.string().email("Enter a valid email").optional().or(z.literal("")),
  address: z.string().min(8, "Enter your full address"),
  city: z.string().min(2, "Enter your city"),
  paymentMethod: z.enum(["cod", "card", "bkash"]),
});

type CheckoutForm = z.infer<typeof checkoutSchema>;

export default function CheckoutPage() {
  const { items, subtotal, clearCart } = useCartStore();
  const shipping = subtotal() > 3000 ? 0 : 100;

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<CheckoutForm>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: { paymentMethod: "cod" },
  });

  const onSubmit = async (_data: CheckoutForm) => {
    await new Promise((r) => setTimeout(r, 800));
    clearCart();
    window.location.href = "/order-tracking";
  };

  if (items.length === 0) {
    return (
      <div className="container-padded section-spacing text-center">
        <h1 className="font-display text-display-sm">Your cart is empty</h1>
        <Link href="/shop" className={buttonVariants({ size: "lg", className: "mt-4" })}>
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="container-padded section-spacing">
      <h1 className="mb-8 font-display text-display-sm md:text-display-md">Checkout</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 gap-10 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <section>
            <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-charcoal">
              Shipping Information
            </h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="mb-1 block text-sm font-medium">Full Name</label>
                <input {...register("fullName")} className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm" />
                {errors.fullName && <p className="mt-1 text-xs text-maroon">{errors.fullName.message}</p>}
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium">Phone</label>
                <input {...register("phone")} className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm" />
                {errors.phone && <p className="mt-1 text-xs text-maroon">{errors.phone.message}</p>}
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium">Email (optional)</label>
                <input {...register("email")} className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm" />
                {errors.email && <p className="mt-1 text-xs text-maroon">{errors.email.message}</p>}
              </div>
              <div className="sm:col-span-2">
                <label className="mb-1 block text-sm font-medium">Address</label>
                <input {...register("address")} className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm" />
                {errors.address && <p className="mt-1 text-xs text-maroon">{errors.address.message}</p>}
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium">City</label>
                <input {...register("city")} className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm" />
                {errors.city && <p className="mt-1 text-xs text-maroon">{errors.city.message}</p>}
              </div>
            </div>
          </section>

          <section>
            <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-charcoal">Payment Method</h2>
            <div className="space-y-2">
              {[
                { value: "cod", label: "Cash on Delivery" },
                { value: "bkash", label: "bKash" },
                { value: "card", label: "Credit / Debit Card" },
              ].map((opt) => (
                <label key={opt.value} className="flex items-center gap-3 rounded border border-beige-dark px-4 py-3 text-sm">
                  <input type="radio" value={opt.value} {...register("paymentMethod")} className="h-4 w-4 text-maroon" />
                  {opt.label}
                </label>
              ))}
            </div>
          </section>
        </div>

        <div className="h-fit rounded-md bg-beige p-6">
          <h2 className="mb-4 font-display text-lg font-semibold">Order Summary</h2>
          <ul className="mb-4 space-y-2 text-sm text-charcoal-light">
            {items.map((item) => (
              <li key={`${item.product.id}-${item.size ?? "default"}`} className="flex justify-between">
                <span className="line-clamp-1 pr-2">
                  {item.product.name}
                  {item.size ? ` (${item.size})` : ""} × {item.quantity}
                </span>
                <span>{formatPrice(item.product.price * item.quantity)}</span>
              </li>
            ))}
          </ul>
          <div className="space-y-2 border-t border-beige-dark pt-4 text-sm text-charcoal-light">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>{formatPrice(subtotal())}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span>{shipping === 0 ? "Free" : formatPrice(shipping)}</span>
            </div>
          </div>
          <div className="mt-3 flex justify-between border-t border-beige-dark pt-3 font-semibold">
            <span>Total</span>
            <span className="text-maroon">{formatPrice(subtotal() + shipping)}</span>
          </div>
          <Button type="submit" size="lg" isLoading={isSubmitting} className="mt-6 w-full">
            Place Order
          </Button>
          <div className="mt-4 space-y-2 text-xs text-charcoal-muted">
            <p className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-maroon" /> Secure checkout</p>
            <p className="flex items-center gap-2"><Truck className="h-4 w-4 text-maroon" /> Delivery in 2–5 business days</p>
          </div>
        </div>
      </form>
    </div>
  );
}
