"use client";
import Image from "next/image";
import Link from "next/link";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useCartStore } from "@/store/cart-store";
import { formatPrice } from "@/lib/utils";
import { Button, buttonVariants } from "@/components/ui/button";

export default function CartPage() {
  const { items, removeItem, updateQuantity, subtotal } = useCartStore();

  if (items.length === 0) {
    return (
      <div className="container-padded section-spacing flex flex-col items-center gap-4 text-center">
        <ShoppingBag className="h-12 w-12 text-charcoal-muted" />
        <h1 className="font-display text-display-sm">Your cart is empty</h1>
        <p className="text-charcoal-light">Looks like you haven&apos;t added anything yet.</p>
        <Link href="/shop" className={buttonVariants({ size: "lg" })}>
          Start Shopping
        </Link>
      </div>
    );
  }

  const shipping = subtotal() > 3000 ? 0 : 100;

  return (
    <div className="container-padded section-spacing">
      <h1 className="mb-8 font-display text-display-sm md:text-display-md">Your Cart</h1>
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          {items.map((item) => (
            <div key={`${item.product.id}-${item.size ?? "default"}`} className="flex gap-4 border-b border-beige-dark pb-6">
              <div className="relative h-28 w-24 shrink-0 overflow-hidden rounded-sm bg-beige">
                <Image src={item.product.image} alt={item.product.name} fill sizes="96px" className="object-cover" />
              </div>
              <div className="flex flex-1 flex-col justify-between">
                <div className="flex justify-between gap-3">
                  <div>
                    <Link href={`/product/${item.product.slug}`} className="font-medium hover:text-maroon">
                      {item.product.name}
                    </Link>
                    {item.size && <p className="text-xs text-charcoal-muted">Size: {item.size}</p>}
                  </div>
                  <button onClick={() => removeItem(item.product.id, item.size)} aria-label="Remove item">
                    <Trash2 className="h-4 w-4 text-charcoal-muted hover:text-maroon" />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 rounded-pill border border-beige-dark px-3 py-1.5">
                    <button aria-label="Decrease quantity" onClick={() => updateQuantity(item.product.id, item.quantity - 1, item.size)}>
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="w-5 text-center text-sm">{item.quantity}</span>
                    <button aria-label="Increase quantity" onClick={() => updateQuantity(item.product.id, item.quantity + 1, item.size)}>
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                  <span className="font-semibold text-maroon">{formatPrice(item.product.price * item.quantity)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="h-fit rounded-md bg-beige p-6">
          <h2 className="mb-4 font-display text-lg font-semibold">Order Summary</h2>
          <div className="space-y-2 text-sm text-charcoal-light">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>{formatPrice(subtotal())}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span>{shipping === 0 ? "Free" : formatPrice(shipping)}</span>
            </div>
          </div>
          <div className="mt-4 flex justify-between border-t border-beige-dark pt-4 font-semibold text-charcoal">
            <span>Total</span>
            <span className="text-maroon">{formatPrice(subtotal() + shipping)}</span>
          </div>
          <Link href="/checkout" className={buttonVariants({ size: "lg", className: "mt-6 w-full" })}>
            Proceed to Checkout
          </Link>
          <div className="mt-3 flex items-center gap-2">
            <input type="text" placeholder="Coupon code" className="w-full rounded border border-beige-dark bg-white px-3 py-2.5 text-sm" />
            <Button variant="outline" size="md">Apply</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
