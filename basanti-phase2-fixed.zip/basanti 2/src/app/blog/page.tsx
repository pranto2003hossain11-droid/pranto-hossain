import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import { blogPosts } from "@/lib/blog-data";

export const metadata: Metadata = { title: "Blog" };

export default function BlogPage() {
  return (
    <div className="container-padded section-spacing">
      <div className="mb-10 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Journal</p>
        <h1 className="mt-2 font-display text-display-sm md:text-display-md">The Basanti Edit</h1>
      </div>
      <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
        {blogPosts.map((post) => (
          <Link key={post.slug} href={`/blog/${post.slug}`} className="group block">
            <div className="relative aspect-[4/3] overflow-hidden rounded-md">
              <Image
                src={post.image}
                alt={post.title}
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
            </div>
            <p className="mt-4 text-xs uppercase tracking-wider text-charcoal-muted">
              {new Date(post.date).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
            </p>
            <h2 className="mt-1 font-display text-lg font-semibold group-hover:text-maroon">{post.title}</h2>
            <p className="mt-2 text-sm text-charcoal-light">{post.excerpt}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
