import Image from "next/image";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { blogPosts, getPostBySlug } from "@/lib/blog-data";

export function generateStaticParams() {
  return blogPosts.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const post = getPostBySlug(params.slug);
  return { title: post?.title ?? "Article", description: post?.excerpt };
}

export default function ArticlePage({ params }: { params: { slug: string } }) {
  const post = getPostBySlug(params.slug);
  if (!post) notFound();

  return (
    <article className="container-padded section-spacing mx-auto max-w-2xl">
      <p className="text-xs uppercase tracking-wider text-charcoal-muted">
        {new Date(post.date).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })} · {post.author}
      </p>
      <h1 className="mt-2 font-display text-display-sm md:text-display-md">{post.title}</h1>
      <div className="relative mt-6 aspect-[16/9] overflow-hidden rounded-md">
        <Image src={post.image} alt={post.title} fill sizes="(max-width: 768px) 100vw, 700px" className="object-cover" />
      </div>
      <div className="mt-8 space-y-4 text-charcoal-light">
        {post.content.map((p, i) => (
          <p key={i}>{p}</p>
        ))}
      </div>
    </article>
  );
}
