import type { MetadataRoute } from "next";
import { prisma } from "@/lib/prisma";
import { blogPosts } from "@/lib/blog-data";

const siteUrl = "https://www.basantiboutiques.com";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const staticRoutes = [
    "",
    "/shop",
    "/collection",
    "/about",
    "/contact",
    "/faq",
  ].map((route) => ({
    url: `${siteUrl}${route}`,
    lastModified: new Date(),
  }));

  // Cart, wishlist, login, register, checkout, and account are user-specific
  // and already disallowed in robots.txt — they shouldn't be listed here.
  const [categories, products, collections] = await Promise.all([
    prisma.category.findMany({ where: { visible: true }, select: { slug: true, updatedAt: true } }),
    prisma.product.findMany({
      where: { status: "PUBLISHED", visibility: "VISIBLE" },
      select: { slug: true, updatedAt: true },
    }),
    prisma.collection.findMany({ where: { visible: true }, select: { slug: true, updatedAt: true } }),
  ]);

  const categoryRoutes = categories.map((c: { slug: string; updatedAt: Date }) => ({
    url: `${siteUrl}/category/${c.slug}`,
    lastModified: c.updatedAt,
  }));

  const productRoutes = products.map((p: { slug: string; updatedAt: Date }) => ({
    url: `${siteUrl}/product/${p.slug}`,
    lastModified: p.updatedAt,
  }));

  const collectionRoutes = collections.map((c: { slug: string; updatedAt: Date }) => ({
    url: `${siteUrl}/collection/${c.slug}`,
    lastModified: c.updatedAt,
  }));

  const blogRoutes = blogPosts.map((p) => ({
    url: `${siteUrl}/blog/${p.slug}`,
    lastModified: new Date(p.date),
  }));

  return [...staticRoutes, ...categoryRoutes, ...productRoutes, ...collectionRoutes, ...blogRoutes];
}
