import type { Metadata } from "next";
import Link from "next/link";
import { Package, Heart, MapPin, LogOut, User } from "lucide-react";

export const metadata: Metadata = { title: "My Account" };

const menu = [
  { label: "Order History", href: "/order-tracking", icon: Package },
  { label: "Wishlist", href: "/wishlist", icon: Heart },
  { label: "Saved Addresses", href: "/account", icon: MapPin },
  { label: "Profile Details", href: "/account", icon: User },
];

export default function AccountPage() {
  return (
    <div className="container-padded section-spacing">
      <h1 className="mb-8 font-display text-display-sm md:text-display-md">My Account</h1>
      <div className="grid grid-cols-1 gap-10 md:grid-cols-[240px_1fr]">
        <nav className="space-y-1">
          {menu.map(({ label, href, icon: Icon }) => (
            <Link key={label} href={href} className="flex items-center gap-3 rounded px-3 py-2.5 text-sm text-charcoal-light hover:bg-beige">
              <Icon className="h-4 w-4 text-maroon" /> {label}
            </Link>
          ))}
          <button className="flex w-full items-center gap-3 rounded px-3 py-2.5 text-sm text-maroon hover:bg-beige">
            <LogOut className="h-4 w-4" /> Logout
          </button>
        </nav>
        <div className="rounded-md bg-beige p-6">
          <h2 className="mb-2 font-display text-lg font-semibold">Welcome back</h2>
          <p className="text-sm text-charcoal-light">
            Manage your orders, saved addresses, and wishlist from this dashboard.
          </p>
        </div>
      </div>
    </div>
  );
}
