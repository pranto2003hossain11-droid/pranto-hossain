import type { Metadata } from "next";
import { Playfair_Display, Poppins } from "next/font/google";
import "./globals.css";
import { RouteChrome } from "@/components/layout/route-chrome";
import { StoreHydration } from "@/components/store-hydration";

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
  weight: ["500", "600", "700"],
});

const poppins = Poppins({
  subsets: ["latin"],
  variable: "--font-poppins",
  display: "swap",
  weight: ["300", "400", "500", "600", "700"],
});

const siteUrl = "https://www.basantiboutiques.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Basanti Boutiques & House | Premium Fashion, Crafted in Bangladesh",
    template: "%s | Basanti Boutiques & House",
  },
  description:
    "Discover Basanti Boutiques & House — premium fashion for the modern Bangladeshi wardrobe. Sarees, fusion wear, and curated collections crafted with elegance.",
  keywords: ["Basanti Boutiques", "Bangladeshi fashion", "premium saree", "boutique fashion Dhaka"],
  openGraph: {
    type: "website",
    locale: "en_BD",
    url: siteUrl,
    siteName: "Basanti Boutiques & House",
    title: "Basanti Boutiques & House | Premium Fashion",
    description: "Premium fashion for the modern Bangladeshi wardrobe.",
  },
  twitter: {
    card: "summary_large_image",
    title: "Basanti Boutiques & House",
    description: "Premium fashion for the modern Bangladeshi wardrobe.",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${playfair.variable} ${poppins.variable}`}>
      <body className="flex min-h-screen flex-col">
        <StoreHydration />
        <RouteChrome>{children}</RouteChrome>
      </body>
    </html>
  );
}
