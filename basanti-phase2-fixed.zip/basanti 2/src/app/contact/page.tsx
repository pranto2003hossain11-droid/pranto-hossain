import type { Metadata } from "next";
import { Mail, MapPin, Phone } from "lucide-react";
import { ContactForm } from "@/components/contact-form";

export const metadata: Metadata = { title: "Contact Us" };

export default function ContactPage() {
  return (
    <div className="container-padded section-spacing">
      <div className="mb-10 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Get In Touch</p>
        <h1 className="mt-2 font-display text-display-sm md:text-display-md">Contact Us</h1>
      </div>
      <div className="grid grid-cols-1 gap-10 md:grid-cols-2">
        <ContactForm />

        <div className="space-y-6">
          <div className="flex items-start gap-3">
            <MapPin className="mt-1 h-5 w-5 text-maroon" />
            <div>
              <p className="font-medium">Boutique Location</p>
              <p className="text-sm text-charcoal-light">Gulshan Avenue, Dhaka, Bangladesh</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Phone className="mt-1 h-5 w-5 text-maroon" />
            <div>
              <p className="font-medium">Phone</p>
              <p className="text-sm text-charcoal-light">+880 1XXX-XXXXXX</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Mail className="mt-1 h-5 w-5 text-maroon" />
            <div>
              <p className="font-medium">Email</p>
              <p className="text-sm text-charcoal-light">hello@basantiboutiques.com</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
