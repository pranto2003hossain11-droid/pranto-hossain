import Link from "next/link";
import type { Metadata } from "next";
import { LoginForm } from "@/components/auth/login-form";

export const metadata: Metadata = { title: "Login" };

export default function LoginPage() {
  return (
    <div className="container-padded section-spacing flex justify-center">
      <div className="w-full max-w-sm">
        <h1 className="mb-2 text-center font-display text-display-sm">Welcome Back</h1>
        <p className="mb-8 text-center text-sm text-charcoal-muted">Login to your Basanti account</p>
        <LoginForm />
        <p className="mt-6 text-center text-sm text-charcoal-light">
          Don&apos;t have an account?{" "}
          <Link href="/register" className="font-medium text-maroon hover:underline">Sign up</Link>
        </p>
      </div>
    </div>
  );
}
