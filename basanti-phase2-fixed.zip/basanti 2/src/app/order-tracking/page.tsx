"use client";

import { useState } from "react";
import { Package, CheckCircle2, Truck, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const steps = [
  { label: "Order Confirmed", icon: CheckCircle2 },
  { label: "Processing", icon: Package },
  { label: "Out for Delivery", icon: Truck },
  { label: "Delivered", icon: Home },
];

export default function OrderTrackingPage() {
  const [tracked, setTracked] = useState(false);
  const currentStep = 1;

  return (
    <div className="container-padded section-spacing">
      <div className="mx-auto max-w-xl text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Order Status</p>
        <h1 className="mt-2 font-display text-display-sm md:text-display-md">Track Your Order</h1>
        <form
          className="mx-auto mt-8 flex max-w-sm gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            setTracked(true);
          }}
        >
          <input
            required
            placeholder="Order ID (e.g. BB-10234)"
            className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm"
          />
          <Button type="submit" size="md">Track</Button>
        </form>
      </div>

      {tracked && (
        <div className="mx-auto mt-14 max-w-2xl">
          <div className="flex items-center justify-between">
            {steps.map((step, i) => (
              <div key={step.label} className="relative flex flex-1 flex-col items-center text-center">
                <div
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-full",
                    i <= currentStep ? "bg-maroon text-ivory" : "bg-beige text-charcoal-muted"
                  )}
                >
                  <step.icon className="h-5 w-5" />
                </div>
                <p className="mt-2 text-xs font-medium">{step.label}</p>
                {i < steps.length - 1 && (
                  <div className={cn("absolute left-1/2 top-5 h-0.5 w-full", i < currentStep ? "bg-maroon" : "bg-beige-dark")} />
                )}
              </div>
            ))}
          </div>
          <div className="mt-12 rounded-md bg-beige p-6 text-sm text-charcoal-light">
            <p className="font-medium text-charcoal">Order BB-10234</p>
            <p className="mt-1">Your order is being processed and will be packed within 24 hours.</p>
            <p className="mt-1">Estimated delivery: 3–5 business days.</p>
          </div>
        </div>
      )}
    </div>
  );
}
