import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { reviewUpdateSchema } from "@/lib/validators";
import { recalculateProductRating } from "@/lib/reviews";
import { ok, notFound, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ id: string }>;
}

export async function PUT(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    const data = reviewUpdateSchema.parse(body);

    const review = await prisma.review.update({ where: { id }, data });
    await recalculateProductRating(review.productId);

    return ok({ review });
  } catch (error) {
    return handleApiError(error);
  }
}

export const PATCH = PUT;

export async function DELETE(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const review = await prisma.review.findUnique({ where: { id } });
    if (!review) return notFound("Review not found.");

    await prisma.review.delete({ where: { id } });
    await recalculateProductRating(review.productId);

    return ok({ success: true });
  } catch (error) {
    return handleApiError(error);
  }
}
