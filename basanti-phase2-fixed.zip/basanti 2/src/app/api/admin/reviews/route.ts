import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ok, handleApiError } from "@/lib/api-response";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const approved = searchParams.get("approved");

    const reviews = await prisma.review.findMany({
      where: approved !== null ? { approved: approved === "true" } : undefined,
      include: { product: { select: { name: true, slug: true, image: true } } },
      orderBy: { createdAt: "desc" },
    });

    return ok({ reviews });
  } catch (error) {
    return handleApiError(error);
  }
}
