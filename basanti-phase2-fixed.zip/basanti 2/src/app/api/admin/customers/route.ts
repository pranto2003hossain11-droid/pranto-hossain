import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword } from "@/lib/auth";
import { serializePublicCustomer } from "@/lib/serializers";
import { customerCreateSchema } from "@/lib/validators";
import { ok, created, handleApiError } from "@/lib/api-response";
import { Prisma } from "@prisma/client";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search")?.trim();
    const status = searchParams.get("status");

    const where: Prisma.CustomerWhereInput = {
      ...(search
        ? {
            OR: [
              { name: { contains: search } },
              { email: { contains: search } },
              { phone: { contains: search } },
            ],
          }
        : {}),
      ...(status ? { status: status as "ACTIVE" | "INACTIVE" } : {}),
    };

    const customers = await prisma.customer.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: {
        _count: { select: { orders: true } },
        orders: {
          where: { status: { notIn: ["CANCELLED", "REFUNDED"] } },
          select: { total: true },
        },
      },
    });

    return ok({
      customers: customers.map((customer: (typeof customers)[number]) => ({
        ...serializePublicCustomer(customer),
        totalSpent: customer.orders.reduce((sum: number, o: { total: number }) => sum + o.total, 0),
      })),
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { password, ...data } = customerCreateSchema.parse(body);

    const customer = await prisma.customer.create({
      data: {
        ...data,
        ...(password ? { passwordHash: await hashPassword(password) } : {}),
      },
    });

    return created({ customer: serializePublicCustomer(customer) });
  } catch (error) {
    return handleApiError(error);
  }
}
