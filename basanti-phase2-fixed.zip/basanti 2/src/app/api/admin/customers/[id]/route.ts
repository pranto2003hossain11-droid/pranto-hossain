import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { serializePublicCustomer } from "@/lib/serializers";
import { customerUpdateSchema } from "@/lib/validators";
import { ok, notFound, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ id: string }>;
}

export async function GET(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const customer = await prisma.customer.findUnique({
      where: { id },
      include: {
        _count: { select: { orders: true } },
        orders: { orderBy: { createdAt: "desc" }, take: 10 },
      },
    });
    if (!customer) return notFound("Customer not found.");
    return ok({
      customer: { ...serializePublicCustomer(customer), recentOrders: customer.orders },
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    const data = customerUpdateSchema.parse(body);
    const customer = await prisma.customer.update({ where: { id }, data });
    return ok({ customer: serializePublicCustomer(customer) });
  } catch (error) {
    return handleApiError(error);
  }
}

export const PATCH = PUT;

export async function DELETE(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    await prisma.customer.delete({ where: { id } });
    return ok({ success: true });
  } catch (error) {
    return handleApiError(error);
  }
}
