import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { orderStatusUpdateSchema } from "@/lib/validators";
import { ok, notFound, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ id: string }>;
}

export async function GET(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const order = await prisma.order.findUnique({
      where: { id },
      include: { items: true, customer: true },
    });
    if (!order) return notFound("Order not found.");
    return ok({ order });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PATCH(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { status } = orderStatusUpdateSchema.parse(body);

    const previous = await prisma.order.findUnique({ where: { id }, select: { status: true } });
    if (!previous) return notFound("Order not found.");
    const wasAlreadyReleased = previous.status === "CANCELLED" || previous.status === "REFUNDED";

    const order = await prisma.order.update({
      where: { id },
      data: { status },
      include: { items: true },
    });

    // Restock items only on the transition INTO cancelled/refunded, so
    // repeated status updates never double-restock the same order.
    const isNowReleased = status === "CANCELLED" || status === "REFUNDED";
    if (isNowReleased && !wasAlreadyReleased) {
      await prisma.$transaction(
        order.items
          .filter((item: { productId: string | null }) => item.productId)
          .map((item: { productId: string | null; quantity: number }) =>
            prisma.product.update({
              where: { id: item.productId! },
              data: { stock: { increment: item.quantity } },
            })
          )
      );
    }

    return ok({ order });
  } catch (error) {
    return handleApiError(error);
  }
}
