import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { couponCreateSchema } from "@/lib/validators";
import { ok, created, handleApiError } from "@/lib/api-response";

export async function GET() {
  try {
    const coupons = await prisma.coupon.findMany({ orderBy: { createdAt: "desc" } });
    return ok({ coupons });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const data = couponCreateSchema.parse(body);
    const coupon = await prisma.coupon.create({
      data: {
        ...data,
        expiryDate: data.expiryDate ? new Date(data.expiryDate) : null,
      },
    });
    return created({ coupon });
  } catch (error) {
    return handleApiError(error);
  }
}
