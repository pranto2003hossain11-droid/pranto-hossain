import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { couponUpdateSchema } from "@/lib/validators";
import { ok, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ id: string }>;
}

export async function PUT(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    const data = couponUpdateSchema.parse(body);
    const coupon = await prisma.coupon.update({
      where: { id },
      data: {
        ...data,
        ...(data.expiryDate !== undefined
          ? { expiryDate: data.expiryDate ? new Date(data.expiryDate) : null }
          : {}),
      },
    });
    return ok({ coupon });
  } catch (error) {
    return handleApiError(error);
  }
}

export const PATCH = PUT;

export async function DELETE(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    await prisma.coupon.delete({ where: { id } });
    return ok({ success: true });
  } catch (error) {
    return handleApiError(error);
  }
}
