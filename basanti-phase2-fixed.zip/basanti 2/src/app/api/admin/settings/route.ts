import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { settingUpdateSchema } from "@/lib/validators";
import { ok, handleApiError } from "@/lib/api-response";

const SETTING_ID = "singleton";

const DEFAULT_SETTINGS = {
  id: SETTING_ID,
  storeName: "Basanti Boutiques & House",
  phone: "+880 1XXX-XXXXXX",
  email: "hello@basantiboutiques.com",
  address: "Dhaka, Bangladesh",
  currency: "BDT",
  seoTitle: "Basanti Boutiques & House",
  seoDescription: "Traditional and contemporary boutique fashion.",
};

export async function GET() {
  try {
    const settings = await prisma.setting.upsert({
      where: { id: SETTING_ID },
      update: {},
      create: DEFAULT_SETTINGS,
    });
    return ok({ settings });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const data = settingUpdateSchema.parse(body);

    const settings = await prisma.setting.upsert({
      where: { id: SETTING_ID },
      update: data,
      create: { ...DEFAULT_SETTINGS, ...data },
    });

    return ok({ settings });
  } catch (error) {
    return handleApiError(error);
  }
}

export const PATCH = PUT;
