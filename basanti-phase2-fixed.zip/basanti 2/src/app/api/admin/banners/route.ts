import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { bannerCreateSchema } from "@/lib/validators";
import { ok, created, handleApiError } from "@/lib/api-response";

export async function GET() {
  try {
    const banners = await prisma.banner.findMany({
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
    });
    return ok({ banners });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const data = bannerCreateSchema.parse(body);
    const banner = await prisma.banner.create({ data });
    return created({ banner });
  } catch (error) {
    return handleApiError(error);
  }
}
