import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { bannerUpdateSchema } from "@/lib/validators";
import { ok, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ id: string }>;
}

export async function PUT(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    const data = bannerUpdateSchema.parse(body);
    const banner = await prisma.banner.update({ where: { id }, data });
    return ok({ banner });
  } catch (error) {
    return handleApiError(error);
  }
}

export const PATCH = PUT;

export async function DELETE(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    await prisma.banner.delete({ where: { id } });
    return ok({ success: true });
  } catch (error) {
    return handleApiError(error);
  }
}
