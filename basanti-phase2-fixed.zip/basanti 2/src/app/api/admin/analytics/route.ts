import { prisma } from "@/lib/prisma";
import { ok, handleApiError } from "@/lib/api-response";

export async function GET() {
  try {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const [
      totalRevenueAgg,
      monthRevenueAgg,
      todayOrdersCount,
      totalOrders,
      totalCustomers,
      totalProducts,
      lowStockProducts,
      pendingOrders,
      ordersByStatus,
      recentOrders,
      topProducts,
      revenueLast30Days,
    ] = await Promise.all([
      prisma.order.aggregate({
        _sum: { total: true },
        where: { status: { notIn: ["CANCELLED", "REFUNDED"] } },
      }),
      prisma.order.aggregate({
        _sum: { total: true },
        where: {
          createdAt: { gte: startOfMonth },
          status: { notIn: ["CANCELLED", "REFUNDED"] },
        },
      }),
      prisma.order.count({ where: { createdAt: { gte: startOfToday } } }),
      prisma.order.count(),
      prisma.customer.count(),
      prisma.product.count(),
      prisma.product.findMany({
        where: { stock: { lte: 5 } },
        select: { id: true, name: true, stock: true, image: true },
        orderBy: { stock: "asc" },
        take: 10,
      }),
      prisma.order.count({ where: { status: "PENDING" } }),
      prisma.order.groupBy({ by: ["status"], _count: { status: true } }),
      prisma.order.findMany({
        orderBy: { createdAt: "desc" },
        take: 8,
        select: {
          id: true,
          orderNumber: true,
          customerName: true,
          total: true,
          status: true,
          createdAt: true,
        },
      }),
      prisma.orderItem.groupBy({
        by: ["productId", "name"],
        _sum: { quantity: true },
        orderBy: { _sum: { quantity: "desc" } },
        take: 5,
      }),
      prisma.order.findMany({
        where: {
          createdAt: { gte: thirtyDaysAgo },
          status: { notIn: ["CANCELLED", "REFUNDED"] },
        },
        select: { createdAt: true, total: true },
      }),
    ]);

    // Bucket revenue by day for a simple 30-day trend chart.
    const revenueByDay = new Map<string, number>();
    for (const order of revenueLast30Days) {
      const key = order.createdAt.toISOString().slice(0, 10);
      revenueByDay.set(key, (revenueByDay.get(key) ?? 0) + order.total);
    }

    return ok({
      totalRevenue: totalRevenueAgg._sum.total ?? 0,
      monthRevenue: monthRevenueAgg._sum.total ?? 0,
      todayOrdersCount,
      totalOrders,
      totalCustomers,
      totalProducts,
      pendingOrders,
      lowStockProducts,
      ordersByStatus: ordersByStatus.map((s: { status: string; _count: { status: number } }) => ({
        status: s.status,
        count: s._count.status,
      })),
      recentOrders,
      topProducts: topProducts.map(
        (p: { productId: string | null; name: string; _sum: { quantity: number | null } }) => ({
          productId: p.productId,
          name: p.name,
          unitsSold: p._sum.quantity ?? 0,
      })),
      revenueTrend: Array.from(revenueByDay.entries())
        .map(([date, total]) => ({ date, total }))
        .sort((a, b) => a.date.localeCompare(b.date)),
    });
  } catch (error) {
    return handleApiError(error);
  }
}
