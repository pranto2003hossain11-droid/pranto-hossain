import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  verifyPassword,
  createAdminSessionToken,
  setAdminSessionCookie,
} from "@/lib/auth";
import { adminLoginSchema } from "@/lib/validators";
import { ok, unauthorized, handleApiError } from "@/lib/api-response";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password } = adminLoginSchema.parse(body);

    const admin = await prisma.admin.findUnique({
      where: { email: email.toLowerCase().trim() },
    });

    if (!admin) {
      return unauthorized("Invalid email or password.");
    }

    const passwordValid = await verifyPassword(password, admin.passwordHash);
    if (!passwordValid) {
      return unauthorized("Invalid email or password.");
    }

    const token = await createAdminSessionToken({
      adminId: admin.id,
      email: admin.email,
      name: admin.name,
      role: admin.role,
    });
    await setAdminSessionCookie(token);

    return ok({
      user: {
        id: admin.id,
        name: admin.name,
        email: admin.email,
        role: admin.role,
        avatar: admin.avatar,
      },
    });
  } catch (error) {
    return handleApiError(error);
  }
}
