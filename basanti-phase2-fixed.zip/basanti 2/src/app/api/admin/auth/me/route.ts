import { NextRequest } from "next/server";
import { z } from "zod";
import { getAdminSession, hashPassword } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ok, unauthorized, handleApiError } from "@/lib/api-response";

const profileUpdateSchema = z.object({
  name: z.string().min(1).optional(),
  email: z.string().email().optional(),
  avatar: z.string().optional().nullable(),
  password: z.string().min(6).optional(),
});

export async function PATCH(request: NextRequest) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return unauthorized("Not signed in.");
    }

    const body = await request.json();
    const { name, email, avatar, password } = profileUpdateSchema.parse(body);

    const admin = await prisma.admin.update({
      where: { id: session.adminId },
      data: {
        ...(name !== undefined ? { name } : {}),
        ...(email !== undefined ? { email: email.toLowerCase().trim() } : {}),
        ...(avatar !== undefined ? { avatar } : {}),
        ...(password ? { passwordHash: await hashPassword(password) } : {}),
      },
      select: { id: true, name: true, email: true, role: true, avatar: true },
    });

    return ok({ user: admin });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function GET() {
  try {
    const session = await getAdminSession();
    if (!session) {
      return unauthorized("Not signed in.");
    }

    const admin = await prisma.admin.findUnique({
      where: { id: session.adminId },
      select: { id: true, name: true, email: true, role: true, avatar: true },
    });

    if (!admin) {
      return unauthorized("Session no longer valid.");
    }

    return ok({ user: admin });
  } catch (error) {
    return handleApiError(error);
  }
}
