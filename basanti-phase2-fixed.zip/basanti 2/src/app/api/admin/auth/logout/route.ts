import { clearAdminSessionCookie } from "@/lib/auth";
import { ok, handleApiError } from "@/lib/api-response";

export async function POST() {
  try {
    await clearAdminSessionCookie();
    return ok({ success: true });
  } catch (error) {
    return handleApiError(error);
  }
}
