import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { homepageSectionUpdateSchema } from "@/lib/validators";
import { ok, handleApiError } from "@/lib/api-response";

const DEFAULT_SECTIONS = [
  "hero",
  "categories",
  "featuredProducts",
  "collections",
  "newArrivals",
  "bestSellers",
  "offers",
  "testimonials",
  "instagram",
  "newsletter",
];

export async function GET() {
  try {
    const existing = await prisma.homepageSection.findMany({
      orderBy: { sortOrder: "asc" },
    });

    // Auto-provision any section key that doesn't exist yet, so the admin
    // panel always has a toggle for every section the storefront supports,
    // even ones added after the initial migration.
    const existingKeys = new Set(existing.map((s: { key: string }) => s.key));
    const missing = DEFAULT_SECTIONS.filter((key) => !existingKeys.has(key));

    if (missing.length > 0) {
      await prisma.$transaction(
        missing.map((key, index) =>
          prisma.homepageSection.create({
            data: { key, enabled: true, sortOrder: existing.length + index },
          })
        )
      );
    }

    const sections = missing.length > 0
      ? await prisma.homepageSection.findMany({ orderBy: { sortOrder: "asc" } })
      : existing;

    return ok({ sections });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { sections } = homepageSectionUpdateSchema.parse(body);

    await prisma.$transaction(
      sections.map((section) =>
        prisma.homepageSection.upsert({
          where: { key: section.key },
          update: { enabled: section.enabled, sortOrder: section.sortOrder },
          create: section,
        })
      )
    );

    const updated = await prisma.homepageSection.findMany({
      orderBy: { sortOrder: "asc" },
    });

    return ok({ sections: updated });
  } catch (error) {
    return handleApiError(error);
  }
}
