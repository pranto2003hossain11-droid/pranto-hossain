import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { serializeProduct, toJsonString } from "@/lib/serializers";
import { productCreateSchema } from "@/lib/validators";
import { ok, created, handleApiError } from "@/lib/api-response";
import { Prisma } from "@prisma/client";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, Number(searchParams.get("page") ?? "1"));
    const pageSize = Math.min(100, Math.max(1, Number(searchParams.get("pageSize") ?? "20")));
    const search = searchParams.get("search")?.trim();
    const categoryId = searchParams.get("categoryId");
    const status = searchParams.get("status");

    const where: Prisma.ProductWhereInput = {
      ...(search
        ? {
            OR: [
              { name: { contains: search } },
              { sku: { contains: search } },
              { brand: { contains: search } },
            ],
          }
        : {}),
      ...(categoryId ? { categoryId } : {}),
      ...(status ? { status: status as "PUBLISHED" | "DRAFT" } : {}),
    };

    const [products, total] = await Promise.all([
      prisma.product.findMany({
        where,
        include: { category: { select: { name: true } } },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.product.count({ where }),
    ]);

    return ok({
      products: products.map(serializeProduct),
      pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const data = productCreateSchema.parse(body);
    const { collectionIds, ...productData } = data;

    const product = await prisma.product.create({
      data: {
        ...productData,
        images: toJsonString(productData.images),
        sizes: toJsonString(productData.sizes),
        colors: toJsonString(productData.colors),
        specifications: toJsonString(productData.specifications),
        ...(collectionIds && collectionIds.length > 0
          ? {
              collections: {
                create: collectionIds.map((collectionId, index) => ({
                  collectionId,
                  sortOrder: index,
                })),
              },
            }
          : {}),
      },
      include: { category: { select: { name: true } } },
    });

    return created({ product: serializeProduct(product) });
  } catch (error) {
    return handleApiError(error);
  }
}
