import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import type { Prisma } from "@prisma/client";
import { serializeProduct, toJsonString } from "@/lib/serializers";
import { productUpdateSchema } from "@/lib/validators";
import { ok, notFound, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ id: string }>;
}

export async function GET(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const product = await prisma.product.findUnique({
      where: { id },
      include: { category: { select: { name: true } } },
    });
    if (!product) return notFound("Product not found.");
    return ok({ product: serializeProduct(product) });
  } catch (error) {
    return handleApiError(error);
  }
}

async function updateProduct(request: NextRequest, id: string) {
  const body = await request.json();
  const data = productUpdateSchema.parse(body);
  const { collectionIds, images, sizes, colors, specifications, ...rest } = data;

  const product = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
    if (collectionIds !== undefined) {
      await tx.productCollection.deleteMany({ where: { productId: id } });
      if (collectionIds.length > 0) {
        await tx.productCollection.createMany({
          data: collectionIds.map((collectionId, index) => ({
            productId: id,
            collectionId,
            sortOrder: index,
          })),
        });
      }
    }

    return tx.product.update({
      where: { id },
      data: {
        ...rest,
        ...(images !== undefined ? { images: toJsonString(images) } : {}),
        ...(sizes !== undefined ? { sizes: toJsonString(sizes) } : {}),
        ...(colors !== undefined ? { colors: toJsonString(colors) } : {}),
        ...(specifications !== undefined
          ? { specifications: toJsonString(specifications) }
          : {}),
      },
      include: { category: { select: { name: true } } },
    });
  });

  return ok({ product: serializeProduct(product) });
}

export async function PUT(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    return await updateProduct(request, id);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PATCH(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    return await updateProduct(request, id);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    await prisma.product.delete({ where: { id } });
    return ok({ success: true });
  } catch (error) {
    return handleApiError(error);
  }
}
