import { NextRequest } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";
import { prisma } from "@/lib/prisma";
import { ok, created, badRequest, handleApiError } from "@/lib/api-response";

const ALLOWED_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif", "image/svg+xml"]);
const MAX_FILE_SIZE = 8 * 1024 * 1024; // 8MB

function safeFilename(originalName: string) {
  const ext = path.extname(originalName).toLowerCase() || "";
  const base = randomUUID();
  return `${base}${ext}`;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const folder = searchParams.get("folder");

    const media = await prisma.media.findMany({
      where: folder ? { folder } : undefined,
      orderBy: { uploadedAt: "desc" },
    });

    return ok({ media });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const files = formData.getAll("files").filter((f): f is File => f instanceof File);
    const folder = (formData.get("folder") as string | null)?.trim() || "general";

    if (files.length === 0) {
      return badRequest("No files were provided. Attach at least one file under the 'files' field.");
    }

    for (const file of files) {
      if (!ALLOWED_TYPES.has(file.type)) {
        return badRequest(`Unsupported file type: ${file.type}. Allowed: JPG, PNG, WEBP, GIF, SVG.`);
      }
      if (file.size > MAX_FILE_SIZE) {
        return badRequest(`File "${file.name}" exceeds the 8MB size limit.`);
      }
    }

    const uploadDir = path.join(process.cwd(), "public", "uploads", folder);
    await mkdir(uploadDir, { recursive: true });

    const createdMedia = await Promise.all(
      files.map(async (file) => {
        const filename = safeFilename(file.name);
        const buffer = Buffer.from(await file.arrayBuffer());
        await writeFile(path.join(uploadDir, filename), buffer);

        const url = `/uploads/${folder}/${filename}`;
        return prisma.media.create({
          data: {
            url,
            name: file.name,
            folder,
            size: file.size,
            type: file.type,
          },
        });
      })
    );

    return created({ media: createdMedia });
  } catch (error) {
    return handleApiError(error);
  }
}
