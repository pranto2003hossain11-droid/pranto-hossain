import { NextRequest } from "next/server";
import { unlink } from "fs/promises";
import path from "path";
import { prisma } from "@/lib/prisma";
import { ok, notFound, conflict, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ id: string }>;
}

async function findReferences(url: string) {
  const [products, categories, collections, banners, setting] = await Promise.all([
    prisma.product.findMany({
      where: { OR: [{ image: url }, { images: { contains: url } }] },
      select: { id: true, name: true },
    }),
    prisma.category.findMany({ where: { image: url }, select: { id: true, name: true } }),
    prisma.collection.findMany({ where: { image: url }, select: { id: true, name: true } }),
    prisma.banner.findMany({ where: { image: url }, select: { id: true, title: true } }),
    prisma.setting.findFirst({
      where: { OR: [{ logo: url }, { favicon: url }] },
      select: { id: true },
    }),
  ]);

  const references: string[] = [
    ...products.map((p: { name: string }) => `Product "${p.name}"`),
    ...categories.map((c: { name: string }) => `Category "${c.name}"`),
    ...collections.map((c: { name: string }) => `Collection "${c.name}"`),
    ...banners.map((b: { title: string }) => `Banner "${b.title}"`),
    ...(setting ? ["Store Settings (logo/favicon)"] : []),
  ];

  return references;
}

export async function DELETE(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const force = searchParams.get("force") === "true";

    const media = await prisma.media.findUnique({ where: { id } });
    if (!media) return notFound("Media item not found.");

    if (!force) {
      const references = await findReferences(media.url);
      if (references.length > 0) {
        return conflict(
          `This file is still used by: ${references.join(", ")}. Remove it from those first, or delete with force=true to unlink anyway.`
        );
      }
    }

    await prisma.media.delete({ where: { id } });

    // Only ever unlink files inside our own managed uploads directory.
    if (media.url.startsWith("/uploads/")) {
      const filePath = path.join(process.cwd(), "public", media.url);
      try {
        await unlink(filePath);
      } catch {
        // File already missing from disk — the DB record removal is what matters.
      }
    }

    return ok({ success: true });
  } catch (error) {
    return handleApiError(error);
  }
}
