import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import type { Prisma } from "@prisma/client";
import { collectionUpdateSchema } from "@/lib/validators";
import { ok, notFound, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ id: string }>;
}

export async function GET(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const collection = await prisma.collection.findUnique({
      where: { id },
      include: { products: { include: { product: true } } },
    });
    if (!collection) return notFound("Collection not found.");
    return ok({ collection });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { productIds, ...data } = collectionUpdateSchema.parse(body);

    const collection = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      if (productIds !== undefined) {
        await tx.productCollection.deleteMany({ where: { collectionId: id } });
        if (productIds.length > 0) {
          await tx.productCollection.createMany({
            data: productIds.map((productId, index) => ({
              productId,
              collectionId: id,
              sortOrder: index,
            })),
          });
        }
      }
      return tx.collection.update({ where: { id }, data });
    });

    return ok({ collection });
  } catch (error) {
    return handleApiError(error);
  }
}

export const PATCH = PUT;

export async function DELETE(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    await prisma.collection.delete({ where: { id } });
    return ok({ success: true });
  } catch (error) {
    return handleApiError(error);
  }
}
