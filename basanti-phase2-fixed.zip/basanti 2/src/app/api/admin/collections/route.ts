import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { serializeProduct } from "@/lib/serializers";
import { collectionCreateSchema } from "@/lib/validators";
import { ok, created, handleApiError } from "@/lib/api-response";

export async function GET() {
  try {
    const collections = await prisma.collection.findMany({
      orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
      include: {
        products: {
          include: { product: { include: { category: { select: { name: true } } } } },
          orderBy: { sortOrder: "asc" },
        },
      },
    });

    return ok({
      collections: collections.map(
        (c: {
          id: string;
          name: string;
          slug: string;
          description: string | null;
          image: string | null;
          sortOrder: number;
          visible: boolean;
          products: { product: Parameters<typeof serializeProduct>[0] }[];
        }) => ({
          id: c.id,
          name: c.name,
          slug: c.slug,
          description: c.description,
          image: c.image,
          sortOrder: c.sortOrder,
          visible: c.visible,
          products: c.products.map((pc) => serializeProduct(pc.product)),
        })
      ),
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { productIds, ...data } = collectionCreateSchema.parse(body);
    const collection = await prisma.collection.create({
      data: {
        ...data,
        ...(productIds && productIds.length > 0
          ? {
              products: {
                create: productIds.map((productId, index) => ({
                  productId,
                  sortOrder: index,
                })),
              },
            }
          : {}),
      },
    });
    return created({ collection });
  } catch (error) {
    return handleApiError(error);
  }
}
