import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { categoryUpdateSchema } from "@/lib/validators";
import { ok, notFound, badRequest, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ id: string }>;
}

export async function GET(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const category = await prisma.category.findUnique({
      where: { id },
      include: { _count: { select: { products: true } } },
    });
    if (!category) return notFound("Category not found.");
    return ok({ category });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    const data = categoryUpdateSchema.parse(body);
    if (data.parentId === id) {
      return badRequest("A category cannot be its own parent.");
    }
    const category = await prisma.category.update({ where: { id }, data });
    return ok({ category });
  } catch (error) {
    return handleApiError(error);
  }
}

export const PATCH = PUT;

export async function DELETE(_request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const childCount = await prisma.category.count({ where: { parentId: id } });
    if (childCount > 0) {
      return badRequest(
        "This category has sub-categories. Reassign or delete them first."
      );
    }
    await prisma.category.delete({ where: { id } });
    return ok({ success: true });
  } catch (error) {
    return handleApiError(error);
  }
}
