import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { categoryCreateSchema } from "@/lib/validators";
import { ok, created, handleApiError } from "@/lib/api-response";

export async function GET() {
  try {
    const categories = await prisma.category.findMany({
      orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
      include: { _count: { select: { products: true } } },
    });
    return ok({ categories });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const data = categoryCreateSchema.parse(body);
    const category = await prisma.category.create({ data });
    return created({ category });
  } catch (error) {
    return handleApiError(error);
  }
}
