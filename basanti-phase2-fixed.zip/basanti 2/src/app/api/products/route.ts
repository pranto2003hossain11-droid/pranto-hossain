import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { serializeProduct } from "@/lib/serializers";
import { ok, handleApiError } from "@/lib/api-response";
import { Prisma } from "@prisma/client";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, Number(searchParams.get("page") ?? "1"));
    const pageSize = Math.min(60, Math.max(1, Number(searchParams.get("pageSize") ?? "24")));
    const categorySlug = searchParams.get("category");
    const collectionSlug = searchParams.get("collection");
    const isNew = searchParams.get("isNew");
    const isBestSeller = searchParams.get("isBestSeller");
    const minPrice = searchParams.get("minPrice");
    const maxPrice = searchParams.get("maxPrice");
    const sort = searchParams.get("sort"); // "newest" | "price-asc" | "price-desc" | "rating"

    const where: Prisma.ProductWhereInput = {
      status: "PUBLISHED",
      visibility: "VISIBLE",
      ...(categorySlug ? { category: { slug: categorySlug } } : {}),
      ...(collectionSlug
        ? { collections: { some: { collection: { slug: collectionSlug } } } }
        : {}),
      ...(isNew === "true" ? { isNew: true } : {}),
      ...(isBestSeller === "true" ? { isBestSeller: true } : {}),
      ...(minPrice || maxPrice
        ? {
            price: {
              ...(minPrice ? { gte: Number(minPrice) } : {}),
              ...(maxPrice ? { lte: Number(maxPrice) } : {}),
            },
          }
        : {}),
    };

    const orderBy: Prisma.ProductOrderByWithRelationInput =
      sort === "price-asc"
        ? { price: "asc" }
        : sort === "price-desc"
        ? { price: "desc" }
        : sort === "rating"
        ? { rating: "desc" }
        : { createdAt: "desc" };

    const [products, total] = await Promise.all([
      prisma.product.findMany({
        where,
        include: { category: { select: { name: true } } },
        orderBy,
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.product.count({ where }),
    ]);

    return ok({
      products: products.map(serializeProduct),
      pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
    });
  } catch (error) {
    return handleApiError(error);
  }
}
