import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { serializeProduct } from "@/lib/serializers";
import { ok, notFound, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ slug: string }>;
}

export async function GET(_request: NextRequest, { params }: Params) {
  try {
    const { slug } = await params;

    const product = await prisma.product.findUnique({
      where: { slug },
      include: { category: { select: { name: true, slug: true } } },
    });

    if (!product || product.status !== "PUBLISHED" || product.visibility !== "VISIBLE") {
      return notFound("Product not found.");
    }

    const [relatedProducts, reviews] = await Promise.all([
      product.categoryId
        ? prisma.product.findMany({
            where: {
              categoryId: product.categoryId,
              id: { not: product.id },
              status: "PUBLISHED",
              visibility: "VISIBLE",
            },
            include: { category: { select: { name: true } } },
            take: 8,
          })
        : Promise.resolve([]),
      prisma.review.findMany({
        where: { productId: product.id, approved: true },
        orderBy: { createdAt: "desc" },
      }),
    ]);

    return ok({
      product: serializeProduct(product),
      relatedProducts: relatedProducts.map(serializeProduct),
      reviews,
    });
  } catch (error) {
    return handleApiError(error);
  }
}
