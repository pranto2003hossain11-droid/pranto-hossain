import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { couponValidateSchema } from "@/lib/validators";
import { ok, badRequest, notFound, handleApiError } from "@/lib/api-response";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { code, subtotal } = couponValidateSchema.parse(body);

    const coupon = await prisma.coupon.findUnique({
      where: { code: code.toUpperCase().trim() },
    });

    if (!coupon || !coupon.enabled) {
      return notFound("This coupon code is invalid or no longer active.");
    }

    if (coupon.expiryDate && coupon.expiryDate < new Date()) {
      return badRequest("This coupon has expired.");
    }

    if (coupon.usageLimit !== null && coupon.usedCount >= coupon.usageLimit) {
      return badRequest("This coupon has reached its usage limit.");
    }

    if (coupon.minOrder !== null && subtotal < coupon.minOrder) {
      return badRequest(`This coupon requires a minimum order of ৳${coupon.minOrder}.`);
    }

    const discount =
      coupon.type === "PERCENTAGE"
        ? Math.round(subtotal * (coupon.value / 100) * 100) / 100
        : Math.min(coupon.value, subtotal);

    return ok({
      valid: true,
      coupon: { code: coupon.code, type: coupon.type, value: coupon.value },
      discount,
    });
  } catch (error) {
    return handleApiError(error);
  }
}
