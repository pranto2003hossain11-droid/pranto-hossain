import { prisma } from "@/lib/prisma";
import { ok, handleApiError } from "@/lib/api-response";

const SETTING_ID = "singleton";

export async function GET() {
  try {
    const settings = await prisma.setting.findUnique({ where: { id: SETTING_ID } });

    // Every field on Setting is already safe to expose publicly (no secrets
    // live on this model), but we select explicitly so a future sensitive
    // field added to the model doesn't leak here by accident.
    if (!settings) {
      return ok({ settings: null });
    }

    return ok({
      settings: {
        storeName: settings.storeName,
        logo: settings.logo,
        favicon: settings.favicon,
        phone: settings.phone,
        email: settings.email,
        address: settings.address,
        facebook: settings.facebook,
        instagram: settings.instagram,
        whatsapp: settings.whatsapp,
        shippingCharge: settings.shippingCharge,
        freeShippingThreshold: settings.freeShippingThreshold,
        currency: settings.currency,
        seoTitle: settings.seoTitle,
        seoDescription: settings.seoDescription,
      },
    });
  } catch (error) {
    return handleApiError(error);
  }
}
