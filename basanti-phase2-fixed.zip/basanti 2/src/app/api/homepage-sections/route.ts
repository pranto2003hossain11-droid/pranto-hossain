import { prisma } from "@/lib/prisma";
import { ok, handleApiError } from "@/lib/api-response";

export async function GET() {
  try {
    const sections = await prisma.homepageSection.findMany({
      where: { enabled: true },
      orderBy: { sortOrder: "asc" },
      select: { key: true, sortOrder: true },
    });
    return ok({ sections });
  } catch (error) {
    return handleApiError(error);
  }
}
