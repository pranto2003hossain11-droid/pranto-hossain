import { prisma } from "@/lib/prisma";
import { ok, handleApiError } from "@/lib/api-response";

export async function GET() {
  try {
    const banners = await prisma.banner.findMany({
      where: { enabled: true },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
    });
    return ok({ banners });
  } catch (error) {
    return handleApiError(error);
  }
}
