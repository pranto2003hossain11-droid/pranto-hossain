import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { serializeProduct } from "@/lib/serializers";
import { ok, notFound, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ slug: string }>;
}

export async function GET(_request: NextRequest, { params }: Params) {
  try {
    const { slug } = await params;

    const collection = await prisma.collection.findUnique({
      where: { slug },
      include: {
        products: {
          where: { product: { status: "PUBLISHED", visibility: "VISIBLE" } },
          include: { product: { include: { category: { select: { name: true } } } } },
          orderBy: { sortOrder: "asc" },
        },
      },
    });

    if (!collection || !collection.visible) {
      return notFound("Collection not found.");
    }

    return ok({
      collection: {
        id: collection.id,
        name: collection.name,
        slug: collection.slug,
        description: collection.description,
        image: collection.image,
        products: collection.products.map((pc: { product: Parameters<typeof serializeProduct>[0] }) =>
          serializeProduct(pc.product)
        ),
      },
    });
  } catch (error) {
    return handleApiError(error);
  }
}
