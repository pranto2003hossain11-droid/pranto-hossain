import { prisma } from "@/lib/prisma";
import { serializeProduct } from "@/lib/serializers";
import { ok, handleApiError } from "@/lib/api-response";

export async function GET() {
  try {
    const collections = await prisma.collection.findMany({
      where: { visible: true },
      orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
      include: {
        products: {
          where: {
            product: { status: "PUBLISHED", visibility: "VISIBLE" },
          },
          include: { product: { include: { category: { select: { name: true } } } } },
          orderBy: { sortOrder: "asc" },
        },
      },
    });

    return ok({
      collections: collections.map(
        (c: {
          id: string;
          name: string;
          slug: string;
          description: string | null;
          image: string | null;
          products: { product: Parameters<typeof serializeProduct>[0] }[];
        }) => ({
          id: c.id,
          name: c.name,
          slug: c.slug,
          description: c.description,
          image: c.image,
          products: c.products.map((pc) => serializeProduct(pc.product)),
        })
      ),
    });
  } catch (error) {
    return handleApiError(error);
  }
}
