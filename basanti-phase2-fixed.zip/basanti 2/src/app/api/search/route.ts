import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { serializeProduct } from "@/lib/serializers";
import { ok, badRequest, handleApiError } from "@/lib/api-response";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get("q")?.trim();
    const limit = Math.min(50, Math.max(1, Number(searchParams.get("limit") ?? "20")));

    if (!query) {
      return badRequest("Provide a search query via ?q=");
    }

    const products = await prisma.product.findMany({
      where: {
        status: "PUBLISHED",
        visibility: "VISIBLE",
        OR: [
          { name: { contains: query } },
          { description: { contains: query } },
          { brand: { contains: query } },
          { category: { name: { contains: query } } },
        ],
      },
      include: { category: { select: { name: true } } },
      take: limit,
      orderBy: { rating: "desc" },
    });

    return ok({ query, results: products.map(serializeProduct) });
  } catch (error) {
    return handleApiError(error);
  }
}
