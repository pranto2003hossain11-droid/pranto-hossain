import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ok, notFound, badRequest, handleApiError } from "@/lib/api-response";

interface Params {
  params: Promise<{ orderNumber: string }>;
}

export async function GET(request: NextRequest, { params }: Params) {
  try {
    const { orderNumber } = await params;
    const { searchParams } = new URL(request.url);
    const email = searchParams.get("email")?.trim().toLowerCase();
    const phone = searchParams.get("phone")?.trim();

    if (!email && !phone) {
      return badRequest("Provide the order email or phone number to look up an order.");
    }

    const order = await prisma.order.findUnique({
      where: { orderNumber },
      include: { items: true },
    });

    if (
      !order ||
      (email && order.customerEmail.toLowerCase() !== email) ||
      (phone && order.phone !== phone)
    ) {
      return notFound("No order found matching those details.");
    }

    return ok({ order });
  } catch (error) {
    return handleApiError(error);
  }
}
