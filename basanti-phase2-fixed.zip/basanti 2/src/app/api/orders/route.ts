import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import type { Prisma, Product as PrismaProduct } from "@prisma/client";
import { orderCreateSchema } from "@/lib/validators";
import { created, badRequest, handleApiError } from "@/lib/api-response";

function generateOrderNumber() {
  const date = new Date();
  const datePart = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(
    date.getDate()
  ).padStart(2, "0")}`;
  const randomPart = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `BAS-${datePart}-${randomPart}`;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const data = orderCreateSchema.parse(body);

    const result = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      // Re-fetch every product server-side — never trust client-supplied
      // prices or stock. This is the one source of truth for checkout math.
      const productIds = data.items.map((item) => item.productId);
      const products = await tx.product.findMany({ where: { id: { in: productIds } } });
      const productMap = new Map<string, PrismaProduct>(
        products.map((p: PrismaProduct) => [p.id, p])
      );

      for (const item of data.items) {
        const product = productMap.get(item.productId);
        if (!product) {
          throw new Error(`Product ${item.productId} no longer exists.`);
        }
        if (product.status !== "PUBLISHED" || product.visibility !== "VISIBLE") {
          throw new Error(`"${product.name}" is no longer available.`);
        }
        if (product.stock < item.quantity) {
          throw new Error(`Not enough stock for "${product.name}" (only ${product.stock} left).`);
        }
      }

      const subtotal = data.items.reduce((sum, item) => {
        const product = productMap.get(item.productId)!;
        return sum + product.price * item.quantity;
      }, 0);

      let discount = 0;
      let couponCode: string | null = null;
      if (data.couponCode) {
        const coupon = await tx.coupon.findUnique({
          where: { code: data.couponCode.toUpperCase().trim() },
        });
        if (!coupon || !coupon.enabled) {
          throw new Error("The applied coupon is no longer valid.");
        }
        if (coupon.expiryDate && coupon.expiryDate < new Date()) {
          throw new Error("The applied coupon has expired.");
        }
        if (coupon.usageLimit !== null && coupon.usedCount >= coupon.usageLimit) {
          throw new Error("The applied coupon has reached its usage limit.");
        }
        if (coupon.minOrder !== null && subtotal < coupon.minOrder) {
          throw new Error(`This coupon requires a minimum order of ৳${coupon.minOrder}.`);
        }
        discount =
          coupon.type === "PERCENTAGE"
            ? Math.round(subtotal * (coupon.value / 100) * 100) / 100
            : Math.min(coupon.value, subtotal);
        couponCode = coupon.code;
        await tx.coupon.update({
          where: { id: coupon.id },
          data: { usedCount: { increment: 1 } },
        });
      }

      const settings = await tx.setting.findUnique({ where: { id: "singleton" } });
      const afterDiscount = subtotal - discount;
      const shipping =
        settings && afterDiscount >= settings.freeShippingThreshold && settings.freeShippingThreshold > 0
          ? 0
          : settings?.shippingCharge ?? 0;
      const total = afterDiscount + shipping;

      const order = await tx.order.create({
        data: {
          orderNumber: generateOrderNumber(),
          customerId: data.customerId ?? null,
          customerName: data.customerName,
          customerEmail: data.customerEmail,
          subtotal,
          shipping,
          discount,
          total,
          paymentMethod: data.paymentMethod,
          shippingAddress: data.shippingAddress,
          phone: data.phone,
          couponCode,
          items: {
            create: data.items.map((item) => {
              const product = productMap.get(item.productId)!;
              return {
                productId: item.productId,
                name: product.name,
                image: product.image,
                size: item.size,
                quantity: item.quantity,
                price: product.price,
              };
            }),
          },
        },
        include: { items: true },
      });

      // Decrement stock for every purchased item.
      await Promise.all(
        data.items.map((item) =>
          tx.product.update({
            where: { id: item.productId },
            data: { stock: { decrement: item.quantity } },
          })
        )
      );

      return order;
    });

    return created({ order: result });
  } catch (error) {
    if (error instanceof Error && !("code" in error)) {
      return badRequest(error.message);
    }
    return handleApiError(error);
  }
}
