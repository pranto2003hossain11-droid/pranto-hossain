import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword } from "@/lib/auth";
import { createCustomerSessionToken, setCustomerSessionCookie } from "@/lib/customer-auth";
import { serializePublicCustomer } from "@/lib/serializers";
import { customerRegisterSchema } from "@/lib/validators";
import { created, conflict, handleApiError } from "@/lib/api-response";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const data = customerRegisterSchema.parse(body);
    const email = data.email.toLowerCase().trim();

    const existing = await prisma.customer.findUnique({ where: { email } });
    if (existing) {
      return conflict("An account with this email already exists.");
    }

    const customer = await prisma.customer.create({
      data: {
        name: data.name,
        email,
        phone: data.phone,
        passwordHash: await hashPassword(data.password),
      },
    });

    const token = await createCustomerSessionToken({
      customerId: customer.id,
      email: customer.email,
      name: customer.name,
    });
    await setCustomerSessionCookie(token);

    return created({ customer: serializePublicCustomer(customer) });
  } catch (error) {
    return handleApiError(error);
  }
}
