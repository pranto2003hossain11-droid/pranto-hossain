import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyPassword } from "@/lib/auth";
import { createCustomerSessionToken, setCustomerSessionCookie } from "@/lib/customer-auth";
import { serializePublicCustomer } from "@/lib/serializers";
import { customerLoginSchema } from "@/lib/validators";
import { ok, unauthorized, handleApiError } from "@/lib/api-response";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password } = customerLoginSchema.parse(body);

    const customer = await prisma.customer.findUnique({
      where: { email: email.toLowerCase().trim() },
    });

    if (!customer || !customer.passwordHash) {
      return unauthorized("Invalid email or password.");
    }

    const valid = await verifyPassword(password, customer.passwordHash);
    if (!valid) {
      return unauthorized("Invalid email or password.");
    }

    if (customer.status === "INACTIVE") {
      return unauthorized("This account has been deactivated. Please contact support.");
    }

    const token = await createCustomerSessionToken({
      customerId: customer.id,
      email: customer.email,
      name: customer.name,
    });
    await setCustomerSessionCookie(token);

    return ok({ customer: serializePublicCustomer(customer) });
  } catch (error) {
    return handleApiError(error);
  }
}
