import { getCustomerSession } from "@/lib/customer-auth";
import { prisma } from "@/lib/prisma";
import { serializePublicCustomer } from "@/lib/serializers";
import { ok, unauthorized, handleApiError } from "@/lib/api-response";

export async function GET() {
  try {
    const session = await getCustomerSession();
    if (!session) {
      return unauthorized("Not signed in.");
    }

    const customer = await prisma.customer.findUnique({ where: { id: session.customerId } });
    if (!customer) {
      return unauthorized("Session no longer valid.");
    }

    return ok({ customer: serializePublicCustomer(customer) });
  } catch (error) {
    return handleApiError(error);
  }
}
