import { clearCustomerSessionCookie } from "@/lib/customer-auth";
import { ok, handleApiError } from "@/lib/api-response";

export async function POST() {
  try {
    await clearCustomerSessionCookie();
    return ok({ success: true });
  } catch (error) {
    return handleApiError(error);
  }
}
