import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { reviewCreateSchema } from "@/lib/validators";
import { ok, created, badRequest, handleApiError } from "@/lib/api-response";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const productId = searchParams.get("productId");
    const productSlug = searchParams.get("productSlug");

    if (!productId && !productSlug) {
      return badRequest("Provide either productId or productSlug.");
    }

    const reviews = await prisma.review.findMany({
      where: {
        approved: true,
        product: productSlug ? { slug: productSlug } : undefined,
        ...(productId ? { productId } : {}),
      },
      orderBy: { createdAt: "desc" },
    });

    return ok({ reviews });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const data = reviewCreateSchema.parse(body);

    // New reviews start unapproved so they go through admin moderation
    // before appearing publicly or affecting the product's rating.
    const review = await prisma.review.create({
      data: { ...data, approved: false, verified: Boolean(data.customerId) },
    });

    return created({
      review,
      message: "Thanks for your review! It will appear once approved by our team.",
    });
  } catch (error) {
    return handleApiError(error);
  }
}
