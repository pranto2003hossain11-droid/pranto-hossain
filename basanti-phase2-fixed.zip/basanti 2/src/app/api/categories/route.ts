import { prisma } from "@/lib/prisma";
import { ok, handleApiError } from "@/lib/api-response";

export async function GET() {
  try {
    const categories = await prisma.category.findMany({
      where: { visible: true },
      orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
      include: {
        children: { where: { visible: true }, orderBy: { sortOrder: "asc" } },
        _count: {
          select: {
            products: { where: { status: "PUBLISHED", visibility: "VISIBLE" } },
          },
        },
      },
      // Only return top-level categories; children are nested above.
    });

    const topLevel = categories.filter((c: { parentId: string | null }) => !c.parentId);

    return ok({ categories: topLevel });
  } catch (error) {
    return handleApiError(error);
  }
}
