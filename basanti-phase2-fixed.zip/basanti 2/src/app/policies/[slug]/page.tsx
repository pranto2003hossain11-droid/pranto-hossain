import { notFound } from "next/navigation";
import type { Metadata } from "next";

const policies: Record<string, { title: string; body: string[] }> = {
  returns: {
    title: "Returns & Exchanges",
    body: [
      "We accept returns within 7 days of delivery for items that are unused, unworn, and in their original packaging with tags attached.",
      "To start a return, contact our support team with your order number. Once approved, we'll arrange pickup or provide a drop-off location.",
      "Refunds are processed within 5–7 business days after the returned item is received and inspected. Sale items are final sale unless defective.",
    ],
  },
  privacy: {
    title: "Privacy Policy",
    body: [
      "We collect only the information needed to process your orders and improve your shopping experience — name, contact details, and shipping address.",
      "We never sell your personal information to third parties. Payment details are processed securely and are not stored on our servers.",
      "You may request access to or deletion of your data at any time by contacting hello@basantiboutiques.com.",
    ],
  },
  terms: {
    title: "Terms of Service",
    body: [
      "By using this website, you agree to use it only for lawful purposes and in a way that does not infringe the rights of others.",
      "All product descriptions, images, and pricing are subject to change without notice. We reserve the right to refuse or cancel any order.",
      "All content on this site, including logos and designs, is the property of Basanti Boutiques & House and may not be reproduced without permission.",
    ],
  },
  shipping: {
    title: "Shipping Policy",
    body: [
      "Orders are processed within 1–2 business days. Delivery within Dhaka takes 1–2 business days; outside Dhaka, 3–5 business days.",
      "Free shipping applies to orders over ৳3,000. A flat shipping fee applies to orders below this threshold.",
      "You will receive tracking information by SMS and email once your order has shipped.",
    ],
  },
};

export function generateStaticParams() {
  return Object.keys(policies).map((slug) => ({ slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const policy = policies[params.slug];
  return { title: policy?.title ?? "Policy" };
}

export default function PolicyPage({ params }: { params: { slug: string } }) {
  const policy = policies[params.slug];
  if (!policy) notFound();

  return (
    <div className="container-padded section-spacing">
      <div className="mx-auto max-w-2xl">
        <h1 className="mb-8 font-display text-display-sm md:text-display-md">{policy.title}</h1>
        <div className="space-y-4 text-sm leading-relaxed text-charcoal-light">
          {policy.body.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
      </div>
    </div>
  );
}
