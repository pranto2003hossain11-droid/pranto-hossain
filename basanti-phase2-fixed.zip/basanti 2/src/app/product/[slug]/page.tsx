import { notFound } from "next/navigation";
import Link from "next/link";
import { Star, ChevronRight } from "lucide-react";
import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { serializeProduct } from "@/lib/serializers";
import { formatPrice } from "@/lib/utils";
import { ProductGallery } from "@/components/product/product-gallery";
import { AddToCartPanel } from "@/components/product/add-to-cart-panel";
import { ReviewsSection } from "@/components/product/reviews-section";
import { ProductSection } from "@/components/home/product-section";

export const dynamic = "force-dynamic";

interface PageProps {
  params: { slug: string };
}

async function loadProduct(slug: string) {
  const product = await prisma.product.findUnique({
    where: { slug },
    include: { category: { select: { name: true, slug: true } } },
  });
  if (!product || product.status !== "PUBLISHED" || product.visibility !== "VISIBLE") {
    return null;
  }
  return product;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const product = await loadProduct(params.slug);
  if (!product) return {};
  return {
    title: product.seoTitle || product.name,
    description: product.seoDescription || product.description || undefined,
    openGraph: { images: [product.image] },
  };
}

export default async function ProductPage({ params }: PageProps) {
  const product = await loadProduct(params.slug);
  if (!product) notFound();

  const [reviewRows, relatedRows] = await Promise.all([
    prisma.review.findMany({
      where: { productId: product.id, approved: true },
      orderBy: { createdAt: "desc" },
    }),
    product.categoryId
      ? prisma.product.findMany({
          where: {
            categoryId: product.categoryId,
            id: { not: product.id },
            status: "PUBLISHED",
            visibility: "VISIBLE",
          },
          include: { category: { select: { name: true } } },
          take: 8,
        })
      : Promise.resolve([]),
  ]);

  const serialized = serializeProduct(product);
  const reviews = reviewRows.map((r: (typeof reviewRows)[number]) => ({
    id: r.id,
    productId: r.productId,
    author: r.author,
    rating: r.rating,
    date: r.createdAt.toISOString(),
    text: r.text,
    verified: r.verified,
  }));
  const related = relatedRows.map(serializeProduct);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: serialized.name,
    image: serialized.images && serialized.images.length > 0 ? serialized.images : [serialized.image],
    description: serialized.description,
    offers: {
      "@type": "Offer",
      priceCurrency: "BDT",
      price: serialized.price,
      availability: serialized.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: serialized.rating,
      reviewCount: serialized.reviewCount,
    },
  };

  const categorySlug = product.category?.slug ?? "";

  return (
    <div className="container-padded section-spacing">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-1.5 text-xs text-charcoal-muted">
        <Link href="/" className="hover:text-maroon">Home</Link>
        <ChevronRight className="h-3 w-3" />
        <Link href={`/category/${categorySlug}`} className="hover:text-maroon">
          {serialized.category}
        </Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-charcoal">{serialized.name}</span>
      </nav>

      <div className="grid grid-cols-1 gap-10 md:grid-cols-2 md:gap-14">
        <ProductGallery images={serialized.images && serialized.images.length > 0 ? serialized.images : [serialized.image]} name={serialized.name} />

        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-gold-600">{serialized.category}</p>
          <h1 className="mt-1 font-display text-display-sm md:text-display-md">{serialized.name}</h1>

          <div className="mt-2 flex items-center gap-2 text-sm text-charcoal-light">
            <div className="flex gap-0.5">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className={`h-4 w-4 ${i < Math.round(serialized.rating) ? "fill-gold text-gold" : "text-beige-dark"}`} />
              ))}
            </div>
            <a href="#reviews" className="hover:text-maroon">{serialized.rating} ({serialized.reviewCount} reviews)</a>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <span className="font-display text-2xl font-semibold text-maroon">{formatPrice(serialized.price)}</span>
            {serialized.compareAtPrice && (
              <span className="text-base text-charcoal-muted line-through">{formatPrice(serialized.compareAtPrice)}</span>
            )}
          </div>

          <p className="mt-5 max-w-md text-sm leading-relaxed text-charcoal-light">{serialized.description}</p>

          <div className="mt-6">
            <AddToCartPanel product={serialized} />
          </div>
        </div>
      </div>

      <div className="mt-16">
        <ReviewsSection reviews={reviews} rating={serialized.rating} count={serialized.reviewCount} />
      </div>

      {related.length > 0 && (
        <div className="mt-4">
          <ProductSection
            eyebrow="You May Also Like"
            title="Related Products"
            products={related}
            viewAllHref={`/category/${categorySlug}`}
          />
        </div>
      )}
    </div>
  );
}
