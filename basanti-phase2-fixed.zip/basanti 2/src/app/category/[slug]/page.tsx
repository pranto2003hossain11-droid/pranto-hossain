import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { serializeProduct } from "@/lib/serializers";
import { ProductCard } from "@/components/product/product-card";

export const dynamic = "force-dynamic";

interface PageProps {
  params: { slug: string };
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const category = await prisma.category.findUnique({ where: { slug: params.slug } });
  if (!category) return { title: "Category | Basanti Boutiques & House" };
  return { title: `${category.name} | Basanti Boutiques & House` };
}

export default async function CategoryPage({ params }: PageProps) {
  const category = await prisma.category.findUnique({ where: { slug: params.slug } });

  if (!category || !category.visible) notFound();

  const products = await prisma.product.findMany({
    where: { categoryId: category.id, status: "PUBLISHED", visibility: "VISIBLE" },
    include: { category: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="container-padded section-spacing">
      <div className="mb-10 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Category</p>
        <h1 className="mt-2 font-display text-display-sm capitalize md:text-display-md">{category.name}</h1>
      </div>
      {products.length === 0 ? (
        <p className="text-center text-charcoal-muted">No products in this category yet.</p>
      ) : (
        <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-4 lg:gap-x-6">
          {products.map((p: Parameters<typeof serializeProduct>[0]) => (
            <ProductCard key={p.id} product={serializeProduct(p)} />
          ))}
        </div>
      )}
    </div>
  );
}
