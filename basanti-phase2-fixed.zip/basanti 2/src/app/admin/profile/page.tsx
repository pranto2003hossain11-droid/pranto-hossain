"use client";

import * as React from "react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { AdminInput } from "@/components/admin/ui/admin-input";
import { ImageDropzone } from "@/components/admin/ui/image-dropzone";
import { Button } from "@/components/ui/button";
import { useAdminAuthStore } from "@/store/admin/admin-auth-store";
import { useToastStore } from "@/store/admin/toast-store";

export default function AdminProfilePage() {
  const user = useAdminAuthStore((s) => s.user);
  const updateProfile = useAdminAuthStore((s) => s.updateProfile);
  const showToast = useToastStore((s) => s.show);
  const [name, setName] = React.useState(user?.name ?? "");
  const [email, setEmail] = React.useState(user?.email ?? "");
  const [avatar, setAvatar] = React.useState(user?.avatar ?? "");
  const [password, setPassword] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const result = await updateProfile({
      name,
      email,
      avatar: avatar || null,
      ...(password ? { password } : {}),
    });
    setSaving(false);
    setPassword("");
    showToast(result.success ? "Profile updated." : result.error ?? "Failed to update profile.");
  }

  return (
    <div>
      <PageHeader title="Admin Profile" description="Manage your personal account details" />

      <form onSubmit={handleSave} className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Personal Information</h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <AdminInput label="Full Name" value={name} onChange={(e) => setName(e.target.value)} />
              <AdminInput label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
              <AdminInput label="Role" value={user?.role ?? "Owner"} disabled />
            </div>
          </section>

          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Change Password</h3>
            <AdminInput
              label="New Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              hint="Leave blank to keep your current password."
            />
          </section>

          <Button type="submit" size="lg" isLoading={saving}>
            Save Changes
          </Button>
        </div>

        <div>
          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-3 font-display text-base font-semibold text-charcoal">Profile Photo</h3>
            <ImageDropzone images={avatar ? [avatar] : []} onChange={(imgs) => setAvatar(imgs[imgs.length - 1] ?? "")} maxImages={1} />
          </section>
        </div>
      </form>
    </div>
  );
}
