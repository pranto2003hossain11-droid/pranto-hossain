"use client";

import * as React from "react";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Printer } from "lucide-react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { OrderStatusBadge } from "@/components/admin/ui/status-badge";
import { AdminSelect } from "@/components/admin/ui/admin-input";
import { Button } from "@/components/ui/button";
import { useOrdersStore } from "@/store/admin/orders-store";
import { useToastStore } from "@/store/admin/toast-store";
import { formatPrice } from "@/lib/utils";
import type { OrderStatus } from "@/lib/admin-types";

const statusOptions: OrderStatus[] = ["Pending", "Confirmed", "Processing", "Packed", "Shipped", "Delivered", "Cancelled", "Refunded"];

export default function AdminOrderDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const getOrder = useOrdersStore((s) => s.getOrder);
  const fetchOrders = useOrdersStore((s) => s.fetchOrders);
  const updateStatus = useOrdersStore((s) => s.updateStatus);
  const isLoading = useOrdersStore((s) => s.isLoading);
  const showToast = useToastStore((s) => s.show);
  const order = getOrder(params.id);

  React.useEffect(() => {
    fetchOrders();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!order) {
    if (isLoading) {
      return (
        <div className="flex h-40 items-center justify-center rounded-md bg-white shadow-soft">
          <div className="h-6 w-6 animate-spin rounded-full border-2 border-maroon border-t-transparent" />
        </div>
      );
    }
    return (
      <div className="rounded-md bg-white p-8 text-center shadow-soft">
        <p className="text-charcoal-muted">Order not found.</p>
      </div>
    );
  }

  return (
    <div>
      <button onClick={() => router.push("/admin/orders")} className="mb-4 flex items-center gap-1.5 text-sm text-charcoal-muted hover:text-maroon">
        <ArrowLeft className="h-4 w-4" /> Back to Orders
      </button>

      <PageHeader
        title={order.orderNumber}
        description={`Placed on ${new Date(order.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}`}
        actions={
          <Button variant="outline" onClick={() => window.print()}>
            <Printer className="h-4 w-4" /> Print Invoice
          </Button>
        }
      />

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Items</h3>
            <div className="divide-y divide-beige-dark/40">
              {order.items.map((item, i) => (
                <div key={i} className="flex items-center gap-3 py-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={item.image} alt={item.name} className="h-14 w-14 rounded-md object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium text-charcoal">{item.name}</p>
                    <p className="text-xs text-charcoal-muted">
                      {item.size ? `Size: ${item.size} · ` : ""}Qty: {item.quantity}
                    </p>
                  </div>
                  <p className="font-medium text-charcoal">{formatPrice(item.price * item.quantity)}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 space-y-2 border-t border-beige-dark/60 pt-4 text-sm">
              <div className="flex justify-between text-charcoal-muted">
                <span>Subtotal</span>
                <span>{formatPrice(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-charcoal-muted">
                <span>Shipping</span>
                <span>{order.shipping === 0 ? "Free" : formatPrice(order.shipping)}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-charcoal-muted">
                  <span>Discount</span>
                  <span>-{formatPrice(order.discount)}</span>
                </div>
              )}
              <div className="flex justify-between border-t border-beige-dark/60 pt-2 font-display text-base font-semibold text-charcoal">
                <span>Total</span>
                <span>{formatPrice(order.total)}</span>
              </div>
            </div>
          </section>

          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Shipping Address</h3>
            <p className="text-sm text-charcoal">{order.shippingAddress}</p>
            <p className="mt-1 text-sm text-charcoal-muted">{order.phone}</p>
          </section>
        </div>

        <div className="space-y-5">
          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Order Status</h3>
            <div className="mb-4">
              <OrderStatusBadge status={order.status} />
            </div>
            <AdminSelect
              label="Update Status"
              value={order.status}
              onChange={async (e) => {
                const success = await updateStatus(order.id, e.target.value as OrderStatus);
                showToast(
                  success ? `Order marked as ${e.target.value}.` : "Failed to update order status.",
                  success ? "success" : "error"
                );
              }}
              options={statusOptions.map((s) => ({ label: s, value: s }))}
            />
          </section>

          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Customer</h3>
            <p className="font-medium text-charcoal">{order.customerName}</p>
            <p className="text-sm text-charcoal-muted">{order.customerEmail}</p>
            <p className="mt-3 text-sm text-charcoal-muted">Payment: {order.paymentMethod}</p>
          </section>
        </div>
      </div>
    </div>
  );
}
