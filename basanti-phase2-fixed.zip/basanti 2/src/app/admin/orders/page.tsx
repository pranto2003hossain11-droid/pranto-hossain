"use client";

import * as React from "react";
import Link from "next/link";
import { Eye } from "lucide-react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { DataTable, type Column } from "@/components/admin/ui/data-table";
import { AdminSelect } from "@/components/admin/ui/admin-input";
import { useOrdersStore } from "@/store/admin/orders-store";
import { formatPrice } from "@/lib/utils";
import type { Order, OrderStatus } from "@/lib/admin-types";

const statusOptions: OrderStatus[] = ["Pending", "Confirmed", "Processing", "Packed", "Shipped", "Delivered", "Cancelled", "Refunded"];

export default function AdminOrdersPage() {
  const orders = useOrdersStore((s) => s.orders);
  const fetchOrders = useOrdersStore((s) => s.fetchOrders);
  const updateStatus = useOrdersStore((s) => s.updateStatus);
  const [statusFilter, setStatusFilter] = React.useState("all");

  React.useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  const filtered = statusFilter === "all" ? orders : orders.filter((o) => o.status === statusFilter);

  const columns: Column<Order>[] = [
    { key: "order", header: "Order", sortValue: (o) => o.orderNumber, render: (o) => <span className="font-medium text-charcoal">{o.orderNumber}</span> },
    { key: "customer", header: "Customer", sortValue: (o) => o.customerName, render: (o) => (
      <div>
        <p className="text-charcoal">{o.customerName}</p>
        <p className="text-xs text-charcoal-muted">{o.customerEmail}</p>
      </div>
    ) },
    { key: "items", header: "Items", render: (o) => `${o.items.reduce((s, i) => s + i.quantity, 0)} items` },
    { key: "total", header: "Total", sortValue: (o) => o.total, render: (o) => formatPrice(o.total) },
    {
      key: "status",
      header: "Status",
      render: (o) => (
        <AdminSelect
          value={o.status}
          onChange={(e) => updateStatus(o.id, e.target.value as OrderStatus)}
          options={statusOptions.map((s) => ({ label: s, value: s }))}
          wrapperClassName="w-40"
          className="py-1.5 text-xs"
        />
      ),
    },
    { key: "date", header: "Date", sortValue: (o) => o.createdAt, render: (o) => new Date(o.createdAt).toLocaleDateString() },
    {
      key: "actions",
      header: "",
      render: (o) => (
        <Link href={`/admin/orders/${o.id}`} className="flex items-center justify-end gap-1 text-sm font-medium text-maroon hover:underline">
          <Eye className="h-4 w-4" /> View
        </Link>
      ),
      className: "text-right",
    },
  ];

  return (
    <div>
      <PageHeader title="Orders" description={`${orders.length} total orders`} />

      <div className="mb-4">
        <AdminSelect
          wrapperClassName="w-52"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          options={[{ label: "All Statuses", value: "all" }, ...statusOptions.map((s) => ({ label: s, value: s }))]}
        />
      </div>

      <DataTable
        columns={columns}
        rows={filtered}
        rowId={(o) => o.id}
        searchPlaceholder="Search by order number or customer..."
        searchKeys={(o) => `${o.orderNumber} ${o.customerName} ${o.customerEmail}`}
      />
    </div>
  );
}
