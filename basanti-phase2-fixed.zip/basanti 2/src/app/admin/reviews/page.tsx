"use client";

import * as React from "react";
import { Star, Trash2, CheckCircle2, XCircle } from "lucide-react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { DataTable, type Column } from "@/components/admin/ui/data-table";
import { ConfirmDialog } from "@/components/admin/ui/modal";
import { useReviewsStore } from "@/store/admin/reviews-store";
import { useProductsStore } from "@/store/admin/products-store";
import { useToastStore } from "@/store/admin/toast-store";
import type { Review } from "@/lib/types";

export default function AdminReviewsPage() {
  const reviews = useReviewsStore((s) => s.reviews);
  const toggleApproved = useReviewsStore((s) => s.toggleApproved);
  const deleteReview = useReviewsStore((s) => s.deleteReview);
  const products = useProductsStore((s) => s.products);
  const showToast = useToastStore((s) => s.show);
  const [toDelete, setToDelete] = React.useState<(Review & { approved: boolean }) | null>(null);

  const columns: Column<Review & { approved: boolean }>[] = [
    {
      key: "product",
      header: "Product",
      render: (r) => products.find((p) => p.id === r.productId)?.name ?? "Unknown product",
    },
    { key: "author", header: "Author", sortValue: (r) => r.author, render: (r) => r.author },
    {
      key: "rating",
      header: "Rating",
      sortValue: (r) => r.rating,
      render: (r) => (
        <div className="flex items-center gap-0.5">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star key={i} className={`h-3.5 w-3.5 ${i < r.rating ? "fill-gold text-gold" : "text-beige-dark"}`} />
          ))}
        </div>
      ),
    },
    { key: "text", header: "Review", render: (r) => <p className="max-w-md truncate text-charcoal-muted">{r.text}</p> },
    { key: "date", header: "Date", sortValue: (r) => r.date, render: (r) => new Date(r.date).toLocaleDateString() },
    {
      key: "status",
      header: "Status",
      render: (r) => (
        <button
          onClick={() => {
            toggleApproved(r.id);
            showToast(r.approved ? "Review hidden." : "Review approved.");
          }}
          className={`flex items-center gap-1 text-xs font-semibold ${r.approved ? "text-emerald-700" : "text-charcoal-muted"}`}
        >
          {r.approved ? <CheckCircle2 className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}
          {r.approved ? "Approved" : "Hidden"}
        </button>
      ),
    },
    {
      key: "actions",
      header: "",
      render: (r) => (
        <button onClick={() => setToDelete(r)} className="rounded-md p-2 text-charcoal-muted hover:bg-maroon-50 hover:text-maroon">
          <Trash2 className="h-4 w-4" />
        </button>
      ),
      className: "text-right",
    },
  ];

  return (
    <div>
      <PageHeader title="Reviews" description={`${reviews.length} customer reviews`} />
      <DataTable
        columns={columns}
        rows={reviews}
        rowId={(r) => r.id}
        searchPlaceholder="Search reviews..."
        searchKeys={(r) => `${r.author} ${r.text}`}
      />
      <ConfirmDialog
        open={Boolean(toDelete)}
        onClose={() => setToDelete(null)}
        onConfirm={() => {
          if (toDelete) {
            deleteReview(toDelete.id);
            showToast("Review deleted.");
          }
        }}
        title="Delete Review"
        description="Are you sure you want to permanently delete this review?"
      />
    </div>
  );
}
