"use client";

import * as React from "react";
import Link from "next/link";
import { Plus, Trash2, Pencil, GripVertical, Eye } from "lucide-react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { Modal, ConfirmDialog } from "@/components/admin/ui/modal";
import { AdminInput, Toggle } from "@/components/admin/ui/admin-input";
import { ImageDropzone } from "@/components/admin/ui/image-dropzone";
import { Button } from "@/components/ui/button";
import { useHeroStore } from "@/store/admin/hero-store";
import { useToastStore } from "@/store/admin/toast-store";
import type { HeroSlide } from "@/lib/admin-types";

const emptyForm = { image: "", title: "", subtitle: "", buttonText: "", buttonLink: "", enabled: true };

export default function AdminHeroPage() {
  const slides = useHeroStore((s) => s.slides);
  const addSlide = useHeroStore((s) => s.addSlide);
  const updateSlide = useHeroStore((s) => s.updateSlide);
  const deleteSlide = useHeroStore((s) => s.deleteSlide);
  const reorder = useHeroStore((s) => s.reorder);
  const showToast = useToastStore((s) => s.show);

  const [modalOpen, setModalOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<HeroSlide | null>(null);
  const [toDelete, setToDelete] = React.useState<HeroSlide | null>(null);
  const [form, setForm] = React.useState(emptyForm);
  const dragIndex = React.useRef<number | null>(null);

  const sorted = [...slides].sort((a, b) => a.sortOrder - b.sortOrder);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }

  function openEdit(slide: HeroSlide) {
    setEditing(slide);
    setForm({
      image: slide.image,
      title: slide.title,
      subtitle: slide.subtitle ?? "",
      buttonText: slide.buttonText ?? "",
      buttonLink: slide.buttonLink ?? "",
      enabled: slide.enabled,
    });
    setModalOpen(true);
  }

  function handleSave() {
    if (!form.image || !form.title.trim()) {
      showToast("Slide image and title are required.", "error");
      return;
    }
    if (editing) {
      updateSlide(editing.id, form);
      showToast("Slide updated.");
    } else {
      addSlide(form);
      showToast("Slide added.");
    }
    setModalOpen(false);
  }

  function handleDrop(targetIndex: number) {
    if (dragIndex.current === null || dragIndex.current === targetIndex) return;
    const ids = sorted.map((s) => s.id);
    const [moved] = ids.splice(dragIndex.current, 1);
    if (moved) ids.splice(targetIndex, 0, moved);
    reorder(ids);
    dragIndex.current = null;
  }

  return (
    <div>
      <PageHeader
        title="Hero Slider"
        description="Manage the homepage hero banners — no hardcoded images."
        actions={
          <>
            <Link href="/" target="_blank" className="inline-flex">
              <Button variant="outline">
                <Eye className="h-4 w-4" /> Preview Homepage
              </Button>
            </Link>
            <Button onClick={openCreate}>
              <Plus className="h-4 w-4" /> Add Slide
            </Button>
          </>
        }
      />

      <div className="space-y-3">
        {sorted.length === 0 && (
          <div className="rounded-md bg-white p-8 text-center shadow-soft">
            <p className="text-charcoal-muted">No slides yet. Add your first slide.</p>
          </div>
        )}
        {sorted.map((slide, index) => (
          <div
            key={slide.id}
            draggable
            onDragStart={() => (dragIndex.current = index)}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => handleDrop(index)}
            className="flex items-center gap-4 rounded-md bg-white p-4 shadow-soft"
          >
            <span className="cursor-grab text-charcoal-muted">
              <GripVertical className="h-5 w-5" />
            </span>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={slide.image} alt={slide.title} className="h-16 w-28 rounded-md object-cover" />
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium text-charcoal">{slide.title}</p>
              <p className="truncate text-xs text-charcoal-muted">{slide.subtitle}</p>
            </div>
            <Toggle checked={slide.enabled} onChange={() => updateSlide(slide.id, { enabled: !slide.enabled })} />
            <button onClick={() => openEdit(slide)} className="rounded-md p-2 text-charcoal-muted hover:bg-beige hover:text-charcoal">
              <Pencil className="h-4 w-4" />
            </button>
            <button onClick={() => setToDelete(slide)} className="rounded-md p-2 text-charcoal-muted hover:bg-maroon-50 hover:text-maroon">
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Slide" : "Add Slide"} size="lg">
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-sm font-medium text-charcoal">Slide Image</label>
            <ImageDropzone images={form.image ? [form.image] : []} onChange={(imgs) => setForm((f) => ({ ...f, image: imgs[imgs.length - 1] ?? "" }))} maxImages={1} />
          </div>
          <AdminInput label="Title" required value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
          <AdminInput label="Subtitle" value={form.subtitle} onChange={(e) => setForm((f) => ({ ...f, subtitle: e.target.value }))} />
          <div className="grid grid-cols-2 gap-4">
            <AdminInput label="Button Text" value={form.buttonText} onChange={(e) => setForm((f) => ({ ...f, buttonText: e.target.value }))} />
            <AdminInput label="Button Link" value={form.buttonLink} onChange={(e) => setForm((f) => ({ ...f, buttonLink: e.target.value }))} placeholder="/shop" />
          </div>
          <Toggle label="Enabled" checked={form.enabled} onChange={(v) => setForm((f) => ({ ...f, enabled: v }))} />
          <Button className="w-full" size="lg" onClick={handleSave}>
            {editing ? "Save Changes" : "Add Slide"}
          </Button>
        </div>
      </Modal>

      <ConfirmDialog
        open={Boolean(toDelete)}
        onClose={() => setToDelete(null)}
        onConfirm={() => {
          if (toDelete) {
            deleteSlide(toDelete.id);
            showToast("Slide deleted.");
          }
        }}
        title="Delete Slide"
        description={`Are you sure you want to delete "${toDelete?.title}"?`}
      />
    </div>
  );
}
