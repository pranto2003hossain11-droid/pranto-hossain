"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AdminInput } from "@/components/admin/ui/admin-input";
import { useAdminAuthStore } from "@/store/admin/admin-auth-store";

export default function AdminLoginPage() {
  const router = useRouter();
  const login = useAdminAuthStore((s) => s.login);
  const isAuthenticated = useAdminAuthStore((s) => s.isAuthenticated);
  const checkSession = useAdminAuthStore((s) => s.checkSession);
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [error, setError] = React.useState("");
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    checkSession();
  }, [checkSession]);

  React.useEffect(() => {
    if (isAuthenticated) router.replace("/admin/dashboard");
  }, [isAuthenticated, router]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const result = await login(email, password);
    setLoading(false);
    if (!result.success) {
      setError(result.error ?? "Invalid email or password. Please try again.");
      return;
    }
    router.push("/admin/dashboard");
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-charcoal px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-md bg-gold font-display text-2xl font-semibold text-charcoal">
            B
          </div>
          <h1 className="font-display text-2xl font-semibold text-ivory">Basanti Admin</h1>
          <p className="mt-1 text-sm text-ivory/60">Sign in to manage your boutique</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 rounded-md bg-white p-7 shadow-elevated">
          <AdminInput
            label="Email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="admin@basantiboutiques.com"
          />
          <AdminInput
            label="Password"
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
          />
          {error && <p className="text-sm font-medium text-maroon-600">{error}</p>}
          <Button type="submit" size="lg" className="w-full" isLoading={loading}>
            <Lock className="h-4 w-4" /> Sign In
          </Button>
        </form>

        <Link href="/" className="mt-6 block text-center text-sm text-ivory/60 hover:text-ivory">
          ← Back to Basanti Boutiques &amp; House
        </Link>
      </div>
    </div>
  );
}
