"use client";

import * as React from "react";
import { Plus, Trash2, Pencil } from "lucide-react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { DataTable, type Column } from "@/components/admin/ui/data-table";
import { Modal, ConfirmDialog } from "@/components/admin/ui/modal";
import { AdminInput, AdminSelect, Toggle } from "@/components/admin/ui/admin-input";
import { Button } from "@/components/ui/button";
import { useCouponsStore } from "@/store/admin/coupons-store";
import { useToastStore } from "@/store/admin/toast-store";
import type { Coupon } from "@/lib/admin-types";

const emptyForm = {
  code: "",
  type: "percentage" as "percentage" | "fixed",
  value: 0,
  minOrder: 0,
  usageLimit: 100,
  expiryDate: "",
  enabled: true,
};

export default function AdminCouponsPage() {
  const coupons = useCouponsStore((s) => s.coupons);
  const fetchCoupons = useCouponsStore((s) => s.fetchCoupons);
  const addCoupon = useCouponsStore((s) => s.addCoupon);
  const updateCoupon = useCouponsStore((s) => s.updateCoupon);
  const deleteCoupon = useCouponsStore((s) => s.deleteCoupon);
  const toggleEnabled = useCouponsStore((s) => s.toggleEnabled);
  const showToast = useToastStore((s) => s.show);

  React.useEffect(() => {
    fetchCoupons();
  }, [fetchCoupons]);

  const [modalOpen, setModalOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Coupon | null>(null);
  const [toDelete, setToDelete] = React.useState<Coupon | null>(null);
  const [form, setForm] = React.useState(emptyForm);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }

  function openEdit(c: Coupon) {
    setEditing(c);
    setForm({
      code: c.code,
      type: c.type,
      value: c.value,
      minOrder: c.minOrder ?? 0,
      usageLimit: c.usageLimit ?? 0,
      expiryDate: c.expiryDate ?? "",
      enabled: c.enabled,
    });
    setModalOpen(true);
  }

  async function handleSave() {
    if (!form.code.trim()) {
      showToast("Coupon code is required.", "error");
      return;
    }
    if (editing) {
      const success = await updateCoupon(editing.id, { ...form, code: form.code.toUpperCase() });
      showToast(success ? "Coupon updated." : "Failed to update coupon.", success ? "success" : "error");
    } else {
      const success = await addCoupon({ ...form, code: form.code.toUpperCase() });
      showToast(success ? "Coupon created." : "Failed to create coupon.", success ? "success" : "error");
    }
    setModalOpen(false);
  }

  const columns: Column<Coupon>[] = [
    { key: "code", header: "Code", sortValue: (c) => c.code, render: (c) => <span className="font-mono font-semibold text-charcoal">{c.code}</span> },
    {
      key: "discount",
      header: "Discount",
      render: (c) => (c.type === "percentage" ? `${c.value}% off` : `৳${c.value} off`),
    },
    { key: "minOrder", header: "Min Order", render: (c) => (c.minOrder ? `৳${c.minOrder}` : "—") },
    { key: "usage", header: "Usage", render: (c) => `${c.usedCount} / ${c.usageLimit ?? "∞"}` },
    { key: "expiry", header: "Expires", render: (c) => (c.expiryDate ? new Date(c.expiryDate).toLocaleDateString() : "—") },
    {
      key: "enabled",
      header: "Status",
      render: (c) => (
        <Toggle
          checked={c.enabled}
          onChange={async () => {
            const success = await toggleEnabled(c.id);
            if (success) showToast(c.enabled ? "Coupon disabled." : "Coupon enabled.");
          }}
        />
      ),
    },
    {
      key: "actions",
      header: "",
      render: (c) => (
        <div className="flex items-center justify-end gap-1">
          <button onClick={() => openEdit(c)} className="rounded-md p-2 text-charcoal-muted hover:bg-beige hover:text-charcoal">
            <Pencil className="h-4 w-4" />
          </button>
          <button onClick={() => setToDelete(c)} className="rounded-md p-2 text-charcoal-muted hover:bg-maroon-50 hover:text-maroon">
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      ),
      className: "text-right",
    },
  ];

  return (
    <div>
      <PageHeader
        title="Coupons"
        description={`${coupons.length} coupon codes`}
        actions={
          <Button onClick={openCreate}>
            <Plus className="h-4 w-4" /> Add Coupon
          </Button>
        }
      />

      <DataTable columns={columns} rows={coupons} rowId={(c) => c.id} searchPlaceholder="Search coupons..." searchKeys={(c) => c.code} />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Coupon" : "Add Coupon"}>
        <div className="space-y-4">
          <AdminInput
            label="Coupon Code"
            required
            value={form.code}
            onChange={(e) => setForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))}
            placeholder="e.g. WELCOME10"
          />
          <div className="grid grid-cols-2 gap-4">
            <AdminSelect
              label="Discount Type"
              value={form.type}
              onChange={(e) => setForm((f) => ({ ...f, type: e.target.value as "percentage" | "fixed" }))}
              options={[
                { label: "Percentage (%)", value: "percentage" },
                { label: "Fixed Amount (৳)", value: "fixed" },
              ]}
            />
            <AdminInput
              label="Value"
              type="number"
              min={0}
              value={form.value}
              onChange={(e) => setForm((f) => ({ ...f, value: Number(e.target.value) }))}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <AdminInput
              label="Minimum Order (৳)"
              type="number"
              min={0}
              value={form.minOrder}
              onChange={(e) => setForm((f) => ({ ...f, minOrder: Number(e.target.value) }))}
            />
            <AdminInput
              label="Usage Limit"
              type="number"
              min={0}
              value={form.usageLimit}
              onChange={(e) => setForm((f) => ({ ...f, usageLimit: Number(e.target.value) }))}
            />
          </div>
          <AdminInput
            label="Expiry Date"
            type="date"
            value={form.expiryDate}
            onChange={(e) => setForm((f) => ({ ...f, expiryDate: e.target.value }))}
          />
          <Toggle label="Enabled" checked={form.enabled} onChange={(v) => setForm((f) => ({ ...f, enabled: v }))} />
          <Button className="w-full" size="lg" onClick={handleSave}>
            {editing ? "Save Changes" : "Create Coupon"}
          </Button>
        </div>
      </Modal>

      <ConfirmDialog
        open={Boolean(toDelete)}
        onClose={() => setToDelete(null)}
        onConfirm={() => {
          if (toDelete) {
            deleteCoupon(toDelete.id);
            showToast("Coupon deleted.");
          }
        }}
        title="Delete Coupon"
        description={`Are you sure you want to delete "${toDelete?.code}"?`}
      />
    </div>
  );
}
