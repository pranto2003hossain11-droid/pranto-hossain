"use client";

import * as React from "react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { AdminInput, AdminTextarea } from "@/components/admin/ui/admin-input";
import { ImageDropzone } from "@/components/admin/ui/image-dropzone";
import { Button } from "@/components/ui/button";
import { useSettingsStore } from "@/store/admin/settings-store";
import { useToastStore } from "@/store/admin/toast-store";
import type { StoreSettings } from "@/lib/admin-types";

export default function AdminSettingsPage() {
  const settings = useSettingsStore((s) => s.settings);
  const isLoading = useSettingsStore((s) => s.isLoading);
  const fetchSettings = useSettingsStore((s) => s.fetchSettings);
  const updateSettings = useSettingsStore((s) => s.updateSettings);
  const showToast = useToastStore((s) => s.show);
  const [form, setForm] = React.useState<StoreSettings | null>(settings);
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    fetchSettings();
  }, [fetchSettings]);

  React.useEffect(() => setForm(settings), [settings]);

  function set<K extends keyof StoreSettings>(key: K, value: StoreSettings[K]) {
    setForm((f) => (f ? { ...f, [key]: value } : f));
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setSaving(true);
    const success = await updateSettings(form);
    setSaving(false);
    showToast(success ? "Settings saved." : "Failed to save settings.");
  }

  if (isLoading || !form) {
    return (
      <div>
        <PageHeader title="Settings" description="Store configuration and preferences" />
        <div className="flex h-40 items-center justify-center rounded-md bg-white shadow-soft">
          <div className="h-6 w-6 animate-spin rounded-full border-2 border-maroon border-t-transparent" />
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Settings" description="Store configuration and preferences" />

      <form onSubmit={handleSave} className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Store Information</h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <AdminInput label="Store Name" value={form.storeName} onChange={(e) => set("storeName", e.target.value)} wrapperClassName="sm:col-span-2" />
              <AdminInput label="Phone" value={form.phone} onChange={(e) => set("phone", e.target.value)} />
              <AdminInput label="Email" type="email" value={form.email} onChange={(e) => set("email", e.target.value)} />
              <AdminTextarea label="Address" rows={2} value={form.address} onChange={(e) => set("address", e.target.value)} wrapperClassName="sm:col-span-2" />
            </div>
          </section>

          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Social Links</h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <AdminInput label="Facebook" value={form.facebook ?? ""} onChange={(e) => set("facebook", e.target.value)} />
              <AdminInput label="Instagram" value={form.instagram ?? ""} onChange={(e) => set("instagram", e.target.value)} />
              <AdminInput label="WhatsApp" value={form.whatsapp ?? ""} onChange={(e) => set("whatsapp", e.target.value)} />
            </div>
          </section>

          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Shipping & Currency</h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <AdminInput label="Shipping Charge (৳)" type="number" min={0} value={form.shippingCharge} onChange={(e) => set("shippingCharge", Number(e.target.value))} />
              <AdminInput label="Free Shipping Above (৳)" type="number" min={0} value={form.freeShippingThreshold} onChange={(e) => set("freeShippingThreshold", Number(e.target.value))} />
              <AdminInput label="Currency" value={form.currency} onChange={(e) => set("currency", e.target.value)} />
            </div>
          </section>

          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-4 font-display text-base font-semibold text-charcoal">SEO & Analytics</h3>
            <div className="space-y-4">
              <AdminInput label="SEO Title" value={form.seoTitle} onChange={(e) => set("seoTitle", e.target.value)} />
              <AdminTextarea label="SEO Description" rows={3} value={form.seoDescription} onChange={(e) => set("seoDescription", e.target.value)} />
              <AdminInput label="Analytics ID" value={form.analyticsId ?? ""} onChange={(e) => set("analyticsId", e.target.value)} placeholder="G-XXXXXXXXXX" />
            </div>
          </section>
        </div>

        <div className="space-y-5">
          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-3 font-display text-base font-semibold text-charcoal">Logo</h3>
            <ImageDropzone images={form.logo ? [form.logo] : []} onChange={(imgs) => set("logo", imgs[imgs.length - 1] ?? "")} maxImages={1} />
          </section>
          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-3 font-display text-base font-semibold text-charcoal">Favicon</h3>
            <ImageDropzone images={form.favicon ? [form.favicon] : []} onChange={(imgs) => set("favicon", imgs[imgs.length - 1] ?? "")} maxImages={1} />
          </section>
          <Button type="submit" size="lg" className="w-full" isLoading={saving}>
            Save Settings
          </Button>
        </div>
      </form>
    </div>
  );
}
