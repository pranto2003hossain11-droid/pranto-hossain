"use client";

import * as React from "react";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";
import { PageHeader } from "@/components/admin/ui/page-header";
import { OrderStatusBadge } from "@/components/admin/ui/status-badge";
import { Toggle } from "@/components/admin/ui/admin-input";
import { useCustomersStore } from "@/store/admin/customers-store";
import { useOrdersStore } from "@/store/admin/orders-store";
import { useToastStore } from "@/store/admin/toast-store";
import { formatPrice } from "@/lib/utils";

export default function AdminCustomerDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const getCustomer = useCustomersStore((s) => s.getCustomer);
  const fetchCustomers = useCustomersStore((s) => s.fetchCustomers);
  const isLoading = useCustomersStore((s) => s.isLoading);
  const toggleStatus = useCustomersStore((s) => s.toggleStatus);
  const orders = useOrdersStore((s) => s.orders);
  const fetchOrders = useOrdersStore((s) => s.fetchOrders);
  const showToast = useToastStore((s) => s.show);
  const customer = getCustomer(params.id);

  React.useEffect(() => {
    fetchCustomers();
    fetchOrders();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!customer) {
    if (isLoading) {
      return (
        <div className="flex h-40 items-center justify-center rounded-md bg-white shadow-soft">
          <div className="h-6 w-6 animate-spin rounded-full border-2 border-maroon border-t-transparent" />
        </div>
      );
    }
    return (
      <div className="rounded-md bg-white p-8 text-center shadow-soft">
        <p className="text-charcoal-muted">Customer not found.</p>
      </div>
    );
  }

  const customerOrders = orders.filter((o) => o.customerId === customer.id);

  return (
    <div>
      <button onClick={() => router.push("/admin/customers")} className="mb-4 flex items-center gap-1.5 text-sm text-charcoal-muted hover:text-maroon">
        <ArrowLeft className="h-4 w-4" /> Back to Customers
      </button>

      <PageHeader title={customer.name} description={customer.email} />

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <section className="rounded-md bg-white shadow-soft">
            <div className="border-b border-beige-dark/60 px-5 py-4">
              <h3 className="font-display text-base font-semibold text-charcoal">Order History</h3>
            </div>
            <div className="divide-y divide-beige-dark/40">
              {customerOrders.length === 0 ? (
                <p className="px-5 py-6 text-sm text-charcoal-muted">No orders yet.</p>
              ) : (
                customerOrders.map((o) => (
                  <Link key={o.id} href={`/admin/orders/${o.id}`} className="flex items-center justify-between px-5 py-3.5 text-sm hover:bg-ivory/60">
                    <div>
                      <p className="font-medium text-charcoal">{o.orderNumber}</p>
                      <p className="text-xs text-charcoal-muted">{new Date(o.createdAt).toLocaleDateString()}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-charcoal">{formatPrice(o.total)}</p>
                      <OrderStatusBadge status={o.status} />
                    </div>
                  </Link>
                ))
              )}
            </div>
          </section>
        </div>

        <div className="space-y-5">
          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-3 font-display text-base font-semibold text-charcoal">Details</h3>
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between"><dt className="text-charcoal-muted">Phone</dt><dd className="text-charcoal">{customer.phone ?? "—"}</dd></div>
              <div className="flex justify-between"><dt className="text-charcoal-muted">Address</dt><dd className="text-right text-charcoal">{customer.address ?? "—"}</dd></div>
              <div className="flex justify-between"><dt className="text-charcoal-muted">Orders</dt><dd className="text-charcoal">{customer.ordersCount}</dd></div>
              <div className="flex justify-between"><dt className="text-charcoal-muted">Total Spent</dt><dd className="text-charcoal">{formatPrice(customer.totalSpent)}</dd></div>
              <div className="flex justify-between"><dt className="text-charcoal-muted">Joined</dt><dd className="text-charcoal">{new Date(customer.joinedAt).toLocaleDateString()}</dd></div>
            </dl>
          </section>

          <section className="rounded-md bg-white p-5 shadow-soft">
            <h3 className="mb-3 font-display text-base font-semibold text-charcoal">Account Status</h3>
            <Toggle
              label={customer.status === "active" ? "Active" : "Deactivated"}
              checked={customer.status === "active"}
              onChange={() => {
                toggleStatus(customer.id);
                showToast(customer.status === "active" ? "Customer deactivated." : "Customer reactivated.");
              }}
            />
          </section>
        </div>
      </div>
    </div>
  );
}
