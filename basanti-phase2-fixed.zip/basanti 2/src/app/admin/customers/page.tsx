"use client";

import * as React from "react";
import Link from "next/link";
import { Eye } from "lucide-react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { DataTable, type Column } from "@/components/admin/ui/data-table";
import { Toggle } from "@/components/admin/ui/admin-input";
import { useCustomersStore } from "@/store/admin/customers-store";
import { useToastStore } from "@/store/admin/toast-store";
import { formatPrice } from "@/lib/utils";
import type { Customer } from "@/lib/admin-types";

export default function AdminCustomersPage() {
  const customers = useCustomersStore((s) => s.customers);
  const fetchCustomers = useCustomersStore((s) => s.fetchCustomers);
  const toggleStatus = useCustomersStore((s) => s.toggleStatus);
  const showToast = useToastStore((s) => s.show);

  React.useEffect(() => {
    fetchCustomers();
  }, [fetchCustomers]);

  const columns: Column<Customer>[] = [
    {
      key: "customer",
      header: "Customer",
      sortValue: (c) => c.name,
      render: (c) => (
        <div className="flex items-center gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={c.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(c.name)}&background=6B1424&color=fff`}
            alt={c.name}
            className="h-10 w-10 rounded-full object-cover"
          />
          <div>
            <p className="font-medium text-charcoal">{c.name}</p>
            <p className="text-xs text-charcoal-muted">{c.email}</p>
          </div>
        </div>
      ),
    },
    { key: "phone", header: "Phone", render: (c) => c.phone ?? "—" },
    { key: "orders", header: "Orders", sortValue: (c) => c.ordersCount, render: (c) => c.ordersCount },
    { key: "spent", header: "Total Spent", sortValue: (c) => c.totalSpent, render: (c) => formatPrice(c.totalSpent) },
    { key: "joined", header: "Joined", sortValue: (c) => c.joinedAt, render: (c) => new Date(c.joinedAt).toLocaleDateString() },
    {
      key: "status",
      header: "Status",
      render: (c) => (
        <Toggle
          checked={c.status === "active"}
          onChange={async () => {
            const success = await toggleStatus(c.id);
            if (success) {
              showToast(c.status === "active" ? `${c.name} deactivated.` : `${c.name} reactivated.`);
            } else {
              showToast("Failed to update customer status.", "error");
            }
          }}
        />
      ),
    },
    {
      key: "actions",
      header: "",
      render: (c) => (
        <Link href={`/admin/customers/${c.id}`} className="flex items-center justify-end gap-1 text-sm font-medium text-maroon hover:underline">
          <Eye className="h-4 w-4" /> View
        </Link>
      ),
      className: "text-right",
    },
  ];

  return (
    <div>
      <PageHeader title="Customers" description={`${customers.length} registered customers`} />
      <DataTable
        columns={columns}
        rows={customers}
        rowId={(c) => c.id}
        searchPlaceholder="Search customers..."
        searchKeys={(c) => `${c.name} ${c.email}`}
      />
    </div>
  );
}
