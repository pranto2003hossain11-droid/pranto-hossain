"use client";

import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/admin/ui/page-header";
import { ProductForm, productToFormValues, type ProductFormValues } from "@/components/admin/products/product-form";
import { useProductsStore } from "@/store/admin/products-store";
import { useCategoriesStore } from "@/store/admin/categories-store";
import { useToastStore } from "@/store/admin/toast-store";

export default function NewProductPage() {
  const router = useRouter();
  const addProduct = useProductsStore((s) => s.addProduct);
  const categories = useCategoriesStore((s) => s.categories);
  const showToast = useToastStore((s) => s.show);

  async function handleSubmit(values: ProductFormValues) {
    const categoryId = categories.find((c) => c.name === values.category)?.id;
    const created = await addProduct({
      name: values.name,
      slug: values.slug,
      sku: values.sku,
      brand: values.brand,
      category: values.category,
      categoryId,
      price: values.price,
      compareAtPrice: values.compareAtPrice,
      stock: values.stock,
      sizes: values.sizes,
      colors: values.colors,
      image: values.images[0] ?? "",
      images: values.images,
      description: values.description,
      specifications: values.specifications.filter((s) => s.label && s.value),
      seoTitle: values.seoTitle,
      seoDescription: values.seoDescription,
      status: values.status,
      visibility: values.visibility,
      isNew: values.isNew,
      isBestSeller: values.isBestSeller,
      rating: 0,
      reviewCount: 0,
    });
    if (!created) {
      showToast("Failed to create product.", "error");
      return;
    }
    showToast(`"${created.name}" was created.`);
    router.push("/admin/products");
  }

  return (
    <div>
      <PageHeader title="Add Product" description="Create a new product for your catalog" />
      <ProductForm initial={productToFormValues()} onSubmit={handleSubmit} submitLabel="Create Product" />
    </div>
  );
}
