"use client";

import * as React from "react";
import Link from "next/link";
import { Plus, Copy, Trash2, Pencil, Filter } from "lucide-react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { DataTable, type Column } from "@/components/admin/ui/data-table";
import { ProductStatusBadge } from "@/components/admin/ui/status-badge";
import { ConfirmDialog } from "@/components/admin/ui/modal";
import { AdminSelect } from "@/components/admin/ui/admin-input";
import { Button } from "@/components/ui/button";
import { useProductsStore } from "@/store/admin/products-store";
import { useCategoriesStore } from "@/store/admin/categories-store";
import { useToastStore } from "@/store/admin/toast-store";
import { formatPrice } from "@/lib/utils";
import type { Product } from "@/lib/types";

export default function AdminProductsPage() {
  const products = useProductsStore((s) => s.products);
  const fetchProducts = useProductsStore((s) => s.fetchProducts);
  const deleteProduct = useProductsStore((s) => s.deleteProduct);
  const deleteProducts = useProductsStore((s) => s.deleteProducts);
  const duplicateProduct = useProductsStore((s) => s.duplicateProduct);
  const categories = useCategoriesStore((s) => s.categories);
  const fetchCategories = useCategoriesStore((s) => s.fetchCategories);
  const showToast = useToastStore((s) => s.show);

  React.useEffect(() => {
    fetchProducts();
    fetchCategories();
  }, [fetchProducts, fetchCategories]);

  const [categoryFilter, setCategoryFilter] = React.useState("all");
  const [statusFilter, setStatusFilter] = React.useState("all");
  const [selected, setSelected] = React.useState<string[]>([]);
  const [toDelete, setToDelete] = React.useState<Product | null>(null);
  const [bulkDeleteOpen, setBulkDeleteOpen] = React.useState(false);

  const filtered = products.filter((p) => {
    if (categoryFilter !== "all" && p.category !== categoryFilter) return false;
    if (statusFilter === "published" && p.status === "draft") return false;
    if (statusFilter === "draft" && p.status !== "draft") return false;
    if (statusFilter === "low-stock" && p.stock > 5) return false;
    return true;
  });

  const columns: Column<Product>[] = [
    {
      key: "product",
      header: "Product",
      sortValue: (p) => p.name,
      render: (p) => (
        <div className="flex items-center gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={p.image} alt={p.name} className="h-11 w-11 rounded-md object-cover" />
          <div className="min-w-0">
            <p className="truncate font-medium text-charcoal">{p.name}</p>
            <p className="text-xs text-charcoal-muted">{p.sku || p.slug}</p>
          </div>
        </div>
      ),
    },
    { key: "category", header: "Category", sortValue: (p) => p.category, render: (p) => p.category },
    { key: "price", header: "Price", sortValue: (p) => p.price, render: (p) => formatPrice(p.price) },
    {
      key: "stock",
      header: "Stock",
      sortValue: (p) => p.stock,
      render: (p) => (
        <span className={p.stock <= 5 ? "font-semibold text-maroon-600" : ""}>{p.stock}</span>
      ),
    },
    { key: "status", header: "Status", render: (p) => <ProductStatusBadge status={p.status ?? "published"} /> },
    {
      key: "actions",
      header: "",
      render: (p) => (
        <div className="flex items-center justify-end gap-1">
          <Link href={`/admin/products/edit/${p.id}`} className="rounded-md p-2 text-charcoal-muted hover:bg-beige hover:text-charcoal">
            <Pencil className="h-4 w-4" />
          </Link>
          <button
            onClick={async () => {
              const success = await duplicateProduct(p.id);
              showToast(success ? "Product duplicated as draft." : "Failed to duplicate product.", success ? "success" : "error");
            }}
            className="rounded-md p-2 text-charcoal-muted hover:bg-beige hover:text-charcoal"
          >
            <Copy className="h-4 w-4" />
          </button>
          <button onClick={() => setToDelete(p)} className="rounded-md p-2 text-charcoal-muted hover:bg-maroon-50 hover:text-maroon">
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      ),
      className: "text-right",
    },
  ];

  return (
    <div>
      <PageHeader
        title="Products"
        description={`${products.length} products in your catalog`}
        actions={
          <Link href="/admin/products/new" className="inline-flex">
            <Button>
              <Plus className="h-4 w-4" /> Add Product
            </Button>
          </Link>
        }
      />

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 text-sm text-charcoal-muted">
          <Filter className="h-4 w-4" /> Filters:
        </div>
        <AdminSelect
          wrapperClassName="w-44"
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          options={[{ label: "All Categories", value: "all" }, ...categories.map((c) => ({ label: c.name, value: c.name }))]}
        />
        <AdminSelect
          wrapperClassName="w-44"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          options={[
            { label: "All Status", value: "all" },
            { label: "Published", value: "published" },
            { label: "Draft", value: "draft" },
            { label: "Low Stock", value: "low-stock" },
          ]}
        />
      </div>

      <DataTable
        columns={columns}
        rows={filtered}
        rowId={(p) => p.id}
        searchPlaceholder="Search products..."
        searchKeys={(p) => `${p.name} ${p.sku ?? ""} ${p.category}`}
        selectable
        selectedIds={selected}
        onSelectionChange={setSelected}
        toolbar={
          selected.length > 0 ? (
            <Button variant="outline" size="sm" onClick={() => setBulkDeleteOpen(true)}>
              <Trash2 className="h-4 w-4" /> Delete ({selected.length})
            </Button>
          ) : undefined
        }
      />

      <ConfirmDialog
        open={Boolean(toDelete)}
        onClose={() => setToDelete(null)}
        onConfirm={async () => {
          if (toDelete) {
            const success = await deleteProduct(toDelete.id);
            showToast(success ? "Product deleted." : "Failed to delete product.", success ? "success" : "error");
            setToDelete(null);
          }
        }}
        title="Delete Product"
        description={`Are you sure you want to delete "${toDelete?.name}"? This cannot be undone.`}
      />

      <ConfirmDialog
        open={bulkDeleteOpen}
        onClose={() => setBulkDeleteOpen(false)}
        onConfirm={async () => {
          const count = selected.length;
          const success = await deleteProducts(selected);
          showToast(success ? `${count} products deleted.` : "Failed to delete some products.", success ? "success" : "error");
          setSelected([]);
          setBulkDeleteOpen(false);
        }}
        title="Delete Selected Products"
        description={`Are you sure you want to delete ${selected.length} selected products? This cannot be undone.`}
      />
    </div>
  );
}
