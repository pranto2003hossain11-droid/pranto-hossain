"use client";

import * as React from "react";
import { useParams, useRouter } from "next/navigation";
import { PageHeader } from "@/components/admin/ui/page-header";
import { ProductForm, productToFormValues, type ProductFormValues } from "@/components/admin/products/product-form";
import { useProductsStore } from "@/store/admin/products-store";
import { useCategoriesStore } from "@/store/admin/categories-store";
import { useToastStore } from "@/store/admin/toast-store";

export default function EditProductPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const getProduct = useProductsStore((s) => s.getProduct);
  const updateProduct = useProductsStore((s) => s.updateProduct);
  const isLoading = useProductsStore((s) => s.isLoading);
  const categories = useCategoriesStore((s) => s.categories);
  const showToast = useToastStore((s) => s.show);
  const product = getProduct(params.id);

  async function handleSubmit(values: ProductFormValues) {
    if (!product) return;
    const categoryId = categories.find((c) => c.name === values.category)?.id;
    const success = await updateProduct(product.id, {
      name: values.name,
      slug: values.slug,
      sku: values.sku,
      brand: values.brand,
      category: values.category,
      categoryId,
      price: values.price,
      compareAtPrice: values.compareAtPrice,
      stock: values.stock,
      sizes: values.sizes,
      colors: values.colors,
      image: values.images[0] ?? product.image,
      images: values.images,
      description: values.description,
      specifications: values.specifications.filter((s) => s.label && s.value),
      seoTitle: values.seoTitle,
      seoDescription: values.seoDescription,
      status: values.status,
      visibility: values.visibility,
      isNew: values.isNew,
      isBestSeller: values.isBestSeller,
    });
    showToast(success ? "Product updated successfully." : "Failed to update product.", success ? "success" : "error");
    if (success) router.push("/admin/products");
  }

  if (!product) {
    if (isLoading) {
      return (
        <div className="flex h-40 items-center justify-center rounded-md bg-white shadow-soft">
          <div className="h-6 w-6 animate-spin rounded-full border-2 border-maroon border-t-transparent" />
        </div>
      );
    }
    return (
      <div className="rounded-md bg-white p-8 text-center shadow-soft">
        <p className="text-charcoal-muted">Product not found. It may have been deleted.</p>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Edit Product" description={product.name} />
      <ProductForm initial={productToFormValues(product)} onSubmit={handleSubmit} submitLabel="Save Changes" />
    </div>
  );
}
