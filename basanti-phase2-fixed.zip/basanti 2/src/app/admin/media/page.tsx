"use client";

import * as React from "react";
import { UploadCloud, Trash2, Copy, Search, Folder } from "lucide-react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { ConfirmDialog } from "@/components/admin/ui/modal";
import { useMediaStore } from "@/store/admin/media-store";
import { useToastStore } from "@/store/admin/toast-store";
import { cn } from "@/lib/utils";
import type { MediaItem } from "@/lib/admin-types";

export default function AdminMediaPage() {
  const items = useMediaStore((s) => s.items);
  const fetchMedia = useMediaStore((s) => s.fetchMedia);
  const uploadFiles = useMediaStore((s) => s.uploadFiles);
  const deleteItem = useMediaStore((s) => s.deleteItem);
  const showToast = useToastStore((s) => s.show);

  const [query, setQuery] = React.useState("");
  const [folder, setFolder] = React.useState("all");
  const [toDelete, setToDelete] = React.useState<MediaItem | null>(null);
  const [uploading, setUploading] = React.useState(false);
  const inputRef = React.useRef<HTMLInputElement>(null);
  const replaceInputRef = React.useRef<HTMLInputElement>(null);
  const replaceTarget = React.useRef<MediaItem | null>(null);

  React.useEffect(() => {
    fetchMedia();
  }, [fetchMedia]);

  const folders = Array.from(new Set(items.map((i) => i.folder)));

  const filtered = items.filter((i) => {
    if (folder !== "all" && i.folder !== folder) return false;
    if (query && !i.name.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  });

  async function handleUpload(fileList: FileList | null) {
    if (!fileList || fileList.length === 0) return;
    setUploading(true);
    const files = Array.from(fileList);
    const success = await uploadFiles(files, folder === "all" ? "uploads" : folder);
    setUploading(false);
    showToast(success ? `${files.length} file(s) uploaded.` : "Upload failed. Please try again.");
  }

  async function handleReplace(fileList: FileList | null) {
    const target = replaceTarget.current;
    if (!fileList?.[0] || !target) return;
    setUploading(true);
    const uploaded = await uploadFiles([fileList[0]], target.folder);
    if (uploaded) {
      const result = await deleteItem(target.id);
      showToast(
        result.success
          ? "Media replaced."
          : `New file uploaded, but the old one is still in use: ${result.error}`
      );
    } else {
      showToast("Upload failed. Please try again.");
    }
    setUploading(false);
    replaceTarget.current = null;
  }

  function copyUrl(url: string) {
    navigator.clipboard?.writeText(url).then(() => showToast("URL copied to clipboard."));
  }

  function formatSize(bytes: number) {
    return bytes > 1024 * 1024 ? `${(bytes / (1024 * 1024)).toFixed(1)} MB` : `${(bytes / 1024).toFixed(0)} KB`;
  }

  return (
    <div>
      <PageHeader
        title="Media Library"
        description="Upload and manage the images used across your storefront and admin panel."
        actions={
          <button
            onClick={() => inputRef.current?.click()}
            disabled={uploading}
            className="inline-flex items-center gap-2 rounded-md bg-maroon px-4 py-2.5 text-sm font-medium text-ivory shadow-soft hover:bg-maroon-600 disabled:opacity-60"
          >
            <UploadCloud className="h-4 w-4" /> {uploading ? "Uploading..." : "Upload"}
          </button>
        }
      />
      <input ref={inputRef} type="file" accept="image/*" multiple hidden onChange={(e) => handleUpload(e.target.files)} />
      <input ref={replaceInputRef} type="file" accept="image/*" hidden onChange={(e) => handleReplace(e.target.files)} />

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative w-full max-w-xs">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search media..."
            className="w-full rounded-md border border-beige-dark bg-white py-2 pl-9 pr-3 text-sm focus:border-maroon focus:outline-none focus:ring-2 focus:ring-maroon-100"
          />
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setFolder("all")}
            className={cn("flex items-center gap-1.5 rounded-pill px-3 py-1.5 text-xs font-medium", folder === "all" ? "bg-maroon text-ivory" : "bg-white text-charcoal-muted")}
          >
            <Folder className="h-3.5 w-3.5" /> All
          </button>
          {folders.map((f) => (
            <button
              key={f}
              onClick={() => setFolder(f)}
              className={cn("flex items-center gap-1.5 rounded-pill px-3 py-1.5 text-xs font-medium capitalize", folder === f ? "bg-maroon text-ivory" : "bg-white text-charcoal-muted")}
            >
              <Folder className="h-3.5 w-3.5" /> {f}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
        {filtered.map((item) => (
          <div key={item.id} className="group relative overflow-hidden rounded-md bg-white shadow-soft">
            <div className="aspect-square overflow-hidden bg-beige">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={item.url} alt={item.name} className="h-full w-full object-cover" />
            </div>
            <div className="p-2.5">
              <p className="truncate text-xs font-medium text-charcoal">{item.name}</p>
              <p className="text-[10px] text-charcoal-muted">{formatSize(item.size)}</p>
            </div>
            <div className="absolute inset-x-0 top-0 flex justify-end gap-1 bg-charcoal/0 p-1.5 opacity-0 transition-opacity group-hover:bg-charcoal/10 group-hover:opacity-100">
              <button onClick={() => copyUrl(item.url)} className="rounded bg-white/95 p-1.5 shadow-soft" title="Copy URL">
                <Copy className="h-3.5 w-3.5 text-charcoal" />
              </button>
              <button
                onClick={() => {
                  replaceTarget.current = item;
                  replaceInputRef.current?.click();
                }}
                className="rounded bg-white/95 p-1.5 shadow-soft"
                title="Replace"
              >
                <UploadCloud className="h-3.5 w-3.5 text-charcoal" />
              </button>
              <button onClick={() => setToDelete(item)} className="rounded bg-white/95 p-1.5 shadow-soft" title="Delete">
                <Trash2 className="h-3.5 w-3.5 text-maroon" />
              </button>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full rounded-md bg-white p-10 text-center text-charcoal-muted shadow-soft">No media found.</div>
        )}
      </div>

      <ConfirmDialog
        open={Boolean(toDelete)}
        onClose={() => setToDelete(null)}
        onConfirm={async () => {
          if (toDelete) {
            const result = await deleteItem(toDelete.id);
            showToast(result.success ? "Media deleted." : result.error ?? "Failed to delete media.");
            setToDelete(null);
          }
        }}
        title="Delete Media"
        description={`Are you sure you want to delete "${toDelete?.name}"?`}
      />
    </div>
  );
}
