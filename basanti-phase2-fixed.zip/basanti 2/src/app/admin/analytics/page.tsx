"use client";

import { PageHeader } from "@/components/admin/ui/page-header";
import { StatCard } from "@/components/admin/ui/stat-card";
import { BarChart, LineChart } from "@/components/admin/dashboard/mini-charts";
import { useOrdersStore } from "@/store/admin/orders-store";
import { useCustomersStore } from "@/store/admin/customers-store";
import { useProductsStore } from "@/store/admin/products-store";
import { formatPrice } from "@/lib/utils";
import { TrendingUp, Users, ShoppingCart, Percent } from "lucide-react";

export default function AdminAnalyticsPage() {
  const orders = useOrdersStore((s) => s.orders);
  const customers = useCustomersStore((s) => s.customers);
  const products = useProductsStore((s) => s.products);

  const revenue = orders.reduce((sum, o) => sum + o.total, 0);
  const avgOrderValue = orders.length ? revenue / orders.length : 0;
  const conversionRate = 3.4;

  const monthlyRevenue = [
    { label: "Feb", value: 182000 },
    { label: "Mar", value: 210000 },
    { label: "Apr", value: 195000 },
    { label: "May", value: 248000 },
    { label: "Jun", value: 276000 },
    { label: "Jul", value: 224000 },
  ];

  const trafficSources = [
    { label: "Direct", value: 38 },
    { label: "Social", value: 27 },
    { label: "Search", value: 22 },
    { label: "Referral", value: 13 },
  ];

  const topCategories = Object.entries(
    products.reduce<Record<string, number>>((acc, p) => {
      acc[p.category] = (acc[p.category] ?? 0) + 1;
      return acc;
    }, {})
  );

  return (
    <div>
      <PageHeader title="Analytics" description="Store performance at a glance" />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total Revenue" value={formatPrice(revenue)} icon={TrendingUp} trend={{ value: "+8.9%", positive: true }} />
        <StatCard label="Avg. Order Value" value={formatPrice(avgOrderValue)} icon={ShoppingCart} accent="gold" />
        <StatCard label="Total Customers" value={String(customers.length)} icon={Users} />
        <StatCard label="Conversion Rate" value={`${conversionRate}%`} icon={Percent} accent="gold" trend={{ value: "+0.4%", positive: true }} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="rounded-md bg-white p-5 shadow-soft lg:col-span-2">
          <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Monthly Revenue Trend</h3>
          <LineChart data={monthlyRevenue} color="gold" />
        </div>
        <div className="rounded-md bg-white p-5 shadow-soft">
          <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Traffic Sources</h3>
          <BarChart data={trafficSources} color="maroon" />
        </div>
      </div>

      <div className="mt-6 rounded-md bg-white p-5 shadow-soft">
        <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Products per Category</h3>
        <div className="space-y-3">
          {topCategories.map(([category, count]) => (
            <div key={category} className="flex items-center gap-4">
              <span className="w-32 shrink-0 text-sm text-charcoal-muted">{category}</span>
              <div className="h-2.5 flex-1 overflow-hidden rounded-pill bg-beige">
                <div
                  className="h-full rounded-pill bg-maroon"
                  style={{ width: `${(count / products.length) * 100}%` }}
                />
              </div>
              <span className="w-8 text-right text-sm font-medium text-charcoal">{count}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
