"use client";

import Link from "next/link";
import { DollarSign, ShoppingBag, Users, Package, AlertTriangle, Eye } from "lucide-react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { StatCard } from "@/components/admin/ui/stat-card";
import { OrderStatusBadge } from "@/components/admin/ui/status-badge";
import { BarChart, LineChart } from "@/components/admin/dashboard/mini-charts";
import { useProductsStore } from "@/store/admin/products-store";
import { useOrdersStore } from "@/store/admin/orders-store";
import { useCustomersStore } from "@/store/admin/customers-store";
import { formatPrice } from "@/lib/utils";

export default function AdminDashboardPage() {
  const products = useProductsStore((s) => s.products);
  const orders = useOrdersStore((s) => s.orders);
  const customers = useCustomersStore((s) => s.customers);

  const revenue = orders.reduce((sum, o) => sum + o.total, 0);
  const todaysSales = orders.slice(0, 4).reduce((sum, o) => sum + o.total, 0);
  const lowStock = products.filter((p) => p.stock <= 5);
  const recentOrders = [...orders].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5);

  const productSales = products
    .map((p) => ({ product: p, sold: orders.flatMap((o) => o.items).filter((i) => i.productId === p.id).reduce((s, i) => s + i.quantity, 0) }))
    .sort((a, b) => b.sold - a.sold)
    .slice(0, 5);

  const revenueByDay = [
    { label: "Mon", value: 8200 },
    { label: "Tue", value: 10400 },
    { label: "Wed", value: 7600 },
    { label: "Thu", value: 12800 },
    { label: "Fri", value: 15200 },
    { label: "Sat", value: 19600 },
    { label: "Sun", value: 14100 },
  ];

  const salesByCategory = [
    { label: "Sarees", value: 42 },
    { label: "Fusion", value: 28 },
    { label: "Access.", value: 18 },
    { label: "Outer.", value: 12 },
  ];

  return (
    <div>
      <PageHeader title="Dashboard" description="Welcome back — here's how Basanti is performing." />

      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
        <StatCard label="Today's Sales" value={formatPrice(todaysSales)} icon={DollarSign} trend={{ value: "+12.4%", positive: true }} />
        <StatCard label="Orders" value={String(orders.length)} icon={ShoppingBag} accent="gold" trend={{ value: "+4.1%", positive: true }} />
        <StatCard label="Revenue" value={formatPrice(revenue)} icon={DollarSign} trend={{ value: "+8.9%", positive: true }} />
        <StatCard label="Visitors" value="12,480" icon={Eye} accent="gold" trend={{ value: "-2.3%", positive: false }} />
        <StatCard label="Products" value={String(products.length)} icon={Package} />
        <StatCard label="Customers" value={String(customers.length)} icon={Users} accent="gold" />
      </div>

      {lowStock.length > 0 && (
        <div className="mt-4 flex items-center gap-3 rounded-md border border-gold-200 bg-gold-50 px-4 py-3 text-sm text-gold-800">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span>
            {lowStock.length} product{lowStock.length > 1 ? "s are" : " is"} running low on stock.{" "}
            <Link href="/admin/products?filter=low-stock" className="font-semibold underline">
              Review inventory
            </Link>
          </span>
        </div>
      )}

      <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="rounded-md bg-white p-5 shadow-soft lg:col-span-2">
          <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Revenue (Last 7 Days)</h3>
          <LineChart data={revenueByDay} color="gold" />
        </div>
        <div className="rounded-md bg-white p-5 shadow-soft">
          <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Sales by Category</h3>
          <BarChart data={salesByCategory} color="maroon" />
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="rounded-md bg-white shadow-soft lg:col-span-2">
          <div className="flex items-center justify-between border-b border-beige-dark/60 px-5 py-4">
            <h3 className="font-display text-base font-semibold text-charcoal">Recent Orders</h3>
            <Link href="/admin/orders" className="text-sm font-medium text-maroon hover:underline">
              View All
            </Link>
          </div>
          <div className="divide-y divide-beige-dark/40">
            {recentOrders.map((order) => (
              <Link
                key={order.id}
                href={`/admin/orders/${order.id}`}
                className="flex items-center justify-between px-5 py-3.5 text-sm hover:bg-ivory/60"
              >
                <div>
                  <p className="font-medium text-charcoal">{order.orderNumber}</p>
                  <p className="text-xs text-charcoal-muted">{order.customerName}</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-charcoal">{formatPrice(order.total)}</p>
                  <OrderStatusBadge status={order.status} />
                </div>
              </Link>
            ))}
          </div>
        </div>

        <div className="rounded-md bg-white shadow-soft">
          <div className="border-b border-beige-dark/60 px-5 py-4">
            <h3 className="font-display text-base font-semibold text-charcoal">Top Products</h3>
          </div>
          <div className="divide-y divide-beige-dark/40">
            {productSales.map(({ product, sold }) => (
              <div key={product.id} className="flex items-center gap-3 px-5 py-3.5">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={product.image} alt={product.name} className="h-10 w-10 rounded-md object-cover" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-charcoal">{product.name}</p>
                  <p className="text-xs text-charcoal-muted">{sold} sold</p>
                </div>
                <p className="text-sm font-medium text-charcoal">{formatPrice(product.price)}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
