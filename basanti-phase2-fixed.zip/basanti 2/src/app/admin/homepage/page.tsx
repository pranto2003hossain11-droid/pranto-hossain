"use client";

import Link from "next/link";
import { Eye } from "lucide-react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { Toggle } from "@/components/admin/ui/admin-input";
import { Button } from "@/components/ui/button";
import { useHomepageStore } from "@/store/admin/homepage-store";
import type { HomepageSections } from "@/lib/admin-types";

const sectionMeta: { key: keyof HomepageSections; label: string; description: string }[] = [
  { key: "collections", label: "Collections", description: "Category grid shown right below the hero banner." },
  { key: "featuredProducts", label: "Featured Products", description: "New Arrivals and Best Sellers product rails." },
  { key: "offers", label: "Offers", description: "The flash sale / limited-time offer banner." },
  { key: "testimonials", label: "Testimonials", description: "Customer testimonial carousel." },
  { key: "instagram", label: "Instagram", description: "Instagram-style gallery section." },
  { key: "newsletter", label: "Newsletter", description: "Email signup section at the bottom of the homepage." },
];

export default function AdminHomepagePage() {
  const sections = useHomepageStore((s) => s.sections);
  const toggleSection = useHomepageStore((s) => s.toggleSection);

  return (
    <div>
      <PageHeader
        title="Homepage Management"
        description="Show or hide homepage sections instantly."
        actions={
          <Link href="/" target="_blank" className="inline-flex">
            <Button variant="outline">
              <Eye className="h-4 w-4" /> Preview Homepage
            </Button>
          </Link>
        }
      />

      <div className="space-y-3">
        {sectionMeta.map((section) => (
          <div key={section.key} className="flex items-center justify-between rounded-md bg-white p-5 shadow-soft">
            <div>
              <p className="font-medium text-charcoal">{section.label}</p>
              <p className="text-sm text-charcoal-muted">{section.description}</p>
            </div>
            <Toggle checked={sections[section.key]} onChange={() => toggleSection(section.key)} />
          </div>
        ))}
      </div>
    </div>
  );
}
