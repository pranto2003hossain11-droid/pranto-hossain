"use client";

import * as React from "react";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/admin/ui/page-header";
import { DataTable, type Column } from "@/components/admin/ui/data-table";
import { Modal, ConfirmDialog } from "@/components/admin/ui/modal";
import { AdminInput } from "@/components/admin/ui/admin-input";
import { Toggle } from "@/components/admin/ui/admin-input";
import { ImageDropzone } from "@/components/admin/ui/image-dropzone";
import { Button } from "@/components/ui/button";
import { useCategoriesStore } from "@/store/admin/categories-store";
import { useProductsStore } from "@/store/admin/products-store";
import { useToastStore } from "@/store/admin/toast-store";
import type { Category } from "@/lib/admin-types";

function slugify(value: string) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export default function AdminCategoriesPage() {
  const categories = useCategoriesStore((s) => s.categories);
  const fetchCategories = useCategoriesStore((s) => s.fetchCategories);
  const addCategory = useCategoriesStore((s) => s.addCategory);
  const updateCategory = useCategoriesStore((s) => s.updateCategory);
  const deleteCategory = useCategoriesStore((s) => s.deleteCategory);
  const products = useProductsStore((s) => s.products);
  const showToast = useToastStore((s) => s.show);

  React.useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  const [modalOpen, setModalOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Category | null>(null);
  const [toDelete, setToDelete] = React.useState<Category | null>(null);
  const [form, setForm] = React.useState({ name: "", slug: "", image: "", parentId: "", visible: true });

  function openCreate() {
    setEditing(null);
    setForm({ name: "", slug: "", image: "", parentId: "", visible: true });
    setModalOpen(true);
  }

  function openEdit(cat: Category) {
    setEditing(cat);
    setForm({ name: cat.name, slug: cat.slug, image: cat.image ?? "", parentId: cat.parentId ?? "", visible: cat.visible });
    setModalOpen(true);
  }

  async function handleSave() {
    if (!form.name.trim()) {
      showToast("Category name is required.", "error");
      return;
    }
    if (editing) {
      const success = await updateCategory(editing.id, {
        name: form.name,
        slug: form.slug || slugify(form.name),
        image: form.image,
        parentId: form.parentId || null,
        visible: form.visible,
      });
      showToast(success ? "Category updated." : "Failed to update category.", success ? "success" : "error");
    } else {
      const success = await addCategory({
        name: form.name,
        slug: form.slug || slugify(form.name),
        image: form.image,
        parentId: form.parentId || null,
        visible: form.visible,
        sortOrder: categories.length + 1,
      });
      showToast(success ? "Category created." : "Failed to create category.", success ? "success" : "error");
    }
    setModalOpen(false);
  }

  const columns: Column<Category>[] = [
    {
      key: "category",
      header: "Category",
      sortValue: (c) => c.name,
      render: (c) => (
        <div className="flex items-center gap-3">
          {c.image ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={c.image} alt={c.name} className="h-11 w-11 rounded-md object-cover" />
          ) : (
            <div className="h-11 w-11 rounded-md bg-beige" />
          )}
          <div>
            <p className="font-medium text-charcoal">{c.name}</p>
            <p className="text-xs text-charcoal-muted">/{c.slug}</p>
          </div>
        </div>
      ),
    },
    {
      key: "products",
      header: "Products",
      render: (c) => products.filter((p) => p.category === c.name).length,
    },
    { key: "sort", header: "Sort Order", sortValue: (c) => c.sortOrder, render: (c) => c.sortOrder },
    {
      key: "visible",
      header: "Visibility",
      render: (c) => (
        <span className={c.visible ? "text-emerald-700" : "text-charcoal-muted"}>{c.visible ? "Visible" : "Hidden"}</span>
      ),
    },
    {
      key: "actions",
      header: "",
      render: (c) => (
        <div className="flex items-center justify-end gap-1">
          <button onClick={() => openEdit(c)} className="rounded-md p-2 text-charcoal-muted hover:bg-beige hover:text-charcoal">
            <Pencil className="h-4 w-4" />
          </button>
          <button onClick={() => setToDelete(c)} className="rounded-md p-2 text-charcoal-muted hover:bg-maroon-50 hover:text-maroon">
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      ),
      className: "text-right",
    },
  ];

  return (
    <div>
      <PageHeader
        title="Categories"
        description={`${categories.length} categories`}
        actions={
          <Button onClick={openCreate}>
            <Plus className="h-4 w-4" /> Add Category
          </Button>
        }
      />

      <DataTable
        columns={columns}
        rows={categories}
        rowId={(c) => c.id}
        searchPlaceholder="Search categories..."
        searchKeys={(c) => c.name}
      />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Category" : "Add Category"}>
        <div className="space-y-4">
          <AdminInput
            label="Category Name"
            required
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value, slug: f.slug || slugify(e.target.value) }))}
          />
          <AdminInput label="Slug" value={form.slug} onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))} />
          <AdminInput
            label="Parent Category ID (optional)"
            value={form.parentId}
            onChange={(e) => setForm((f) => ({ ...f, parentId: e.target.value }))}
            hint="Leave blank for a top-level category"
          />
          <div>
            <label className="mb-1.5 block text-sm font-medium text-charcoal">Category Image</label>
            <ImageDropzone
              images={form.image ? [form.image] : []}
              onChange={(imgs) => setForm((f) => ({ ...f, image: imgs[imgs.length - 1] ?? "" }))}
              maxImages={1}
            />
          </div>
          <Toggle label="Visible on storefront" checked={form.visible} onChange={(v) => setForm((f) => ({ ...f, visible: v }))} />
          <Button className="w-full" size="lg" onClick={handleSave}>
            {editing ? "Save Changes" : "Create Category"}
          </Button>
        </div>
      </Modal>

      <ConfirmDialog
        open={Boolean(toDelete)}
        onClose={() => setToDelete(null)}
        onConfirm={async () => {
          if (toDelete) {
            const result = await deleteCategory(toDelete.id);
            showToast(
              result.success ? "Category deleted." : result.error ?? "Failed to delete category.",
              result.success ? "success" : "error"
            );
            setToDelete(null);
          }
        }}
        title="Delete Category"
        description={`Are you sure you want to delete "${toDelete?.name}"? Products in this category will keep their category label.`}
      />
    </div>
  );
}
