import Link from "next/link";
import { buttonVariants } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="container-padded flex min-h-[60vh] flex-col items-center justify-center text-center">
      <p className="font-display text-6xl font-semibold text-maroon">404</p>
      <h1 className="mt-3 font-display text-display-sm">Page Not Found</h1>
      <p className="mt-2 max-w-sm text-charcoal-light">
        The page you&apos;re looking for doesn&apos;t exist or may have been moved.
      </p>
      <Link href="/" className={buttonVariants({ size: "lg", className: "mt-6" })}>
        Back to Home
      </Link>
    </div>
  );
}
