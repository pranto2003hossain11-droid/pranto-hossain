"use client";

import Link from "next/link";
import { Heart } from "lucide-react";
import { useWishlistStore } from "@/store/wishlist-store";
import { ProductCard } from "@/components/product/product-card";
import { buttonVariants } from "@/components/ui/button";

export default function WishlistPage() {
  const items = useWishlistStore((s) => s.items);

  return (
    <div className="container-padded section-spacing">
      <h1 className="mb-8 font-display text-display-sm md:text-display-md">Your Wishlist</h1>
      {items.length === 0 ? (
        <div className="flex flex-col items-center gap-4 py-10 text-center">
          <Heart className="h-12 w-12 text-charcoal-muted" />
          <p className="text-charcoal-light">You haven&apos;t saved anything yet.</p>
          <Link href="/shop" className={buttonVariants({ size: "lg" })}>
            Browse Products
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-4 lg:gap-x-6">
          {items.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
