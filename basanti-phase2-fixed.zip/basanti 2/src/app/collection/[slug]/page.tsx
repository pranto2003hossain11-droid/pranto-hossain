import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { serializeProduct } from "@/lib/serializers";
import { ProductCard } from "@/components/product/product-card";
import type { Product } from "@/lib/types";

export const dynamic = "force-dynamic";

interface PageProps {
  params: { slug: string };
}

async function loadCollection(slug: string) {
  const collection = await prisma.collection.findUnique({
    where: { slug },
    include: {
      products: {
        where: { product: { status: "PUBLISHED", visibility: "VISIBLE" } },
        include: { product: { include: { category: { select: { name: true } } } } },
        orderBy: { sortOrder: "asc" },
      },
    },
  });
  if (!collection || !collection.visible) return null;
  return collection;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const collection = await loadCollection(params.slug);
  if (!collection) return { title: "Collection | Basanti Boutiques & House" };
  return { title: `${collection.name} | Basanti Boutiques & House` };
}

export default async function CollectionDetailPage({ params }: PageProps) {
  const collection = await loadCollection(params.slug);
  if (!collection) notFound();

  const products: Product[] = collection.products.map(
    (pc: { product: Parameters<typeof serializeProduct>[0] }) => serializeProduct(pc.product)
  );

  return (
    <div className="container-padded section-spacing">
      <div className="mb-10 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Collection</p>
        <h1 className="mt-2 font-display text-display-sm md:text-display-md">{collection.name}</h1>
        {collection.description && (
          <p className="mx-auto mt-2 max-w-xl text-sm text-charcoal-muted">{collection.description}</p>
        )}
      </div>
      {products.length === 0 ? (
        <p className="text-center text-charcoal-muted">No products in this collection yet.</p>
      ) : (
        <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-4 lg:gap-x-6">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
