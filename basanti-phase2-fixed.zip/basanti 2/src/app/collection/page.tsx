import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";

export const metadata: Metadata = { title: "Collections" };
export const dynamic = "force-dynamic";

export default async function CollectionPage() {
  const collections = await prisma.collection.findMany({
    where: { visible: true },
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
  });

  return (
    <div className="container-padded section-spacing">
      <div className="mb-10 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Curated</p>
        <h1 className="mt-2 font-display text-display-sm md:text-display-md">Collections</h1>
      </div>
      {collections.length === 0 ? (
        <p className="text-center text-charcoal-muted">No collections available yet.</p>
      ) : (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {collections.map((c: (typeof collections)[number]) => (
            <Link key={c.slug} href={`/collection/${c.slug}`} className="group block">
              <div className="relative aspect-[4/5] overflow-hidden rounded-md bg-beige">
                {c.image && (
                  <Image
                    src={c.image}
                    alt={c.name}
                    fill
                    sizes="(max-width: 768px) 100vw, 33vw"
                    className="object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/70 via-charcoal/10 to-transparent" />
                <div className="absolute bottom-5 left-5 right-5">
                  <h2 className="font-display text-xl font-semibold text-ivory">{c.name}</h2>
                  {c.description && <p className="mt-1 text-sm text-ivory/80">{c.description}</p>}
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
