import type { Metadata } from "next";
import RegisterForm from "@/components/auth/register-form";

export const metadata: Metadata = {
  title: "Create Account",
};

export default function RegisterPage() {
  return (
    <div className="container-padded section-spacing flex justify-center">
      <RegisterForm />
    </div>
  );
}