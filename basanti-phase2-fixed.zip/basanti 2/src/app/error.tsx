"use client";

import { useEffect } from "react";
import { buttonVariants } from "@/components/ui/button";

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    // Log to your error reporting service here.
    console.error(error);
  }, [error]);

  return (
    <div className="container-padded flex min-h-[60vh] flex-col items-center justify-center text-center">
      <p className="font-display text-6xl font-semibold text-maroon">Oops</p>
      <h1 className="mt-3 font-display text-display-sm">Something went wrong</h1>
      <p className="mt-2 max-w-sm text-charcoal-light">
        We hit an unexpected error. Please try again, or head back to the homepage.
      </p>
      <div className="mt-6 flex gap-3">
        <button onClick={() => reset()} className={buttonVariants({ size: "lg" })}>
          Try Again
        </button>
        <a href="/" className={buttonVariants({ variant: "outline", size: "lg" })}>
          Back to Home
        </a>
      </div>
    </div>
  );
}
