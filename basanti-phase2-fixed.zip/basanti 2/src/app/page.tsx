"use client";

import { useEffect, useState } from "react";
import { Hero } from "@/components/home/hero";
import { CategoryGrid } from "@/components/home/category-grid";
import { ProductSection } from "@/components/home/product-section";
import { FlashSale } from "@/components/home/flash-sale";
import { BrandStory } from "@/components/home/brand-story";
import { Testimonials } from "@/components/home/testimonials";
import { InstagramGallery, NewsletterSection } from "@/components/home/instagram-newsletter";
import type { Product } from "@/lib/types";

interface HomepageSectionRow {
  key: string;
  sortOrder: number;
}

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [enabledSections, setEnabledSections] = useState<Set<string>>(
    new Set(["collections", "featuredProducts", "offers", "testimonials", "instagram", "newsletter"])
  );

  useEffect(() => {
    fetch("/api/products?pageSize=60")
      .then((res) => res.json())
      .then((data) => setProducts(data.products ?? []))
      .catch(() => setProducts([]));

    fetch("/api/homepage-sections")
      .then((res) => res.json())
      .then((data: { sections?: HomepageSectionRow[] }) =>
        setEnabledSections(new Set((data.sections ?? []).map((s) => s.key)))
      )
      .catch(() => setEnabledSections(new Set()));
  }, []);

  // Every product returned by /api/products is already published+visible.
  const bestSellers = products.filter((p) => p.isBestSeller);
  const fillerProducts = products.filter((p) => !p.isBestSeller).slice(0, Math.max(0, 6 - bestSellers.length));
  const bestSellersDisplay = [...bestSellers, ...fillerProducts];

  const showCollections = enabledSections.has("collections");
  const showFeatured = enabledSections.has("featuredProducts");
  const showOffers = enabledSections.has("offers");
  const showTestimonials = enabledSections.has("testimonials");
  const showInstagram = enabledSections.has("instagram");
  const showNewsletter = enabledSections.has("newsletter");

  return (
    <>
      <Hero />
      {showCollections && <CategoryGrid />}
      {showFeatured && (
        <ProductSection
          eyebrow="Just In"
          title="New Arrivals"
          products={products.filter((p) => p.isNew)}
          viewAllHref="/shop?filter=new"
        />
      )}
      {showOffers && <FlashSale />}
      {showFeatured && (
        <ProductSection
          eyebrow="Customer Favorites"
          title="Best Sellers"
          products={bestSellersDisplay}
          viewAllHref="/shop?filter=best-seller"
        />
      )}
      <BrandStory />
      {showTestimonials && <Testimonials />}
      {showInstagram && <InstagramGallery />}
      {showNewsletter && <NewsletterSection />}
    </>
  );
}
