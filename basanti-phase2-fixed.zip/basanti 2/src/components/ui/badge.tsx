import * as React from "react";
import { cn } from "@/lib/utils";

type BadgeVariant = "maroon" | "gold" | "beige" | "outline" | "success" | "sale";

const variantClasses: Record<BadgeVariant, string> = {
  maroon: "bg-maroon text-ivory",
  gold: "bg-gold text-ivory",
  beige: "bg-beige text-charcoal",
  outline: "border border-charcoal/20 text-charcoal bg-transparent",
  success: "bg-emerald-100 text-emerald-700",
  sale: "bg-maroon-600 text-ivory",
};

export function Badge({
  className,
  variant = "maroon",
  children,
}: {
  className?: string;
  variant?: BadgeVariant;
  children: React.ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-pill px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider",
        variantClasses[variant],
        className
      )}
    >
      {children}
    </span>
  );
}
