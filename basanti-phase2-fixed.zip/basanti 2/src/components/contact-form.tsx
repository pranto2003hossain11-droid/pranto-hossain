"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";

export function ContactForm() {
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return (
      <div className="rounded-md bg-beige p-6 text-sm text-charcoal">
        Thanks for reaching out — our team will get back to you within 1–2 business days.
      </div>
    );
  }

  return (
    <form
      className="space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        setSubmitted(true);
      }}
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm font-medium">Name</label>
          <input required className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm" />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Email</label>
          <input type="email" required className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm" />
        </div>
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium">Subject</label>
        <input required className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm" />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium">Message</label>
        <textarea required rows={5} className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm" />
      </div>
      <Button type="submit" size="lg">Send Message</Button>
    </form>
  );
}
