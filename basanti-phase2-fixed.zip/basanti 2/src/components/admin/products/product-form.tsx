"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AdminInput, AdminTextarea, AdminSelect, Toggle } from "@/components/admin/ui/admin-input";
import { ImageDropzone } from "@/components/admin/ui/image-dropzone";
import { TagInput } from "@/components/admin/ui/tag-input";
import { useCategoriesStore } from "@/store/admin/categories-store";
import { useToastStore } from "@/store/admin/toast-store";
import type { Product } from "@/lib/types";

export interface ProductFormValues {
  name: string;
  slug: string;
  sku: string;
  brand: string;
  category: string;
  price: number;
  compareAtPrice: number | undefined;
  stock: number;
  sizes: string[];
  colors: string[];
  images: string[];
  description: string;
  specifications: { label: string; value: string }[];
  seoTitle: string;
  seoDescription: string;
  status: "published" | "draft";
  visibility: "visible" | "hidden";
  isNew: boolean;
  isBestSeller: boolean;
}

function slugify(value: string) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export function productToFormValues(product?: Product): ProductFormValues {
  return {
    name: product?.name ?? "",
    slug: product?.slug ?? "",
    sku: product?.sku ?? "",
    brand: product?.brand ?? "Basanti",
    category: product?.category ?? "",
    price: product?.price ?? 0,
    compareAtPrice: product?.compareAtPrice,
    stock: product?.stock ?? 0,
    sizes: product?.sizes ?? [],
    colors: product?.colors ?? [],
    images: product?.images ?? (product?.image ? [product.image] : []),
    description: product?.description ?? "",
    specifications: product?.specifications ?? [],
    seoTitle: product?.seoTitle ?? "",
    seoDescription: product?.seoDescription ?? "",
    status: product?.status ?? "published",
    visibility: product?.visibility ?? "visible",
    isNew: product?.isNew ?? false,
    isBestSeller: product?.isBestSeller ?? false,
  };
}

export function ProductForm({
  initial,
  onSubmit,
  submitLabel = "Save Product",
}: {
  initial: ProductFormValues;
  onSubmit: (values: ProductFormValues) => void;
  submitLabel?: string;
}) {
  const router = useRouter();
  const categories = useCategoriesStore((s) => s.categories);
  const showToast = useToastStore((s) => s.show);
  const [values, setValues] = React.useState<ProductFormValues>(initial);
  const [errors, setErrors] = React.useState<Record<string, string>>({});

  function set<K extends keyof ProductFormValues>(key: K, value: ProductFormValues[K]) {
    setValues((v) => ({ ...v, [key]: value }));
  }

  function handleNameChange(name: string) {
    setValues((v) => ({ ...v, name, slug: v.slug && v.slug !== slugify(v.name) ? v.slug : slugify(name) }));
  }

  function addSpec() {
    set("specifications", [...values.specifications, { label: "", value: "" }]);
  }

  function updateSpec(index: number, field: "label" | "value", val: string) {
    const next = [...values.specifications];
    const current = next[index] ?? { label: "", value: "" };
    next[index] = { ...current, [field]: val };
    set("specifications", next);
  }

  function removeSpec(index: number) {
    set("specifications", values.specifications.filter((_, i) => i !== index));
  }

  function validate() {
    const next: Record<string, string> = {};
    if (!values.name.trim()) next.name = "Product name is required.";
    if (!values.category) next.category = "Select a category.";
    if (values.price <= 0) next.price = "Enter a valid price.";
    if (values.images.length === 0) next.images = "Add at least one product image.";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) {
      showToast("Please fix the highlighted fields.", "error");
      return;
    }
    onSubmit(values);
  }

  return (
    <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-5 lg:grid-cols-3">
      <div className="space-y-5 lg:col-span-2">
        <section className="rounded-md bg-white p-5 shadow-soft">
          <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Basic Information</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <AdminInput
              label="Product Name"
              required
              value={values.name}
              onChange={(e) => handleNameChange(e.target.value)}
              error={errors.name}
              wrapperClassName="sm:col-span-2"
            />
            <AdminInput label="Slug (URL)" value={values.slug} onChange={(e) => set("slug", e.target.value)} />
            <AdminInput label="SKU" value={values.sku} onChange={(e) => set("sku", e.target.value)} />
            <AdminInput label="Brand" value={values.brand} onChange={(e) => set("brand", e.target.value)} />
            <AdminSelect
              label="Category"
              required
              value={values.category}
              onChange={(e) => set("category", e.target.value)}
              placeholder="Select category"
              error={errors.category}
              options={categories.map((c) => ({ label: c.name, value: c.name }))}
            />
          </div>
          <div className="mt-4">
            <AdminTextarea
              label="Description"
              rows={5}
              value={values.description}
              onChange={(e) => set("description", e.target.value)}
            />
          </div>
        </section>

        <section className="rounded-md bg-white p-5 shadow-soft">
          <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Pricing & Inventory</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <AdminInput
              label="Price (৳)"
              type="number"
              required
              min={0}
              value={values.price || ""}
              onChange={(e) => set("price", Number(e.target.value))}
              error={errors.price}
            />
            <AdminInput
              label="Compare-at Price (৳)"
              type="number"
              min={0}
              value={values.compareAtPrice ?? ""}
              onChange={(e) => set("compareAtPrice", e.target.value ? Number(e.target.value) : undefined)}
              hint="Shown as a strikethrough discount price"
            />
            <AdminInput
              label="Stock Quantity"
              type="number"
              min={0}
              value={values.stock}
              onChange={(e) => set("stock", Number(e.target.value))}
            />
          </div>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <TagInput label="Sizes" values={values.sizes} onChange={(v) => set("sizes", v)} placeholder="e.g. S, M, L" />
            <TagInput label="Colors" values={values.colors} onChange={(v) => set("colors", v)} placeholder="e.g. Maroon, Gold" />
          </div>
        </section>

        <section className="rounded-md bg-white p-5 shadow-soft">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-display text-base font-semibold text-charcoal">Specifications</h3>
            <button type="button" onClick={addSpec} className="flex items-center gap-1 text-sm font-medium text-maroon hover:underline">
              <Plus className="h-4 w-4" /> Add Row
            </button>
          </div>
          {values.specifications.length === 0 ? (
            <p className="text-sm text-charcoal-muted">No specifications added yet.</p>
          ) : (
            <div className="space-y-2.5">
              {values.specifications.map((spec, i) => (
                <div key={i} className="flex items-center gap-2.5">
                  <input
                    value={spec.label}
                    onChange={(e) => updateSpec(i, "label", e.target.value)}
                    placeholder="Fabric"
                    className="w-1/3 rounded-md border border-beige-dark px-3 py-2 text-sm focus:border-maroon focus:outline-none"
                  />
                  <input
                    value={spec.value}
                    onChange={(e) => updateSpec(i, "value", e.target.value)}
                    placeholder="Cotton-silk blend"
                    className="flex-1 rounded-md border border-beige-dark px-3 py-2 text-sm focus:border-maroon focus:outline-none"
                  />
                  <button type="button" onClick={() => removeSpec(i)} className="p-2 text-maroon hover:text-maroon-600">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="rounded-md bg-white p-5 shadow-soft">
          <h3 className="mb-4 font-display text-base font-semibold text-charcoal">SEO</h3>
          <div className="space-y-4">
            <AdminInput label="SEO Title" value={values.seoTitle} onChange={(e) => set("seoTitle", e.target.value)} />
            <AdminTextarea label="SEO Description" rows={3} value={values.seoDescription} onChange={(e) => set("seoDescription", e.target.value)} />
          </div>
        </section>
      </div>

      <div className="space-y-5">
        <section className="rounded-md bg-white p-5 shadow-soft">
          <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Publishing</h3>
          <div className="space-y-3">
            <Toggle label="Published" checked={values.status === "published"} onChange={(v) => set("status", v ? "published" : "draft")} />
            <Toggle label="Visible on storefront" checked={values.visibility === "visible"} onChange={(v) => set("visibility", v ? "visible" : "hidden")} />
            <Toggle label="Mark as New Arrival" checked={values.isNew} onChange={(v) => set("isNew", v)} />
            <Toggle label="Mark as Best Seller" checked={values.isBestSeller} onChange={(v) => set("isBestSeller", v)} />
          </div>
        </section>

        <section className="rounded-md bg-white p-5 shadow-soft">
          <h3 className="mb-4 font-display text-base font-semibold text-charcoal">Product Images</h3>
          <ImageDropzone images={values.images} onChange={(imgs) => set("images", imgs)} onFeaturedChange={() => {}} />
          {errors.images && <p className="mt-2 text-xs font-medium text-maroon-600">{errors.images}</p>}
        </section>

        <div className="flex flex-col gap-2.5">
          <Button type="submit" size="lg" className="w-full">
            {submitLabel}
          </Button>
          <Button type="button" variant="outline" size="lg" className="w-full" onClick={() => router.push("/admin/products")}>
            Cancel
          </Button>
        </div>
      </div>
    </form>
  );
}
