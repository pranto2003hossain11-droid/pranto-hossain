"use client";

import * as React from "react";

interface ChartDatum {
  label: string;
  value: number;
}

const COLORS = {
  maroon: "#6B1424",
  gold: "#B4863C",
};

export function BarChart({ data, color = "maroon" }: { data: ChartDatum[]; color?: keyof typeof COLORS }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  const width = 560;
  const height = 220;
  const barGap = 14;
  const barWidth = (width - barGap * (data.length - 1)) / data.length;

  return (
    <svg viewBox={`0 0 ${width} ${height + 24}`} className="w-full" role="img" aria-label="Bar chart">
      {data.map((d, i) => {
        const barHeight = (d.value / max) * height;
        const x = i * (barWidth + barGap);
        const y = height - barHeight;
        return (
          <g key={d.label}>
            <rect
              x={x}
              y={y}
              width={barWidth}
              height={barHeight}
              rx={6}
              fill={COLORS[color]}
              opacity={0.85}
            />
            <text x={x + barWidth / 2} y={height + 18} textAnchor="middle" className="fill-charcoal-muted text-[10px]">
              {d.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

export function LineChart({ data, color = "gold" }: { data: ChartDatum[]; color?: keyof typeof COLORS }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  const width = 560;
  const height = 220;
  const stepX = width / (data.length - 1 || 1);

  const points = data.map((d, i) => {
    const x = i * stepX;
    const y = height - (d.value / max) * (height - 20) - 10;
    return { x, y };
  });

  const path = points.map((p, i) => `${i === 0 ? "M" : "L"}${p.x},${p.y}`).join(" ");
  const areaPath = `${path} L${width},${height} L0,${height} Z`;

  return (
    <svg viewBox={`0 0 ${width} ${height + 24}`} className="w-full" role="img" aria-label="Line chart">
      <defs>
        <linearGradient id={`grad-${color}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={COLORS[color]} stopOpacity="0.25" />
          <stop offset="100%" stopColor={COLORS[color]} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={areaPath} fill={`url(#grad-${color})`} />
      <path d={path} fill="none" stroke={COLORS[color]} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
      {points.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={3.5} fill={COLORS[color]} />
      ))}
      {data.map((d, i) => (
        <text key={d.label} x={points[i]?.x ?? 0} y={height + 18} textAnchor="middle" className="fill-charcoal-muted text-[10px]">
          {d.label}
        </text>
      ))}
    </svg>
  );
}
