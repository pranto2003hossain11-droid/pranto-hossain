import * as React from "react";
import { cn } from "@/lib/utils";

interface FieldWrapperProps {
  label?: string;
  hint?: string;
  error?: string;
  required?: boolean;
  className?: string;
  children: React.ReactNode;
}

export function FieldWrapper({ label, hint, error, required, className, children }: FieldWrapperProps) {
  return (
    <div className={cn("space-y-1.5", className)}>
      {label && (
        <label className="block text-sm font-medium text-charcoal">
          {label}
          {required && <span className="ml-0.5 text-maroon">*</span>}
        </label>
      )}
      {children}
      {hint && !error && <p className="text-xs text-charcoal-muted">{hint}</p>}
      {error && <p className="text-xs font-medium text-maroon-600">{error}</p>}
    </div>
  );
}

const fieldClasses =
  "w-full rounded-md border border-beige-dark bg-white px-3.5 py-2.5 text-sm text-charcoal placeholder:text-charcoal-muted transition-colors focus:border-maroon focus:outline-none focus:ring-2 focus:ring-maroon-100 disabled:cursor-not-allowed disabled:bg-beige/50";

export interface AdminInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  hint?: string;
  error?: string;
  wrapperClassName?: string;
}

export const AdminInput = React.forwardRef<HTMLInputElement, AdminInputProps>(
  ({ label, hint, error, required, className, wrapperClassName, ...props }, ref) => (
    <FieldWrapper label={label} hint={hint} error={error} required={required} className={wrapperClassName}>
      <input ref={ref} required={required} className={cn(fieldClasses, error && "border-maroon-400", className)} {...props} />
    </FieldWrapper>
  )
);
AdminInput.displayName = "AdminInput";

export interface AdminTextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  hint?: string;
  error?: string;
  wrapperClassName?: string;
}

export const AdminTextarea = React.forwardRef<HTMLTextAreaElement, AdminTextareaProps>(
  ({ label, hint, error, required, className, wrapperClassName, rows = 4, ...props }, ref) => (
    <FieldWrapper label={label} hint={hint} error={error} required={required} className={wrapperClassName}>
      <textarea
        ref={ref}
        required={required}
        rows={rows}
        className={cn(fieldClasses, "resize-y", error && "border-maroon-400", className)}
        {...props}
      />
    </FieldWrapper>
  )
);
AdminTextarea.displayName = "AdminTextarea";

export interface AdminSelectOption {
  label: string;
  value: string;
}

export interface AdminSelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  hint?: string;
  error?: string;
  options: AdminSelectOption[];
  wrapperClassName?: string;
  placeholder?: string;
}

export const AdminSelect = React.forwardRef<HTMLSelectElement, AdminSelectProps>(
  ({ label, hint, error, required, className, wrapperClassName, options, placeholder, ...props }, ref) => (
    <FieldWrapper label={label} hint={hint} error={error} required={required} className={wrapperClassName}>
      <select
        ref={ref}
        required={required}
        className={cn(fieldClasses, "appearance-none bg-[url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22none%22 stroke=%22%23262220%22><path d=%22M6 9l6 6 6-6%22/></svg>')] bg-[length:16px] bg-[right_0.75rem_center] bg-no-repeat pr-9", error && "border-maroon-400", className)}
        {...props}
      >
        {placeholder && (
          <option value="" disabled>
            {placeholder}
          </option>
        )}
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </FieldWrapper>
  )
);
AdminSelect.displayName = "AdminSelect";

export function Checkbox({
  label,
  checked,
  onChange,
  className,
}: {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  className?: string;
}) {
  return (
    <label className={cn("flex cursor-pointer items-center gap-2.5 text-sm text-charcoal", className)}>
      <span
        role="checkbox"
        aria-checked={checked}
        tabIndex={0}
        onClick={() => onChange(!checked)}
        onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onChange(!checked)}
        className={cn(
          "flex h-5 w-5 shrink-0 items-center justify-center rounded border transition-colors",
          checked ? "border-maroon bg-maroon" : "border-beige-dark bg-white"
        )}
      >
        {checked && (
          <svg viewBox="0 0 16 16" className="h-3 w-3 text-ivory" fill="none">
            <path d="M3 8.5 6.5 12 13 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
      </span>
      {label}
    </label>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <label className="inline-flex cursor-pointer items-center gap-2.5">
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn(
          "relative h-6 w-11 shrink-0 rounded-pill transition-colors",
          checked ? "bg-maroon" : "bg-beige-dark"
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-soft transition-transform",
            checked ? "translate-x-[22px]" : "translate-x-0.5"
          )}
        />
      </button>
      {label && <span className="text-sm text-charcoal">{label}</span>}
    </label>
  );
}
