import { Badge } from "@/components/ui/badge";
import type { OrderStatus } from "@/lib/admin-types";
import { cn } from "@/lib/utils";

const statusStyles: Record<OrderStatus, string> = {
  Pending: "bg-gold-50 text-gold-700",
  Confirmed: "bg-blue-50 text-blue-700",
  Processing: "bg-gold-100 text-gold-800",
  Packed: "bg-beige text-charcoal",
  Shipped: "bg-maroon-50 text-maroon-600",
  Delivered: "bg-emerald-50 text-emerald-700",
  Cancelled: "bg-red-50 text-red-600",
  Refunded: "bg-charcoal/10 text-charcoal-light",
};

export function OrderStatusBadge({ status }: { status: OrderStatus }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-pill px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider",
        statusStyles[status]
      )}
    >
      {status}
    </span>
  );
}

export function ProductStatusBadge({ status }: { status: "published" | "draft" }) {
  return (
    <Badge variant={status === "published" ? "success" : "outline"}>
      {status === "published" ? "Published" : "Draft"}
    </Badge>
  );
}
