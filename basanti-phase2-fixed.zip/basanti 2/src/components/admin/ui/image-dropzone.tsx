"use client";

import * as React from "react";
import { UploadCloud, X, GripVertical, Star, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { adminApi } from "@/lib/admin-api-client";

interface UploadedMedia {
  url: string;
}

/**
 * Reusable multi-image uploader with drag-to-reorder. Files are uploaded
 * for real to /api/admin/media (which writes them to /public/uploads and
 * records them in the Media table) — nothing here is stored as a base64
 * data URL.
 */
export function ImageDropzone({
  images,
  onChange,
  featuredIndex = 0,
  onFeaturedChange,
  maxImages = 8,
  folder = "products",
}: {
  images: string[];
  onChange: (images: string[]) => void;
  featuredIndex?: number;
  onFeaturedChange?: (index: number) => void;
  maxImages?: number;
  folder?: string;
}) {
  const inputRef = React.useRef<HTMLInputElement>(null);
  const dragIndex = React.useRef<number | null>(null);
  const [isDragOver, setIsDragOver] = React.useState(false);
  const [isUploading, setIsUploading] = React.useState(false);
  const [uploadError, setUploadError] = React.useState<string | null>(null);

  async function handleFiles(fileList: FileList | null) {
    if (!fileList || fileList.length === 0) return;
    const files = Array.from(fileList).slice(0, maxImages - images.length);
    if (files.length === 0) return;

    setIsUploading(true);
    setUploadError(null);
    try {
      const formData = new FormData();
      files.forEach((file) => formData.append("files", file));
      formData.append("folder", folder);
      const data = await adminApi.upload<{ media: UploadedMedia[] }>("/api/admin/media", formData);
      onChange([...images, ...data.media.map((m) => m.url)]);
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : "Upload failed. Please try again.");
    } finally {
      setIsUploading(false);
    }
  }

  function removeAt(index: number) {
    onChange(images.filter((_, i) => i !== index));
  }

  function reorder(from: number, to: number) {
    if (from === to) return;
    const next = [...images];
    const [moved] = next.splice(from, 1);
    if (moved) next.splice(to, 0, moved);
    onChange(next);
  }

  return (
    <div className="space-y-3">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragOver(true);
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragOver(false);
          handleFiles(e.dataTransfer.files);
        }}
        onClick={() => !isUploading && inputRef.current?.click()}
        className={cn(
          "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-md border-2 border-dashed py-8 text-center transition-colors",
          isDragOver ? "border-maroon bg-maroon-50" : "border-beige-dark bg-ivory hover:border-gold",
          isUploading && "pointer-events-none opacity-70"
        )}
      >
        {isUploading ? (
          <Loader2 className="h-7 w-7 animate-spin text-charcoal-muted" />
        ) : (
          <UploadCloud className="h-7 w-7 text-charcoal-muted" />
        )}
        <p className="text-sm font-medium text-charcoal">
          {isUploading ? "Uploading..." : "Drag & drop images, or click to browse"}
        </p>
        <p className="text-xs text-charcoal-muted">PNG, JPG up to {maxImages} images</p>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
        />
      </div>
      {uploadError && <p className="text-xs font-medium text-maroon-600">{uploadError}</p>}

      {images.length > 0 && (
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
          {images.map((src, index) => (
            <div
              key={index}
              draggable
              onDragStart={() => (dragIndex.current = index)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => {
                if (dragIndex.current !== null) reorder(dragIndex.current, index);
                dragIndex.current = null;
              }}
              className="group relative aspect-square overflow-hidden rounded-md border border-beige-dark bg-beige"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={src} alt={`Image ${index + 1}`} className="h-full w-full object-cover" />
              <div className="absolute inset-0 flex items-start justify-between bg-charcoal/0 p-1.5 opacity-0 transition-opacity group-hover:bg-charcoal/20 group-hover:opacity-100">
                <span className="cursor-grab rounded bg-white/90 p-1">
                  <GripVertical className="h-3.5 w-3.5 text-charcoal" />
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeAt(index);
                  }}
                  className="rounded bg-white/90 p-1"
                >
                  <X className="h-3.5 w-3.5 text-maroon" />
                </button>
              </div>
              {onFeaturedChange && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onFeaturedChange(index);
                  }}
                  className={cn(
                    "absolute bottom-1.5 left-1.5 flex items-center gap-1 rounded-pill px-2 py-0.5 text-[10px] font-semibold",
                    featuredIndex === index ? "bg-gold text-ivory" : "bg-white/90 text-charcoal-muted"
                  )}
                >
                  <Star className="h-2.5 w-2.5" fill={featuredIndex === index ? "currentColor" : "none"} />
                  {featuredIndex === index ? "Featured" : "Set featured"}
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
