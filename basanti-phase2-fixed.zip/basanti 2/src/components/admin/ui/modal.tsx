"use client";

import * as React from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export function Modal({
  open,
  onClose,
  title,
  children,
  size = "md",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  size?: "sm" | "md" | "lg";
}) {
  if (!open) return null;

  const sizeClasses = { sm: "max-w-md", md: "max-w-lg", lg: "max-w-2xl" }[size];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-charcoal/50 backdrop-blur-[2px]" onClick={onClose} />
      <div
        className={cn(
          "relative w-full animate-fadeIn rounded-md bg-white shadow-elevated",
          sizeClasses
        )}
      >
        <div className="flex items-center justify-between border-b border-beige-dark/60 px-6 py-4">
          <h3 className="font-display text-lg font-semibold text-charcoal">{title}</h3>
          <button onClick={onClose} aria-label="Close" className="rounded-full p-1.5 hover:bg-beige">
            <X className="h-5 w-5 text-charcoal" />
          </button>
        </div>
        <div className="max-h-[75vh] overflow-y-auto px-6 py-5">{children}</div>
      </div>
    </div>
  );
}

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  description,
  confirmLabel = "Delete",
  danger = true,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmLabel?: string;
  danger?: boolean;
}) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-charcoal/50 backdrop-blur-[2px]" onClick={onClose} />
      <div className="relative w-full max-w-sm animate-fadeIn rounded-md bg-white p-6 shadow-elevated">
        <h3 className="font-display text-lg font-semibold text-charcoal">{title}</h3>
        <p className="mt-2 text-sm text-charcoal-muted">{description}</p>
        <div className="mt-6 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="rounded px-4 py-2 text-sm font-medium text-charcoal transition-colors hover:bg-beige"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className={cn(
              "rounded px-4 py-2 text-sm font-medium text-ivory transition-colors",
              danger ? "bg-maroon hover:bg-maroon-600" : "bg-gold hover:bg-gold-500"
            )}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
