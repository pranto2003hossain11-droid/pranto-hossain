import type { LucideIcon } from "lucide-react";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";

export function StatCard({
  label,
  value,
  icon: Icon,
  trend,
  accent = "maroon",
}: {
  label: string;
  value: string;
  icon: LucideIcon;
  trend?: { value: string; positive: boolean };
  accent?: "maroon" | "gold" | "charcoal";
}) {
  const accentClasses = {
    maroon: "bg-maroon-50 text-maroon",
    gold: "bg-gold-50 text-gold-600",
    charcoal: "bg-beige text-charcoal",
  }[accent];

  return (
    <div className="rounded-md bg-white p-5 shadow-soft transition-shadow duration-300 hover:shadow-card">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-charcoal-muted">{label}</p>
          <p className="mt-2 font-display text-2xl font-semibold text-charcoal">{value}</p>
        </div>
        <div className={cn("flex h-10 w-10 items-center justify-center rounded-md", accentClasses)}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
      {trend && (
        <div className="mt-3 flex items-center gap-1 text-xs font-medium">
          {trend.positive ? (
            <ArrowUpRight className="h-3.5 w-3.5 text-emerald-600" />
          ) : (
            <ArrowDownRight className="h-3.5 w-3.5 text-maroon-500" />
          )}
          <span className={trend.positive ? "text-emerald-600" : "text-maroon-500"}>{trend.value}</span>
          <span className="text-charcoal-muted">vs last month</span>
        </div>
      )}
    </div>
  );
}
