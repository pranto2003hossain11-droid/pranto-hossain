"use client";

import * as React from "react";
import { X } from "lucide-react";

export function TagInput({
  label,
  values,
  onChange,
  placeholder = "Type and press Enter",
}: {
  label?: string;
  values: string[];
  onChange: (values: string[]) => void;
  placeholder?: string;
}) {
  const [draft, setDraft] = React.useState("");

  function addTag() {
    const value = draft.trim();
    if (value && !values.includes(value)) onChange([...values, value]);
    setDraft("");
  }

  return (
    <div className="space-y-1.5">
      {label && <label className="block text-sm font-medium text-charcoal">{label}</label>}
      <div className="flex flex-wrap items-center gap-2 rounded-md border border-beige-dark bg-white px-3 py-2 focus-within:border-maroon focus-within:ring-2 focus-within:ring-maroon-100">
        {values.map((tag) => (
          <span
            key={tag}
            className="flex items-center gap-1 rounded-pill bg-beige px-2.5 py-1 text-xs font-medium text-charcoal"
          >
            {tag}
            <button type="button" onClick={() => onChange(values.filter((v) => v !== tag))}>
              <X className="h-3 w-3" />
            </button>
          </span>
        ))}
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === ",") {
              e.preventDefault();
              addTag();
            }
          }}
          onBlur={addTag}
          placeholder={values.length === 0 ? placeholder : ""}
          className="min-w-[100px] flex-1 border-none bg-transparent py-0.5 text-sm outline-none placeholder:text-charcoal-muted"
        />
      </div>
    </div>
  );
}
