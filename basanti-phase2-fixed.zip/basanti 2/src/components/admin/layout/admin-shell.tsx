"use client";

import * as React from "react";
import { usePathname, useRouter } from "next/navigation";
import { Sidebar } from "./sidebar";
import { Topbar } from "./topbar";
import { Toaster } from "@/components/admin/ui/toaster";
import { useAdminAuthStore } from "@/store/admin/admin-auth-store";
import { useProductsStore } from "@/store/admin/products-store";

export function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const isAuthenticated = useAdminAuthStore((s) => s.isAuthenticated);
  const checkSession = useAdminAuthStore((s) => s.checkSession);
  const fetchProducts = useProductsStore((s) => s.fetchProducts);
  const [hydrated, setHydrated] = React.useState(false);
  const [collapsed, setCollapsed] = React.useState(false);
  const [mobileOpen, setMobileOpen] = React.useState(false);

  React.useEffect(() => {
    checkSession().then(() => setHydrated(true));
  }, [checkSession]);

  React.useEffect(() => {
    if (isAuthenticated) fetchProducts();
  }, [isAuthenticated, fetchProducts]);

  const isLoginPage = pathname === "/admin/login";

  React.useEffect(() => {
    if (hydrated && !isAuthenticated && !isLoginPage) {
      router.replace("/admin/login");
    }
  }, [hydrated, isAuthenticated, isLoginPage, router]);

  if (isLoginPage) {
    return <>{children}</>;
  }

  if (!hydrated || !isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-ivory">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-maroon border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-ivory font-body text-charcoal">
      <Sidebar
        collapsed={collapsed}
        onToggle={() => setCollapsed((v) => !v)}
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
      />
      <div className="flex min-h-screen flex-1 flex-col">
        <Topbar onMenuClick={() => setMobileOpen(true)} />
        <main className="flex-1 p-4 md:p-6 lg:p-8">{children}</main>
      </div>
      <Toaster />
    </div>
  );
}
