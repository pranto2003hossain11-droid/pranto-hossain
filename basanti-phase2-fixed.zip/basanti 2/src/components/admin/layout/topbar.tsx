"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Menu, Search, Bell, Plus, ChevronRight, ChevronDown, LogOut, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAdminAuthStore } from "@/store/admin/admin-auth-store";
import { useProductsStore } from "@/store/admin/products-store";
import { useOrdersStore } from "@/store/admin/orders-store";

function useBreadcrumb() {
  const pathname = usePathname() || "";
  const segments = pathname.split("/").filter(Boolean).slice(1); // drop "admin"
  if (segments.length === 0) return [{ label: "Dashboard", href: "/admin/dashboard" }];
  return segments.map((seg, i) => ({
    label: seg.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
    href: "/admin/" + segments.slice(0, i + 1).join("/"),
  }));
}

export function Topbar({ onMenuClick }: { onMenuClick: () => void }) {
  const breadcrumb = useBreadcrumb();
  const user = useAdminAuthStore((s) => s.user);
  const logout = useAdminAuthStore((s) => s.logout);
  const router = useRouter();
  const products = useProductsStore((s) => s.products);
  const orders = useOrdersStore((s) => s.orders);

  const [query, setQuery] = React.useState("");
  const [showResults, setShowResults] = React.useState(false);
  const [profileOpen, setProfileOpen] = React.useState(false);
  const [quickOpen, setQuickOpen] = React.useState(false);

  const lowStockCount = products.filter((p) => p.stock <= 5).length;
  const pendingOrders = orders.filter((o) => o.status === "Pending").length;

  const searchResults = React.useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return products.filter((p) => p.name.toLowerCase().includes(q)).slice(0, 5);
  }, [query, products]);

  async function handleLogout() {
    await logout();
    router.push("/admin/login");
  }

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-4 border-b border-beige-dark/60 bg-white/95 px-4 backdrop-blur-sm md:px-6">
      <div className="flex items-center gap-3">
        <button onClick={onMenuClick} className="rounded-md p-2 hover:bg-beige md:hidden">
          <Menu className="h-5 w-5 text-charcoal" />
        </button>

        <nav className="hidden items-center gap-1.5 text-sm text-charcoal-muted md:flex">
          {breadcrumb.map((crumb, i) => (
            <span key={crumb.href} className="flex items-center gap-1.5">
              {i > 0 && <ChevronRight className="h-3.5 w-3.5" />}
              {i === breadcrumb.length - 1 ? (
                <span className="font-medium text-charcoal">{crumb.label}</span>
              ) : (
                <Link href={crumb.href} className="hover:text-maroon">
                  {crumb.label}
                </Link>
              )}
            </span>
          ))}
        </nav>
      </div>

      <div className="relative hidden max-w-sm flex-1 md:block">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal-muted" />
        <input
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setShowResults(true);
          }}
          onFocus={() => setShowResults(true)}
          onBlur={() => setTimeout(() => setShowResults(false), 150)}
          placeholder="Search products, orders..."
          className="w-full rounded-md border border-beige-dark bg-ivory py-2 pl-9 pr-3 text-sm focus:border-maroon focus:outline-none focus:ring-2 focus:ring-maroon-100"
        />
        {showResults && query.trim() && (
          <div className="absolute left-0 right-0 top-11 rounded-md border border-beige-dark bg-white shadow-elevated">
            {searchResults.length === 0 ? (
              <p className="px-4 py-3 text-sm text-charcoal-muted">No products found.</p>
            ) : (
              searchResults.map((p) => (
                <Link
                  key={p.id}
                  href={`/admin/products/edit/${p.id}`}
                  className="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-ivory"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={p.image} alt={p.name} className="h-8 w-8 rounded object-cover" />
                  <span className="text-charcoal">{p.name}</span>
                </Link>
              ))
            )}
          </div>
        )}
      </div>

      <div className="flex items-center gap-1.5 md:gap-2">
        <div className="relative">
          <button
            onClick={() => setQuickOpen((v) => !v)}
            className="hidden items-center gap-1.5 rounded-md bg-maroon px-3 py-2 text-sm font-medium text-ivory shadow-soft hover:bg-maroon-600 sm:flex"
          >
            <Plus className="h-4 w-4" /> Quick Add
          </button>
          {quickOpen && (
            <div className="absolute right-0 top-11 w-44 rounded-md border border-beige-dark bg-white py-1.5 shadow-elevated">
              <Link href="/admin/products/new" className="block px-4 py-2 text-sm hover:bg-ivory" onClick={() => setQuickOpen(false)}>
                New Product
              </Link>
              <Link href="/admin/categories" className="block px-4 py-2 text-sm hover:bg-ivory" onClick={() => setQuickOpen(false)}>
                New Category
              </Link>
              <Link href="/admin/coupons" className="block px-4 py-2 text-sm hover:bg-ivory" onClick={() => setQuickOpen(false)}>
                New Coupon
              </Link>
            </div>
          )}
        </div>

        <div className="relative">
          <button className="relative rounded-full p-2 hover:bg-beige">
            <Bell className="h-5 w-5 text-charcoal" />
            {(lowStockCount > 0 || pendingOrders > 0) && (
              <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-maroon" />
            )}
          </button>
        </div>

        <div className="relative">
          <button
            onClick={() => setProfileOpen((v) => !v)}
            className="flex items-center gap-2 rounded-md p-1.5 hover:bg-beige"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={user?.avatar || "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?w=100"}
              alt={user?.name || "Admin"}
              className="h-8 w-8 rounded-full object-cover"
            />
            <span className="hidden text-sm font-medium text-charcoal lg:inline">{user?.name}</span>
            <ChevronDown className="hidden h-4 w-4 text-charcoal-muted lg:inline" />
          </button>
          {profileOpen && (
            <div className="absolute right-0 top-12 w-48 rounded-md border border-beige-dark bg-white py-1.5 shadow-elevated">
              <Link
                href="/admin/profile"
                className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-ivory"
                onClick={() => setProfileOpen(false)}
              >
                <User className="h-4 w-4" /> Profile
              </Link>
              <button
                onClick={handleLogout}
                className={cn("flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-maroon hover:bg-ivory")}
              >
                <LogOut className="h-4 w-4" /> Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
