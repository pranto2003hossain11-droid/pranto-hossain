"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function RegisterForm() {
  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // পরে এখানে API/Firebase connect করবো
    console.log("Register submitted");
  };

  return (
    <div className="w-full max-w-sm">
      <h1 className="mb-2 text-center font-display text-display-sm">
        Create Account
      </h1>

      <p className="mb-8 text-center text-sm text-charcoal-muted">
        Join Basanti Boutiques &amp; House
      </p>

      <form className="space-y-4" onSubmit={onSubmit}>
        <div>
          <label className="mb-1 block text-sm font-medium">
            Full Name
          </label>

          <input
            type="text"
            required
            className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm"
          />
        </div>

        <div>
          <label className="mb-1 block text-sm font-medium">
            Email
          </label>

          <input
            type="email"
            required
            className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm"
          />
        </div>

        <div>
          <label className="mb-1 block text-sm font-medium">
            Password
          </label>

          <input
            type="password"
            required
            className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm"
          />
        </div>

        <Button type="submit" size="lg" className="w-full">
          Create Account
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-charcoal-light">
        Already have an account?{" "}
        <Link
          href="/login"
          className="font-medium text-maroon hover:underline"
        >
          Login
        </Link>
      </p>
    </div>
  );
}