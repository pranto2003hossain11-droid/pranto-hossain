"use client";

import { Button } from "@/components/ui/button";

export function LoginForm() {
  return (
    <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
      <div>
        <label className="mb-1 block text-sm font-medium">Email</label>
        <input type="email" required className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm" />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium">Password</label>
        <input type="password" required className="w-full rounded border border-beige-dark px-3 py-2.5 text-sm" />
      </div>
      <Button type="submit" size="lg" className="w-full">Login</Button>
    </form>
  );
}
