import { Star, BadgeCheck } from "lucide-react";
import type { Review } from "@/lib/types";

export function ReviewsSection({ reviews, rating, count }: { reviews: Review[]; rating: number; count: number }) {
  return (
    <section className="border-t border-beige-dark pt-10" id="reviews">
      <div className="mb-6 flex items-center gap-3">
        <h2 className="font-display text-display-sm">Reviews</h2>
        <span className="flex items-center gap-1 text-sm text-charcoal-light">
          <Star className="h-4 w-4 fill-gold text-gold" /> {rating} ({count} reviews)
        </span>
      </div>
      {reviews.length === 0 ? (
        <p className="text-sm text-charcoal-muted">No reviews yet — be the first to review this product.</p>
      ) : (
        <div className="space-y-6">
          {reviews.map((r) => (
            <div key={r.id} className="border-b border-beige-dark pb-6 last:border-0">
              <div className="mb-1 flex items-center gap-2">
                <p className="text-sm font-semibold text-charcoal">{r.author}</p>
                {r.verified && (
                  <span className="flex items-center gap-1 text-xs text-emerald-700">
                    <BadgeCheck className="h-3.5 w-3.5" /> Verified Purchase
                  </span>
                )}
              </div>
              <div className="mb-2 flex gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={`h-3.5 w-3.5 ${i < r.rating ? "fill-gold text-gold" : "text-beige-dark"}`} />
                ))}
              </div>
              <p className="text-sm text-charcoal-light">{r.text}</p>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
