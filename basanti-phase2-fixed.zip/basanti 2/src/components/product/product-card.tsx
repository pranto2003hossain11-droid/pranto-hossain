"use client";

import Image from "next/image";
import Link from "next/link";
import { Heart, ShoppingBag, Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { formatPrice, cn } from "@/lib/utils";
import { useWishlistStore } from "@/store/wishlist-store";
import { useCartStore } from "@/store/cart-store";
import type { Product } from "@/lib/types";

export function ProductCard({ product }: { product: Product }) {
  const wishlisted = useWishlistStore((s) => s.has(product.id));
  const toggleWishlist = useWishlistStore((s) => s.toggle);
  const addItem = useCartStore((s) => s.addItem);
  const discount = product.compareAtPrice
    ? Math.round(100 - (product.price / product.compareAtPrice) * 100)
    : null;

  return (
    <div className="group relative">
      <Link href={`/product/${product.slug}`} className="block">
        <div className="relative aspect-[3/4] overflow-hidden rounded-md bg-beige">
          <Image
            src={product.image}
            alt={product.name}
            fill
            sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 25vw"
            className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          />
          <div className="absolute left-3 top-3 flex flex-col gap-1.5">
            {product.isNew && <Badge variant="gold">New</Badge>}
            {discount && <Badge variant="sale">-{discount}%</Badge>}
            {product.isBestSeller && <Badge variant="maroon">Best Seller</Badge>}
          </div>
          {product.stock === 0 ? (
            <span className="absolute bottom-3 left-3 rounded-pill bg-charcoal/80 px-2.5 py-1 text-[11px] font-medium text-ivory">
              Sold Out
            </span>
          ) : (
            product.stock <= 5 && (
              <span className="absolute bottom-3 left-3 rounded-pill bg-charcoal/80 px-2.5 py-1 text-[11px] font-medium text-ivory">
                Only {product.stock} left
              </span>
            )
          )}
        </div>
      </Link>

      <button
        onClick={() => toggleWishlist(product)}
        aria-label={wishlisted ? "Remove from wishlist" : "Add to wishlist"}
        aria-pressed={wishlisted}
        className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/90 shadow-soft transition-transform hover:scale-110"
      >
        <Heart
          className={cn("h-4 w-4 transition-colors", wishlisted ? "fill-maroon text-maroon" : "text-charcoal")}
        />
      </button>

      {product.stock > 0 && (
        <button
          onClick={() => addItem(product, 1)}
          aria-label={`Quick add ${product.name} to cart`}
          className="absolute bottom-16 right-3 flex h-10 w-10 translate-y-2 items-center justify-center rounded-full bg-maroon text-ivory opacity-0 shadow-elevated transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100 md:flex"
        >
          <ShoppingBag className="h-4 w-4" />
        </button>
      )}

      <div className="mt-3 space-y-1">
        <p className="text-xs font-medium uppercase tracking-wider text-charcoal-muted">
          {product.category}
        </p>
        <Link href={`/product/${product.slug}`}>
          <h3 className="line-clamp-1 font-body text-sm font-medium text-charcoal hover:text-maroon">
            {product.name}
          </h3>
        </Link>
        <div className="flex items-center gap-1 text-xs text-charcoal-muted">
          <Star className="h-3 w-3 fill-gold text-gold" />
          <span>{product.rating}</span>
          <span>({product.reviewCount})</span>
        </div>
        <div className="flex items-center gap-2 pt-0.5">
          <span className="font-display text-base font-semibold text-maroon">
            {formatPrice(product.price)}
          </span>
          {product.compareAtPrice && (
            <span className="text-sm text-charcoal-muted line-through">
              {formatPrice(product.compareAtPrice)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

export function ProductCardSkeleton() {
  return (
    <div className="space-y-3">
      <div className="skeleton aspect-[3/4] rounded-md" />
      <div className="skeleton h-3 w-1/3 rounded-sm" />
      <div className="skeleton h-4 w-2/3 rounded-sm" />
      <div className="skeleton h-4 w-1/4 rounded-sm" />
    </div>
  );
}
