"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Heart, Minus, Plus, ShieldCheck, RefreshCw, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useCartStore } from "@/store/cart-store";
import { useWishlistStore } from "@/store/wishlist-store";
import type { Product } from "@/lib/types";

export function AddToCartPanel({ product }: { product: Product }) {
  const router = useRouter();
  const [size, setSize] = useState(product.sizes?.[0]);
  const [qty, setQty] = useState(1);
  const addItem = useCartStore((s) => s.addItem);
  const wishlisted = useWishlistStore((s) => s.has(product.id));
  const toggleWishlist = useWishlistStore((s) => s.toggle);
  const outOfStock = product.stock <= 0;

  const handleBuyNow = () => {
    addItem(product, qty, size);
    router.push("/checkout");
  };

  return (
    <div>
      {product.sizes && product.sizes.length > 1 && (
        <div className="mb-6">
          <p className="mb-2 text-sm font-medium text-charcoal">Size</p>
          <div className="flex flex-wrap gap-2">
            {product.sizes.map((s) => (
              <button
                key={s}
                onClick={() => setSize(s)}
                className={cn(
                  "rounded border px-4 py-2 text-sm font-medium transition-colors",
                  size === s
                    ? "border-maroon bg-maroon text-ivory"
                    : "border-beige-dark text-charcoal hover:border-maroon"
                )}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="mb-6 flex items-center gap-4">
        <p className="text-sm font-medium text-charcoal">Quantity</p>
        <div className="flex items-center gap-3 rounded-pill border border-beige-dark px-3 py-1.5">
          <button
            aria-label="Decrease quantity"
            disabled={outOfStock}
            onClick={() => setQty((q) => Math.max(1, q - 1))}
          >
            <Minus className="h-4 w-4" />
          </button>
          <span className="w-5 text-center text-sm">{qty}</span>
          <button
            aria-label="Increase quantity"
            disabled={outOfStock}
            onClick={() => setQty((q) => Math.min(product.stock, q + 1))}
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
        {outOfStock && <span className="text-xs font-medium text-maroon">Out of stock</span>}
      </div>

      <div className="hidden gap-3 md:flex">
        <Button size="lg" className="flex-1" disabled={outOfStock} onClick={() => addItem(product, qty, size)}>
          {outOfStock ? "Sold Out" : "Add to Cart"}
        </Button>
        <Button
          variant="outline"
          size="lg"
          onClick={() => toggleWishlist(product)}
          aria-pressed={wishlisted}
        >
          <Heart className={cn("h-5 w-5", wishlisted && "fill-maroon text-maroon")} />
        </Button>
      </div>
      <Button
        variant="secondary"
        size="lg"
        className="mt-3 hidden w-full md:flex"
        disabled={outOfStock}
        onClick={handleBuyNow}
      >
        Buy Now
      </Button>

      <div className="mt-8 space-y-3 border-t border-beige-dark pt-6 text-sm text-charcoal-light">
        <p className="flex items-center gap-2">
          <Truck className="h-4 w-4 text-maroon" /> Free shipping on orders over ৳3,000
        </p>
        <p className="flex items-center gap-2">
          <RefreshCw className="h-4 w-4 text-maroon" /> 7-day easy returns
        </p>
        <p className="flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-maroon" /> Secure checkout, Cash on Delivery available
        </p>
      </div>

      {/* Sticky mobile add-to-cart bar */}
      <div className="fixed inset-x-0 bottom-16 z-30 flex items-center gap-3 border-t border-beige-dark bg-ivory p-3 shadow-elevated md:hidden">
        <Button variant="outline" size="icon" onClick={() => toggleWishlist(product)} aria-pressed={wishlisted}>
          <Heart className={cn("h-5 w-5", wishlisted && "fill-maroon text-maroon")} />
        </Button>
        <Button size="lg" className="flex-1" disabled={outOfStock} onClick={() => addItem(product, qty, size)}>
          {outOfStock ? "Sold Out" : "Add to Cart"}
        </Button>
      </div>
    </div>
  );
}
