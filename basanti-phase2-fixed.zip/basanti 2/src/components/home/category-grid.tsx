"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";

interface CategoryRow {
  id: string;
  name: string;
  slug: string;
  image: string | null;
}

export function CategoryGrid() {
  const [categories, setCategories] = useState<CategoryRow[]>([]);

  useEffect(() => {
    fetch("/api/categories")
      .then((res) => res.json())
      .then((data: { categories?: CategoryRow[] }) => setCategories(data.categories ?? []))
      .catch(() => setCategories([]));
  }, []);

  if (categories.length === 0) return null;

  return (
    <section className="section-spacing container-padded">
      <div className="mb-10 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Explore</p>
        <h2 className="mt-2 font-display text-display-sm md:text-display-md">Shop by Category</h2>
      </div>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6">
        {categories.map((cat) => (
          <Link
            key={cat.id}
            href={`/category/${cat.slug}`}
            className="group relative block overflow-hidden rounded-md bg-beige"
          >
            <div className="relative aspect-[3/4]">
              {cat.image && (
                <Image
                  src={cat.image}
                  alt={cat.name}
                  fill
                  sizes="(max-width: 768px) 50vw, 25vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 via-transparent to-transparent" />
              <span className="absolute bottom-4 left-4 font-display text-lg font-semibold text-ivory">
                {cat.name}
              </span>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
