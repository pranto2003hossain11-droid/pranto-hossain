import Image from "next/image";
import { Gem, Hand, Leaf, Truck } from "lucide-react";

const reasons = [
  { icon: Hand, title: "Handcrafted Detail", desc: "Every piece finished by skilled artisans across Bangladesh." },
  { icon: Gem, title: "Premium Materials", desc: "Sourced fabrics chosen for texture, drape, and durability." },
  { icon: Leaf, title: "Mindful Production", desc: "Small batches made to order, reducing waste." },
  { icon: Truck, title: "Nationwide Delivery", desc: "Fast, trackable shipping to every district." },
];

export function BrandStory() {
  return (
    <section className="section-spacing container-padded grid grid-cols-1 items-center gap-12 md:grid-cols-2">
      <div className="relative aspect-[4/5] overflow-hidden rounded-md">
        <Image
          src="https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=1000"
          alt="Artisan hand-finishing embroidery for a Basanti garment"
          fill
          sizes="(max-width: 768px) 100vw, 50vw"
          className="object-cover"
        />
      </div>
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Our Craft</p>
        <h2 className="mt-2 font-display text-display-sm md:text-display-md">
          Rooted in tradition, made for today
        </h2>
        <p className="mt-4 max-w-md text-charcoal-light">
          Basanti Boutiques &amp; House works directly with weavers and tailors across
          Bangladesh, blending heritage techniques with contemporary silhouettes.
        </p>
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2">
          {reasons.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="flex gap-3">
              <Icon className="h-6 w-6 shrink-0 text-maroon" />
              <div>
                <p className="text-sm font-semibold text-charcoal">{title}</p>
                <p className="text-xs text-charcoal-muted">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
