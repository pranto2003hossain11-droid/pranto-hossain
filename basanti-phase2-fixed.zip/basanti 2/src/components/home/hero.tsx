"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { buttonVariants } from "@/components/ui/button";

interface Banner {
  id: string;
  image: string;
  title: string;
  subtitle: string | null;
  buttonText: string | null;
  buttonLink: string | null;
  sortOrder: number;
}

export function Hero() {
  const [current, setCurrent] = useState(0);
  const [slides, setSlides] = useState<Banner[]>([]);

  useEffect(() => {
    fetch("/api/banners")
      .then((res) => res.json())
      .then((data: { banners?: Banner[] }) => setSlides(data.banners ?? []))
      .catch(() => setSlides([]));
  }, []);

  const active = slides[Math.min(current, Math.max(slides.length - 1, 0))];

  useEffect(() => {
    if (slides.length === 0) return;
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [slides.length]);

  if (!active) return null;

  return (
    <section className="relative overflow-hidden bg-beige">
      <div className="container-padded grid grid-cols-1 items-center gap-10 py-12 md:grid-cols-2 md:py-0">
        <div className="order-2 md:order-1 md:py-24">
          <p className="mb-4 text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">
            Basanti Boutiques & House
          </p>

          <h1 className="font-display text-display-md leading-tight text-charcoal md:text-display-lg">
            {active.title}
          </h1>

          {active.subtitle && (
            <p className="mt-5 max-w-md text-charcoal-light">{active.subtitle}</p>
          )}

          <div className="mt-8 flex flex-wrap gap-4">
            {active.buttonText && active.buttonLink && (
              <Link href={active.buttonLink} className={buttonVariants({ size: "lg" })}>
                {active.buttonText}
              </Link>
            )}

            <Link
              href="/about"
              className={buttonVariants({
                variant: "outline",
                size: "lg",
              })}
            >
              Learn More
            </Link>
          </div>
        </div>

        <div className="order-1 md:order-2">
          <div className="relative aspect-[4/5] w-full overflow-hidden rounded-md md:aspect-[3/4]">
            {slides.map((slide, index) => (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                key={slide.id}
                src={slide.image}
                alt={slide.title}
                className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${
                  current === index ? "opacity-100" : "opacity-0"
                }`}
              />
            ))}
          </div>

          <div className="mt-5 flex justify-center gap-2">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrent(index)}
                className={`h-2 w-2 rounded-full transition-all ${
                  current === index
                    ? "w-6 bg-gold-600"
                    : "bg-gray-300"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}