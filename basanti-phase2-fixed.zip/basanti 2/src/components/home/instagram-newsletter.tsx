'use client';

import Image from "next/image";
import { Instagram } from "lucide-react";
import { Button } from "@/components/ui/button";

const igImages = [
  "https://images.unsplash.com/photo-1610189844058-91c6e2c92db4?w=400",
  "https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=400",
  "https://images.unsplash.com/photo-1591369822096-ffd140ec948f?w=400",
  "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400",
  "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=400",
  "https://images.unsplash.com/photo-1485968579580-b6d095142e6e?w=400",
];

export function InstagramGallery() {
  return (
    <section className="section-spacing container-padded">
      <div className="mb-8 flex items-center justify-center gap-2 text-center">
        <Instagram className="h-5 w-5 text-maroon" />
        <h2 className="font-display text-xl font-semibold">@basanti.boutiques</h2>
      </div>
      <div className="grid grid-cols-3 gap-2 md:grid-cols-6">
        {igImages.map((src, i) => (
          <div key={i} className="relative aspect-square overflow-hidden rounded-sm">
            <Image src={src} alt="Customer styled in Basanti fashion" fill sizes="200px" className="object-cover transition-transform duration-500 hover:scale-110" />
          </div>
        ))}
      </div>
    </section>
  );
}

export function NewsletterSection() {
  return (
    <section className="bg-maroon-900">
      <div className="container-padded flex flex-col items-center gap-5 py-16 text-center text-ivory">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-200">Stay In The Loop</p>
        <h2 className="max-w-lg font-display text-display-sm md:text-display-md">
          Be first to know about new collections and member-only offers
        </h2>
        <form
          className="mt-2 flex w-full max-w-md gap-2"
          onSubmit={(e) => e.preventDefault()}
        >
          <input
            type="email"
            required
            placeholder="Enter your email"
            aria-label="Email address"
            className="w-full rounded bg-ivory/10 px-4 py-3 text-sm text-ivory placeholder:text-ivory/40 focus:bg-ivory/15"
          />
          <Button type="submit" variant="secondary" className="shrink-0">
            Subscribe
          </Button>
        </form>
      </div>
    </section>
  );
}
