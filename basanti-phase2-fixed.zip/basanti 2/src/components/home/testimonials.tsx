import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Nusrat J.",
    text: "The fabric quality is unlike anything I've ordered online before. Fit was perfect and delivery was quick.",
    rating: 5,
  },
  {
    name: "Farhana A.",
    text: "Beautiful packaging, beautiful saree. Customer support helped me pick the right size over WhatsApp.",
    rating: 5,
  },
  {
    name: "Tasnim R.",
    text: "Basanti has become my go-to for festive wear. The fusion kurtis are so well tailored.",
    rating: 4,
  },
];

export function Testimonials() {
  return (
    <section className="section-spacing bg-beige">
      <div className="container-padded">
        <div className="mb-10 text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Loved By Customers</p>
          <h2 className="mt-2 font-display text-display-sm md:text-display-md">What They&apos;re Saying</h2>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
          {testimonials.map((t) => (
            <div key={t.name} className="rounded-md bg-white p-6 shadow-soft">
              <div className="mb-3 flex gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${i < t.rating ? "fill-gold text-gold" : "text-beige-dark"}`}
                  />
                ))}
              </div>
              <p className="text-sm leading-relaxed text-charcoal-light">&ldquo;{t.text}&rdquo;</p>
              <p className="mt-4 text-sm font-semibold text-charcoal">{t.name}</p>
              <p className="text-xs text-charcoal-muted">Verified Purchase</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
