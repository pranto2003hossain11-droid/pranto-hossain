"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { buttonVariants } from "@/components/ui/button";

function getTimeLeft(target: number) {
  const diff = Math.max(target - Date.now(), 0);
  return {
    h: Math.floor(diff / 3_600_000),
    m: Math.floor((diff % 3_600_000) / 60_000),
    s: Math.floor((diff % 60_000) / 1000),
  };
}

export function FlashSale() {
  // `target` and `time` are only ever computed on the client (inside
  // useEffect) so the server-rendered markup and the client's first render
  // both show the same static "00:00:00" placeholder. Computing Date.now()
  // during render would make the server's HTML disagree with the client's
  // hydration render — worse still for statically generated pages, where the
  // server value could be hours old by the time a visitor loads the page.
  const [time, setTime] = useState<{ h: number; m: number; s: number } | null>(null);

  useEffect(() => {
    const target = Date.now() + 1000 * 60 * 60 * 18;
    setTime(getTimeLeft(target));
    const id = setInterval(() => setTime(getTimeLeft(target)), 1000);
    return () => clearInterval(id);
  }, []);

  const display = time ?? { h: 0, m: 0, s: 0 };

  return (
    <section className="bg-maroon py-12 text-ivory">
      <div className="container-padded flex flex-col items-center gap-6 text-center md:flex-row md:justify-between md:text-left">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-200">Flash Sale</p>
          <h2 className="mt-2 font-display text-display-sm md:text-display-md">Up to 30% Off — Today Only</h2>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex gap-3" role="timer" aria-label="Time remaining for flash sale">
            {[
              { label: "Hrs", value: display.h },
              { label: "Min", value: display.m },
              { label: "Sec", value: display.s },
            ].map((t) => (
              <div key={t.label} className="flex w-14 flex-col items-center rounded bg-ivory/10 py-2">
                <span className="font-display text-xl font-semibold">{String(t.value).padStart(2, "0")}</span>
                <span className="text-[10px] uppercase tracking-wide text-ivory/70">{t.label}</span>
              </div>
            ))}
          </div>
          <Link href="/shop?filter=sale" className={buttonVariants({ variant: "secondary", size: "lg" })}>
            Shop Sale
          </Link>
        </div>
      </div>
    </section>
  );
}
