import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { ProductCard } from "@/components/product/product-card";
import type { Product } from "@/lib/types";

export function ProductSection({
  title,
  eyebrow,
  products,
  viewAllHref,
}: {
  title: string;
  eyebrow: string;
  products: Product[];
  viewAllHref: string;
}) {
  return (
    <section className="section-spacing container-padded">
      <div className="mb-8 flex items-end justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">{eyebrow}</p>
          <h2 className="mt-2 font-display text-display-sm md:text-display-md">{title}</h2>
        </div>
        <Link
          href={viewAllHref}
          className="hidden items-center gap-1 text-sm font-medium text-maroon hover:underline md:flex"
        >
          View All <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
      <div className="grid grid-cols-2 gap-x-4 gap-y-8 md:grid-cols-4 md:gap-x-6">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
      <div className="mt-8 text-center md:hidden">
        <Link href={viewAllHref} className="text-sm font-medium text-maroon hover:underline">
          View All →
        </Link>
      </div>
    </section>
  );
}
