"use client";

import { useEffect } from "react";
import { useCartStore } from "@/store/cart-store";
import { useWishlistStore } from "@/store/wishlist-store";

/**
 * The customer-facing cart/wishlist stores use `skipHydration` so the
 * server-rendered markup and the client's first render both start from the
 * same empty state (avoiding a hydration mismatch). Once mounted, we
 * manually rehydrate from localStorage so returning visitors see their
 * saved cart/wishlist.
 *
 * Admin stores are no longer persisted to localStorage — they're backed by
 * the database and each admin page fetches what it needs on mount (see the
 * `fetch*` actions in src/store/admin/*.ts).
 */
export function StoreHydration() {
  useEffect(() => {
    useCartStore.persist.rehydrate();
    useWishlistStore.persist.rehydrate();
  }, []);

  return null;
}
