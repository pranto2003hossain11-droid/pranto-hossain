"use client";

import Image from "next/image";
import Link from "next/link";
import { X, Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useCartStore } from "@/store/cart-store";
import { formatPrice } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";

export function CartDrawer() {
  const { items, isOpen, closeCart, removeItem, updateQuantity, subtotal } = useCartStore();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60]" role="dialog" aria-modal="true" aria-label="Shopping cart">
      <div className="absolute inset-0 bg-charcoal/40" onClick={closeCart} />
      <div className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-ivory shadow-elevated animate-fadeIn">
        <div className="flex items-center justify-between border-b border-beige-dark px-5 py-4">
          <h2 className="font-display text-lg font-semibold">Your Cart ({items.length})</h2>
          <button onClick={closeCart} aria-label="Close cart">
            <X className="h-5 w-5 text-charcoal" />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
            <ShoppingBag className="h-10 w-10 text-charcoal-muted" />
            <p className="text-charcoal-light">Your cart is empty.</p>
            <Link href="/shop" onClick={closeCart} className={buttonVariants({ size: "md" })}>
              Start Shopping
            </Link>
          </div>
        ) : (
          <>
            <div className="flex-1 space-y-5 overflow-y-auto px-5 py-5">
              {items.map((item) => (
                <div key={`${item.product.id}-${item.size ?? "default"}`} className="flex gap-3">
                  <div className="relative h-20 w-16 shrink-0 overflow-hidden rounded-sm bg-beige">
                    <Image src={item.product.image} alt={item.product.name} fill sizes="64px" className="object-cover" />
                  </div>
                  <div className="flex flex-1 flex-col justify-between">
                    <div className="flex justify-between gap-2">
                      <div>
                        <p className="line-clamp-2 text-sm font-medium">{item.product.name}</p>
                        {item.size && <p className="text-xs text-charcoal-muted">Size: {item.size}</p>}
                      </div>
                      <button onClick={() => removeItem(item.product.id, item.size)} aria-label="Remove item">
                        <Trash2 className="h-4 w-4 text-charcoal-muted hover:text-maroon" />
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 rounded-pill border border-beige-dark px-2 py-1">
                        <button
                          aria-label="Decrease quantity"
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1, item.size)}
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="w-4 text-center text-xs">{item.quantity}</span>
                        <button
                          aria-label="Increase quantity"
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1, item.size)}
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                      <span className="text-sm font-semibold text-maroon">
                        {formatPrice(item.product.price * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-beige-dark px-5 py-5">
              <div className="mb-4 flex justify-between text-sm font-medium">
                <span>Subtotal</span>
                <span className="text-maroon">{formatPrice(subtotal())}</span>
              </div>
              <Link
                href="/checkout"
                onClick={closeCart}
                className={buttonVariants({ size: "lg", className: "w-full" })}
              >
                Checkout
              </Link>
              <Link
                href="/cart"
                onClick={closeCart}
                className={buttonVariants({ variant: "ghost", size: "md", className: "mt-2 w-full" })}
              >
                View Cart
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
