"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Search, Heart, ShoppingBag, User, Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCartStore } from "@/store/cart-store";
import { useWishlistStore } from "@/store/wishlist-store";

const navLinks = [
  { label: "New Arrivals", href: "/shop?filter=new" },
  { label: "Sarees", href: "/category/sarees" },
  { label: "Fusion Wear", href: "/category/fusion-wear" },
  { label: "Accessories", href: "/category/accessories" },
  { label: "Collections", href: "/collection" },
  { label: "About", href: "/about" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const cartCount = useCartStore((s) => s.count());
  const openCart = useCartStore((s) => s.openCart);
  const wishlistCount = useWishlistStore((s) => s.items.length);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-300",
        scrolled ? "bg-ivory/95 shadow-soft backdrop-blur-sm" : "bg-ivory"
      )}
    >
      <div className="hidden items-center justify-center bg-maroon py-2 text-center text-xs font-medium tracking-wide text-ivory md:flex">
        Free shipping across Bangladesh on orders over ৳3,000
      </div>

      <div className="container-padded flex h-16 items-center justify-between md:h-20">
        <button
          className="md:hidden"
          onClick={() => setMobileOpen(true)}
          aria-label="Open menu"
        >
          <Menu className="h-6 w-6 text-charcoal" />
        </button>

        <Link href="/" className="font-display text-xl font-semibold text-maroon md:text-2xl">
          Basanti
          <span className="block text-[10px] font-body font-medium tracking-[0.3em] text-gold">
            BOUTIQUES &amp; HOUSE
          </span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-charcoal-light transition-colors hover:text-maroon"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-1 md:gap-2">
          <Link href="/search" aria-label="Search" className="hidden rounded-full p-2 hover:bg-beige md:flex">
            <Search className="h-5 w-5 text-charcoal" />
          </Link>
          <Link href="/account" aria-label="Account" className="hidden rounded-full p-2 hover:bg-beige md:flex">
            <User className="h-5 w-5 text-charcoal" />
          </Link>
          <Link href="/wishlist" aria-label="Wishlist" className="relative hidden rounded-full p-2 hover:bg-beige md:flex">
            <Heart className="h-5 w-5 text-charcoal" />
            {wishlistCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-maroon text-[10px] font-semibold text-ivory">
                {wishlistCount}
              </span>
            )}
          </Link>
          <button onClick={openCart} aria-label="Open cart" className="relative rounded-full p-2 hover:bg-beige">
            <ShoppingBag className="h-5 w-5 text-charcoal" />
            {cartCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-maroon text-[10px] font-semibold text-ivory">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 bg-charcoal/40 md:hidden" onClick={() => setMobileOpen(false)}>
          <div
            className="h-full w-[85%] max-w-sm animate-fadeIn bg-ivory p-6 shadow-elevated"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-8 flex items-center justify-between">
              <span className="font-display text-lg font-semibold text-maroon">Menu</span>
              <button onClick={() => setMobileOpen(false)} aria-label="Close menu">
                <X className="h-6 w-6 text-charcoal" />
              </button>
            </div>
            <nav className="flex flex-col gap-5">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="text-base font-medium text-charcoal"
                  onClick={() => setMobileOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
