"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Search, Heart, ShoppingBag, User } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { label: "Home", href: "/", icon: Home },
  { label: "Shop", href: "/shop", icon: Search },
  { label: "Wishlist", href: "/wishlist", icon: Heart },
  { label: "Cart", href: "/cart", icon: ShoppingBag },
  { label: "Account", href: "/account", icon: User },
];

export function MobileNav() {
  const pathname = usePathname();

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 flex h-16 items-center justify-around border-t border-beige-dark bg-ivory/95 backdrop-blur-sm md:hidden"
      aria-label="Mobile navigation"
    >
      {items.map(({ label, href, icon: Icon }) => {
        const active = pathname === href;
        return (
          <Link
            key={href}
            href={href}
            className="flex flex-col items-center gap-1 px-3 py-1.5"
            aria-current={active ? "page" : undefined}
          >
            <Icon className={cn("h-5 w-5", active ? "text-maroon" : "text-charcoal-muted")} />
            <span className={cn("text-[10px] font-medium", active ? "text-maroon" : "text-charcoal-muted")}>
              {label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
