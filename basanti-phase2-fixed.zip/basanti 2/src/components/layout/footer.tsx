import Link from "next/link";
import { Facebook, Instagram, Mail, MapPin, Phone, ShieldCheck, Truck, RefreshCw } from "lucide-react";
import { FooterNewsletterForm } from "@/components/layout/footer-newsletter-form";

const columns = [
  {
    title: "Shop",
    links: [
      { label: "New Arrivals", href: "/shop?filter=new" },
      { label: "Sarees", href: "/category/sarees" },
      { label: "Fusion Wear", href: "/category/fusion-wear" },
      { label: "Accessories", href: "/category/accessories" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "Contact Us", href: "/contact" },
      { label: "FAQ", href: "/faq" },
      { label: "Order Tracking", href: "/order-tracking" },
      { label: "Returns & Exchanges", href: "/policies/returns" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About Us", href: "/about" },
      { label: "Our Story", href: "/about#story" },
      { label: "Blog", href: "/blog" },
      { label: "Privacy Policy", href: "/policies/privacy" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="mt-16 bg-charcoal text-ivory">
      <div className="border-b border-ivory/10">
        <div className="container-padded grid grid-cols-1 gap-6 py-8 sm:grid-cols-3">
          {[
            { icon: Truck, title: "Free Shipping", desc: "On orders over ৳3,000" },
            { icon: RefreshCw, title: "Easy Returns", desc: "7-day return policy" },
            { icon: ShieldCheck, title: "Secure Checkout", desc: "100% protected payments" },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="flex items-center gap-3">
              <Icon className="h-7 w-7 text-gold" />
              <div>
                <p className="text-sm font-semibold">{title}</p>
                <p className="text-xs text-ivory/60">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="container-padded grid grid-cols-1 gap-10 py-14 sm:grid-cols-2 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <h3 className="font-display text-2xl font-semibold text-gold">Basanti</h3>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-ivory/70">
            Premium fashion for the modern Bangladeshi wardrobe — sarees, fusion wear, and
            curated collections crafted with elegance.
          </p>
          <div className="mt-5 space-y-2 text-sm text-ivory/70">
            <p className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-gold" /> Gulshan Avenue, Dhaka, Bangladesh
            </p>
            <p className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-gold" /> +880 1XXX-XXXXXX
            </p>
            <p className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-gold" /> hello@basantiboutiques.com
            </p>
          </div>
          <div className="mt-5 flex gap-3">
            <Link href="#" aria-label="Facebook" className="rounded-full bg-ivory/10 p-2 hover:bg-ivory/20">
              <Facebook className="h-4 w-4" />
            </Link>
            <Link href="#" aria-label="Instagram" className="rounded-full bg-ivory/10 p-2 hover:bg-ivory/20">
              <Instagram className="h-4 w-4" />
            </Link>
          </div>
        </div>

        {columns.map((col) => (
          <div key={col.title}>
            <h4 className="mb-4 text-sm font-semibold uppercase tracking-wider text-gold">{col.title}</h4>
            <ul className="space-y-2.5">
              {col.links.map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm text-ivory/70 hover:text-ivory">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}

        <div className="sm:col-span-2 lg:col-span-1">
          <h4 className="mb-4 text-sm font-semibold uppercase tracking-wider text-gold">Newsletter</h4>
          <p className="mb-3 text-sm text-ivory/70">Get early access to new collections and offers.</p>
          <FooterNewsletterForm />
        </div>
      </div>

      <div className="border-t border-ivory/10 py-6">
        <p className="container-padded text-center text-xs text-ivory/50">
          © {new Date().getFullYear()} Basanti Boutiques &amp; House. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
