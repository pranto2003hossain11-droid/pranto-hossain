"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";

export function FooterNewsletterForm() {
  const [subscribed, setSubscribed] = useState(false);

  if (subscribed) {
    return <p className="text-sm text-gold">You&apos;re on the list — thank you!</p>;
  }

  return (
    <form
      className="flex gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        setSubscribed(true);
      }}
    >
      <input
        type="email"
        required
        placeholder="Your email"
        aria-label="Email address"
        className="w-full rounded bg-ivory/10 px-3 py-2.5 text-sm text-ivory placeholder:text-ivory/40 focus:bg-ivory/15"
      />
      <Button type="submit" variant="secondary" size="md" className="shrink-0">
        Join
      </Button>
    </form>
  );
}
