"use client";

import { usePathname } from "next/navigation";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { MobileNav } from "@/components/layout/mobile-nav";
import { CartDrawer } from "@/components/cart/cart-drawer";
import { FloatingWhatsApp } from "@/components/layout/floating-whatsapp";

/**
 * The Admin Panel lives at /admin and renders its own shell (sidebar, topbar)
 * via `AdminShell`, so the public storefront chrome (navbar, footer, mobile
 * nav, cart drawer, WhatsApp bubble) is skipped there. Every other route
 * keeps the exact same layout it always had.
 */
export function RouteChrome({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isAdmin = pathname?.startsWith("/admin");

  if (isAdmin) {
    return <>{children}</>;
  }

  return (
    <>
      <Navbar />
      <main className="flex-1 pb-16 md:pb-0">{children}</main>
      <Footer />
      <MobileNav />
      <CartDrawer />
      <FloatingWhatsApp />
    </>
  );
}
