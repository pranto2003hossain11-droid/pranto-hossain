"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const sizes = ["S", "M", "L", "XL"];

export interface PriceRange {
  label: string;
  min: number;
  max: number;
}

export const priceRanges: PriceRange[] = [
  { label: "Under ৳3,000", min: 0, max: 3000 },
  { label: "৳3,000 – ৳6,000", min: 3000, max: 6000 },
  { label: "৳6,000 – ৳10,000", min: 6000, max: 10000 },
  { label: "Above ৳10,000", min: 10000, max: Infinity },
];

function FilterGroup({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="border-b border-beige-dark py-4">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between text-sm font-semibold text-charcoal"
      >
        {title}
        <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} />
      </button>
      {open && <div className="mt-3 space-y-2">{children}</div>}
    </div>
  );
}

export function ShopFilters({
  categories,
  selectedCategories,
  onToggleCategory,
  selectedSizes,
  onToggleSize,
  selectedPriceRange,
  onSelectPriceRange,
}: {
  categories: string[];
  selectedCategories: string[];
  onToggleCategory: (cat: string) => void;
  selectedSizes: string[];
  onToggleSize: (size: string) => void;
  selectedPriceRange: string | null;
  onSelectPriceRange: (label: string | null) => void;
}) {
  return (
    <aside className="w-full md:w-56 md:shrink-0">
      <FilterGroup title="Category">
        {categories.map((cat) => (
          <label key={cat} className="flex items-center gap-2 text-sm text-charcoal-light">
            <input
              type="checkbox"
              checked={selectedCategories.includes(cat)}
              onChange={() => onToggleCategory(cat)}
              className="h-4 w-4 rounded border-beige-dark text-maroon focus:ring-maroon"
            />
            {cat}
          </label>
        ))}
      </FilterGroup>
      <FilterGroup title="Size">
        {sizes.map((s) => (
          <label key={s} className="flex items-center gap-2 text-sm text-charcoal-light">
            <input
              type="checkbox"
              checked={selectedSizes.includes(s)}
              onChange={() => onToggleSize(s)}
              className="h-4 w-4 rounded border-beige-dark text-maroon focus:ring-maroon"
            />
            {s}
          </label>
        ))}
      </FilterGroup>
      <FilterGroup title="Price">
        {priceRanges.map((p) => (
          <label key={p.label} className="flex items-center gap-2 text-sm text-charcoal-light">
            <input
              type="radio"
              name="price"
              checked={selectedPriceRange === p.label}
              onChange={() => onSelectPriceRange(selectedPriceRange === p.label ? null : p.label)}
              className="h-4 w-4 border-beige-dark text-maroon focus:ring-maroon"
            />
            {p.label}
          </label>
        ))}
      </FilterGroup>
      {(selectedSizes.length > 0 || selectedPriceRange) && (
        <button
          onClick={() => {
            selectedSizes.forEach((s) => onToggleSize(s));
            onSelectPriceRange(null);
          }}
          className="mt-3 text-xs font-medium text-maroon hover:underline"
        >
          Clear size &amp; price filters
        </button>
      )}
    </aside>
  );
}
