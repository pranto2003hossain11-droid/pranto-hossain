"use client";

import { useEffect, useMemo, useState } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import type { Product } from "@/lib/types";
import { ProductCard } from "@/components/product/product-card";
import { ShopFilters, priceRanges } from "@/components/shop/shop-filters";
import { Button } from "@/components/ui/button";

type SortKey = "featured" | "price-asc" | "price-desc" | "rating";

export function ShopPageClient({ initialFilter }: { initialFilter?: string }) {
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [selectedPriceRange, setSelectedPriceRange] = useState<string | null>(null);
  const [sort, setSort] = useState<SortKey>("featured");
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  useEffect(() => {
    fetch("/api/products?pageSize=60")
      .then((res) => res.json())
      .then((data) => setAllProducts(data.products ?? []))
      .catch(() => setAllProducts([]));
  }, []);

  const toggleCategory = (cat: string) =>
    setSelectedCategories((prev) => (prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]));

  const toggleSize = (size: string) =>
    setSelectedSizes((prev) => (prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]));

  const categoryList = useMemo(
    () => Array.from(new Set(allProducts.map((p) => p.category))).filter(Boolean).sort(),
    [allProducts]
  );

  const filtered = useMemo(() => {
    let list = allProducts;
    if (selectedCategories.length > 0) {
      list = list.filter((p) => selectedCategories.includes(p.category));
    }
    if (selectedSizes.length > 0) {
      list = list.filter((p) => p.sizes?.some((s) => selectedSizes.includes(s)));
    }
    if (selectedPriceRange) {
      const range = priceRanges.find((r) => r.label === selectedPriceRange);
      if (range) list = list.filter((p) => p.price >= range.min && p.price < range.max);
    }
    if (initialFilter === "new") list = list.filter((p) => p.isNew);
    if (initialFilter === "best-seller") list = list.filter((p) => p.isBestSeller);
    if (initialFilter === "sale") list = list.filter((p) => p.compareAtPrice);

    const sorted = [...list];
    if (sort === "price-asc") sorted.sort((a, b) => a.price - b.price);
    if (sort === "price-desc") sorted.sort((a, b) => b.price - a.price);
    if (sort === "rating") sorted.sort((a, b) => b.rating - a.rating);
    return sorted;
  }, [allProducts, selectedCategories, selectedSizes, selectedPriceRange, sort, initialFilter]);

  return (
    <div className="container-padded section-spacing">
      <div className="mb-8 flex items-end justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold-600">Shop</p>
          <h1 className="mt-2 font-display text-display-sm md:text-display-md">All Products</h1>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" className="md:hidden" onClick={() => setMobileFiltersOpen(true)}>
            <SlidersHorizontal className="h-4 w-4" /> Filters
          </Button>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            aria-label="Sort products"
            className="rounded border border-beige-dark bg-white px-3 py-2 text-sm"
          >
            <option value="featured">Featured</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="rating">Top Rated</option>
          </select>
        </div>
      </div>

      <div className="flex flex-col gap-10 md:flex-row">
        <div className="hidden md:block">
          <ShopFilters
              categories={categoryList}
              selectedCategories={selectedCategories}
              onToggleCategory={toggleCategory}
              selectedSizes={selectedSizes}
              onToggleSize={toggleSize}
              selectedPriceRange={selectedPriceRange}
              onSelectPriceRange={setSelectedPriceRange}
            />
        </div>

        {mobileFiltersOpen && (
          <div className="fixed inset-0 z-50 bg-charcoal/40 md:hidden" onClick={() => setMobileFiltersOpen(false)}>
            <div className="h-full w-[80%] max-w-xs overflow-y-auto bg-ivory p-5" onClick={(e) => e.stopPropagation()}>
              <div className="mb-4 flex items-center justify-between">
                <span className="font-semibold">Filters</span>
                <button onClick={() => setMobileFiltersOpen(false)} aria-label="Close filters">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <ShopFilters
              categories={categoryList}
              selectedCategories={selectedCategories}
              onToggleCategory={toggleCategory}
              selectedSizes={selectedSizes}
              onToggleSize={toggleSize}
              selectedPriceRange={selectedPriceRange}
              onSelectPriceRange={setSelectedPriceRange}
            />
            </div>
          </div>
        )}

        <div className="flex-1">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 py-20 text-center">
              <p className="font-display text-lg">No products match your filters</p>
              <p className="text-sm text-charcoal-muted">Try adjusting or clearing your filters.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-3 lg:gap-x-6">
              {filtered.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
