"use client";

import { create } from "zustand";
import type { StoreSettings } from "@/lib/admin-types";
import { adminApi } from "@/lib/admin-api-client";

interface ApiSettings {
  storeName: string;
  logo: string | null;
  favicon: string | null;
  phone: string;
  email: string;
  address: string;
  facebook: string | null;
  instagram: string | null;
  whatsapp: string | null;
  shippingCharge: number;
  freeShippingThreshold: number;
  currency: string;
  seoTitle: string;
  seoDescription: string;
  analyticsId: string | null;
}

function toStoreSettings(s: ApiSettings): StoreSettings {
  return {
    storeName: s.storeName,
    logo: s.logo ?? undefined,
    favicon: s.favicon ?? undefined,
    phone: s.phone,
    email: s.email,
    address: s.address,
    facebook: s.facebook ?? undefined,
    instagram: s.instagram ?? undefined,
    whatsapp: s.whatsapp ?? undefined,
    shippingCharge: s.shippingCharge,
    freeShippingThreshold: s.freeShippingThreshold,
    currency: s.currency,
    seoTitle: s.seoTitle,
    seoDescription: s.seoDescription,
    analyticsId: s.analyticsId ?? undefined,
  };
}

interface SettingsState {
  settings: StoreSettings | null;
  isLoading: boolean;
  error: string | null;
  fetchSettings: () => Promise<void>;
  updateSettings: (updates: Partial<StoreSettings>) => Promise<boolean>;
}

export const useSettingsStore = create<SettingsState>()((set) => ({
  settings: null,
  isLoading: false,
  error: null,

  fetchSettings: async () => {
    set({ isLoading: true, error: null });
    try {
      const data = await adminApi.get<{ settings: ApiSettings }>("/api/admin/settings");
      set({ settings: toStoreSettings(data.settings), isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to load settings.", isLoading: false });
    }
  },

  updateSettings: async (updates) => {
    try {
      const data = await adminApi.put<{ settings: ApiSettings }>("/api/admin/settings", updates);
      set({ settings: toStoreSettings(data.settings) });
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to update settings." });
      return false;
    }
  },
}));
