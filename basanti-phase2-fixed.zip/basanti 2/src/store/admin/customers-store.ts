"use client";

import { create } from "zustand";
import type { Customer } from "@/lib/admin-types";
import { adminApi } from "@/lib/admin-api-client";
import { customerStatusToUi, customerStatusToApi } from "@/lib/admin-mappers";

interface ApiCustomer {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  avatar: string | null;
  address: string | null;
  status: string;
  orderCount?: number;
  totalSpent?: number;
  createdAt: string;
}

function toCustomer(c: ApiCustomer): Customer {
  return {
    id: c.id,
    name: c.name,
    email: c.email,
    phone: c.phone ?? undefined,
    avatar: c.avatar ?? undefined,
    address: c.address ?? undefined,
    ordersCount: c.orderCount ?? 0,
    totalSpent: c.totalSpent ?? 0,
    status: customerStatusToUi(c.status),
    joinedAt: c.createdAt,
  };
}

interface CustomersState {
  customers: Customer[];
  isLoading: boolean;
  error: string | null;
  fetchCustomers: () => Promise<void>;
  toggleStatus: (id: string) => Promise<boolean>;
  getCustomer: (id: string) => Customer | undefined;
}

export const useCustomersStore = create<CustomersState>()((set, get) => ({
  customers: [],
  isLoading: false,
  error: null,

  fetchCustomers: async () => {
    set({ isLoading: true, error: null });
    try {
      const data = await adminApi.get<{ customers: ApiCustomer[] }>("/api/admin/customers");
      set({ customers: data.customers.map(toCustomer), isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to load customers.", isLoading: false });
    }
  },

  toggleStatus: async (id) => {
    const current = get().customers.find((c) => c.id === id);
    if (!current) return false;
    const nextStatus = current.status === "active" ? "inactive" : "active";
    try {
      const data = await adminApi.put<{ customer: ApiCustomer }>(`/api/admin/customers/${id}`, {
        status: customerStatusToApi(nextStatus),
      });
      set((state) => ({
        customers: state.customers.map((c) => (c.id === id ? { ...toCustomer(data.customer), ordersCount: c.ordersCount, totalSpent: c.totalSpent } : c)),
      }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to update customer status." });
      return false;
    }
  },

  getCustomer: (id) => get().customers.find((c) => c.id === id),
}));
