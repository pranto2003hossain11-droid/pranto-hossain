"use client";

import { create } from "zustand";
import type { Order, OrderStatus } from "@/lib/admin-types";
import { adminApi } from "@/lib/admin-api-client";
import { orderStatusToUi, orderStatusToApi } from "@/lib/admin-mappers";

interface ApiOrderItem {
  productId: string | null;
  name: string;
  image: string;
  size: string | null;
  quantity: number;
  price: number;
}

interface ApiOrder {
  id: string;
  orderNumber: string;
  customerId: string | null;
  customerName: string;
  customerEmail: string;
  items: ApiOrderItem[];
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  status: string;
  paymentMethod: string;
  shippingAddress: string;
  phone: string;
  couponCode: string | null;
  createdAt: string;
  updatedAt: string;
}

function toOrder(o: ApiOrder): Order {
  return {
    id: o.id,
    orderNumber: o.orderNumber,
    customerId: o.customerId ?? "",
    customerName: o.customerName,
    customerEmail: o.customerEmail,
    items: o.items.map((item) => ({
      productId: item.productId ?? "",
      name: item.name,
      image: item.image,
      size: item.size ?? undefined,
      quantity: item.quantity,
      price: item.price,
    })),
    subtotal: o.subtotal,
    shipping: o.shipping,
    discount: o.discount,
    total: o.total,
    status: orderStatusToUi(o.status),
    paymentMethod: o.paymentMethod,
    shippingAddress: o.shippingAddress,
    phone: o.phone,
    couponCode: o.couponCode ?? undefined,
    createdAt: o.createdAt,
    updatedAt: o.updatedAt,
  };
}

interface OrdersState {
  orders: Order[];
  isLoading: boolean;
  error: string | null;
  fetchOrders: () => Promise<void>;
  updateStatus: (id: string, status: OrderStatus) => Promise<boolean>;
  getOrder: (id: string) => Order | undefined;
}

export const useOrdersStore = create<OrdersState>()((set, get) => ({
  orders: [],
  isLoading: false,
  error: null,

  fetchOrders: async () => {
    set({ isLoading: true, error: null });
    try {
      const data = await adminApi.get<{ orders: ApiOrder[] }>("/api/admin/orders?pageSize=100");
      set({ orders: data.orders.map(toOrder), isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to load orders.", isLoading: false });
    }
  },

  updateStatus: async (id, status) => {
    try {
      const data = await adminApi.patch<{ order: ApiOrder }>(`/api/admin/orders/${id}`, {
        status: orderStatusToApi(status),
      });
      set((state) => ({ orders: state.orders.map((o) => (o.id === id ? toOrder(data.order) : o)) }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to update order status." });
      return false;
    }
  },

  getOrder: (id) => get().orders.find((o) => o.id === id),
}));
