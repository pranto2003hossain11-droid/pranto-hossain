"use client";

import { create } from "zustand";
import type { Category } from "@/lib/admin-types";
import { adminApi } from "@/lib/admin-api-client";

interface ApiCategory {
  id: string;
  name: string;
  slug: string;
  image: string | null;
  parentId: string | null;
  sortOrder: number;
  visible: boolean;
  createdAt: string;
  _count?: { products: number };
}

function toCategory(c: ApiCategory): Category {
  return {
    id: c.id,
    name: c.name,
    slug: c.slug,
    image: c.image ?? undefined,
    parentId: c.parentId,
    sortOrder: c.sortOrder,
    visible: c.visible,
    productCount: c._count?.products,
    createdAt: c.createdAt,
  };
}

interface CategoriesState {
  categories: Category[];
  isLoading: boolean;
  error: string | null;
  fetchCategories: () => Promise<void>;
  addCategory: (category: Omit<Category, "id" | "createdAt">) => Promise<boolean>;
  updateCategory: (id: string, updates: Partial<Category>) => Promise<boolean>;
  deleteCategory: (id: string) => Promise<{ success: boolean; error?: string }>;
  reorder: (orderedIds: string[]) => Promise<boolean>;
}

export const useCategoriesStore = create<CategoriesState>()((set, get) => ({
  categories: [],
  isLoading: false,
  error: null,

  fetchCategories: async () => {
    set({ isLoading: true, error: null });
    try {
      const data = await adminApi.get<{ categories: ApiCategory[] }>("/api/admin/categories");
      set({ categories: data.categories.map(toCategory), isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to load categories.", isLoading: false });
    }
  },

  addCategory: async (category) => {
    try {
      const data = await adminApi.post<{ category: ApiCategory }>("/api/admin/categories", category);
      set((state) => ({ categories: [...state.categories, toCategory(data.category)] }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to add category." });
      return false;
    }
  },

  updateCategory: async (id, updates) => {
    try {
      const data = await adminApi.put<{ category: ApiCategory }>(`/api/admin/categories/${id}`, updates);
      set((state) => ({
        categories: state.categories.map((c) => (c.id === id ? toCategory(data.category) : c)),
      }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to update category." });
      return false;
    }
  },

  deleteCategory: async (id) => {
    try {
      await adminApi.delete(`/api/admin/categories/${id}`);
      set((state) => ({ categories: state.categories.filter((c) => c.id !== id) }));
      return { success: true };
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to delete category.";
      set({ error: message });
      return { success: false, error: message };
    }
  },

  reorder: async (orderedIds) => {
    const previous = get().categories;
    const reordered = orderedIds
      .map((id, index) => {
        const cat = previous.find((c) => c.id === id);
        return cat ? { ...cat, sortOrder: index + 1 } : undefined;
      })
      .filter((c): c is Category => Boolean(c));
    set({ categories: reordered });
    try {
      await Promise.all(
        reordered.map((cat) => adminApi.put(`/api/admin/categories/${cat.id}`, { sortOrder: cat.sortOrder }))
      );
      return true;
    } catch (err) {
      set({ categories: previous, error: err instanceof Error ? err.message : "Failed to reorder categories." });
      return false;
    }
  },
}));
