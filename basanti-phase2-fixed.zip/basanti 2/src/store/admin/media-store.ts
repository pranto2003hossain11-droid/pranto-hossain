"use client";

import { create } from "zustand";
import type { MediaItem } from "@/lib/admin-types";
import { adminApi } from "@/lib/admin-api-client";

interface ApiMedia {
  id: string;
  url: string;
  name: string;
  folder: string;
  size: number;
  type: string;
  uploadedAt: string;
}

function toMediaItem(m: ApiMedia): MediaItem {
  return { id: m.id, url: m.url, name: m.name, folder: m.folder, size: m.size, type: m.type, uploadedAt: m.uploadedAt };
}

interface MediaState {
  items: MediaItem[];
  isLoading: boolean;
  error: string | null;
  fetchMedia: () => Promise<void>;
  /** Uploads real files (not base64) to /api/admin/media. */
  uploadFiles: (files: File[], folder?: string) => Promise<boolean>;
  deleteItem: (id: string, force?: boolean) => Promise<{ success: boolean; error?: string }>;
}

export const useMediaStore = create<MediaState>()((set) => ({
  items: [],
  isLoading: false,
  error: null,

  fetchMedia: async () => {
    set({ isLoading: true, error: null });
    try {
      const data = await adminApi.get<{ media: ApiMedia[] }>("/api/admin/media");
      set({ items: data.media.map(toMediaItem), isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to load media.", isLoading: false });
    }
  },

  uploadFiles: async (files, folder = "general") => {
    try {
      const formData = new FormData();
      files.forEach((file) => formData.append("files", file));
      formData.append("folder", folder);
      const data = await adminApi.upload<{ media: ApiMedia[] }>("/api/admin/media", formData);
      set((state) => ({ items: [...data.media.map(toMediaItem), ...state.items] }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to upload files." });
      return false;
    }
  },

  deleteItem: async (id, force = false) => {
    try {
      await adminApi.delete(`/api/admin/media/${id}${force ? "?force=true" : ""}`);
      set((state) => ({ items: state.items.filter((m) => m.id !== id) }));
      return { success: true };
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to delete media.";
      set({ error: message });
      return { success: false, error: message };
    }
  },
}));
