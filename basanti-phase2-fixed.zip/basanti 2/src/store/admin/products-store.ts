"use client";

import { create } from "zustand";
import type { Product } from "@/lib/types";
import { adminApi } from "@/lib/admin-api-client";

interface ProductsState {
  products: Product[];
  isLoading: boolean;
  error: string | null;
  fetchProducts: () => Promise<void>;
  addProduct: (product: Omit<Product, "id"> & { categoryId?: string }) => Promise<Product | null>;
  updateProduct: (id: string, updates: Partial<Product> & { categoryId?: string }) => Promise<boolean>;
  deleteProduct: (id: string) => Promise<boolean>;
  deleteProducts: (ids: string[]) => Promise<boolean>;
  duplicateProduct: (id: string) => Promise<boolean>;
  getProduct: (id: string) => Product | undefined;
}

function toApiPayload(product: Partial<Product> & { categoryId?: string }) {
  const { category: _categoryName, ...rest } = product;
  void _categoryName;
  return {
    ...rest,
    status: product.status === "draft" ? "DRAFT" : product.status === "published" ? "PUBLISHED" : undefined,
    visibility:
      product.visibility === "hidden" ? "HIDDEN" : product.visibility === "visible" ? "VISIBLE" : undefined,
  };
}

export const useProductsStore = create<ProductsState>()((set, get) => ({
  products: [],
  isLoading: false,
  error: null,

  fetchProducts: async () => {
    set({ isLoading: true, error: null });
    try {
      const data = await adminApi.get<{ products: Product[] }>(
        "/api/admin/products?pageSize=1000"
      );
      set({ products: data.products, isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to load products.", isLoading: false });
    }
  },

  addProduct: async (product) => {
    try {
      const data = await adminApi.post<{ product: Product }>(
        "/api/admin/products",
        toApiPayload(product)
      );
      set((state) => ({ products: [data.product, ...state.products] }));
      return data.product;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to create product." });
      return null;
    }
  },

  updateProduct: async (id, updates) => {
    try {
      const data = await adminApi.patch<{ product: Product }>(
        `/api/admin/products/${id}`,
        toApiPayload(updates)
      );
      set((state) => ({
        products: state.products.map((p) => (p.id === id ? data.product : p)),
      }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to update product." });
      return false;
    }
  },

  deleteProduct: async (id) => {
    try {
      await adminApi.delete(`/api/admin/products/${id}`);
      set((state) => ({ products: state.products.filter((p) => p.id !== id) }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to delete product." });
      return false;
    }
  },

  deleteProducts: async (ids) => {
    try {
      await Promise.all(ids.map((id) => adminApi.delete(`/api/admin/products/${id}`)));
      set((state) => ({ products: state.products.filter((p) => !ids.includes(p.id)) }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to delete products." });
      return false;
    }
  },

  duplicateProduct: async (id) => {
    const original = get().products.find((p) => p.id === id);
    if (!original) return false;
    try {
      const { id: _id, slug, ...rest } = original;
      void _id;
      const data = await adminApi.post<{ product: Product }>("/api/admin/products", {
        ...toApiPayload(rest),
        name: `${original.name} (Copy)`,
        slug: `${slug}-copy-${Date.now()}`,
        status: "DRAFT",
      });
      set((state) => ({ products: [data.product, ...state.products] }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to duplicate product." });
      return false;
    }
  },

  getProduct: (id) => get().products.find((p) => p.id === id),
}));
