"use client";

import { create } from "zustand";
import type { AdminUser } from "@/lib/admin-types";
import { adminApi, ApiError } from "@/lib/admin-api-client";
import { adminRoleToUi } from "@/lib/admin-mappers";

interface AdminApiUser {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar: string | null;
}

function toAdminUser(user: AdminApiUser): AdminUser {
  return {
    name: user.name,
    email: user.email,
    role: adminRoleToUi(user.role),
    avatar: user.avatar ?? undefined,
  };
}

interface AdminAuthState {
  isAuthenticated: boolean;
  user: AdminUser | null;
  isLoading: boolean;
  /** Call on app mount to hydrate `user` from the httpOnly session cookie
   * (the cookie itself already gates page access via middleware — this is
   * only for populating the UI with the signed-in admin's name/avatar). */
  checkSession: () => Promise<void>;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  updateProfile: (
    updates: Partial<{ name: string; email: string; avatar: string | null; password: string }>
  ) => Promise<{ success: boolean; error?: string }>;
}

export const useAdminAuthStore = create<AdminAuthState>()((set) => ({
  isAuthenticated: false,
  user: null,
  isLoading: true,

  checkSession: async () => {
    try {
      const data = await adminApi.get<{ user: AdminApiUser }>("/api/admin/auth/me");
      set({ isAuthenticated: true, user: toAdminUser(data.user), isLoading: false });
    } catch {
      set({ isAuthenticated: false, user: null, isLoading: false });
    }
  },

  login: async (email, password) => {
    try {
      const data = await adminApi.post<{ user: AdminApiUser }>("/api/admin/auth/login", {
        email,
        password,
      });
      set({ isAuthenticated: true, user: toAdminUser(data.user), isLoading: false });
      return { success: true };
    } catch (error) {
      const message = error instanceof ApiError ? error.message : "Login failed. Please try again.";
      return { success: false, error: message };
    }
  },

  logout: async () => {
    try {
      await adminApi.post("/api/admin/auth/logout");
    } finally {
      set({ isAuthenticated: false, user: null });
    }
  },

  updateProfile: async (updates) => {
    try {
      const data = await adminApi.patch<{ user: AdminApiUser }>("/api/admin/auth/me", updates);
      set({ user: toAdminUser(data.user) });
      return { success: true };
    } catch (error) {
      const message = error instanceof ApiError ? error.message : "Update failed. Please try again.";
      return { success: false, error: message };
    }
  },
}));
