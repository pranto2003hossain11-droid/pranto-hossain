"use client";

import { create } from "zustand";
import type { HeroSlide } from "@/lib/admin-types";
import { adminApi } from "@/lib/admin-api-client";

interface HeroState {
  slides: HeroSlide[];
  isLoading: boolean;
  error: string | null;
  fetchSlides: () => Promise<void>;
  addSlide: (slide: Omit<HeroSlide, "id" | "sortOrder">) => Promise<boolean>;
  updateSlide: (id: string, updates: Partial<HeroSlide>) => Promise<boolean>;
  deleteSlide: (id: string) => Promise<boolean>;
  reorder: (orderedIds: string[]) => Promise<boolean>;
}

export const useHeroStore = create<HeroState>()((set, get) => ({
  slides: [],
  isLoading: false,
  error: null,

  fetchSlides: async () => {
    set({ isLoading: true, error: null });
    try {
      const data = await adminApi.get<{ banners: HeroSlide[] }>("/api/admin/banners");
      set({ slides: data.banners, isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to load slides.", isLoading: false });
    }
  },

  addSlide: async (slide) => {
    try {
      const data = await adminApi.post<{ banner: HeroSlide }>("/api/admin/banners", {
        ...slide,
        sortOrder: get().slides.length,
      });
      set((state) => ({ slides: [...state.slides, data.banner] }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to add slide." });
      return false;
    }
  },

  updateSlide: async (id, updates) => {
    try {
      const data = await adminApi.patch<{ banner: HeroSlide }>(`/api/admin/banners/${id}`, updates);
      set((state) => ({ slides: state.slides.map((s) => (s.id === id ? data.banner : s)) }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to update slide." });
      return false;
    }
  },

  deleteSlide: async (id) => {
    try {
      await adminApi.delete(`/api/admin/banners/${id}`);
      set((state) => ({ slides: state.slides.filter((s) => s.id !== id) }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to delete slide." });
      return false;
    }
  },

  reorder: async (orderedIds) => {
    const previous = get().slides;
    const reordered = orderedIds
      .map((id, index) => {
        const slide = previous.find((s) => s.id === id);
        return slide ? { ...slide, sortOrder: index } : undefined;
      })
      .filter((s): s is HeroSlide => Boolean(s));
    set({ slides: reordered });
    try {
      await Promise.all(
        reordered.map((slide) =>
          adminApi.patch(`/api/admin/banners/${slide.id}`, { sortOrder: slide.sortOrder })
        )
      );
      return true;
    } catch (err) {
      set({ slides: previous, error: err instanceof Error ? err.message : "Failed to reorder slides." });
      return false;
    }
  },
}));
