"use client";

import { create } from "zustand";
import type { Review } from "@/lib/types";
import { adminApi } from "@/lib/admin-api-client";

interface ApiReview {
  id: string;
  productId: string;
  author: string;
  rating: number;
  text: string;
  verified: boolean;
  approved: boolean;
  createdAt: string;
}

function toReview(r: ApiReview): Review & { approved: boolean } {
  return {
    id: r.id,
    productId: r.productId,
    author: r.author,
    rating: r.rating,
    date: r.createdAt,
    text: r.text,
    verified: r.verified,
    approved: r.approved,
  };
}

interface ReviewsState {
  reviews: (Review & { approved: boolean })[];
  isLoading: boolean;
  error: string | null;
  fetchReviews: () => Promise<void>;
  toggleApproved: (id: string) => Promise<boolean>;
  deleteReview: (id: string) => Promise<boolean>;
}

export const useReviewsStore = create<ReviewsState>()((set, get) => ({
  reviews: [],
  isLoading: false,
  error: null,

  fetchReviews: async () => {
    set({ isLoading: true, error: null });
    try {
      const data = await adminApi.get<{ reviews: ApiReview[] }>("/api/admin/reviews");
      set({ reviews: data.reviews.map(toReview), isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to load reviews.", isLoading: false });
    }
  },

  toggleApproved: async (id) => {
    const current = get().reviews.find((r) => r.id === id);
    if (!current) return false;
    try {
      const data = await adminApi.put<{ review: ApiReview }>(`/api/admin/reviews/${id}`, {
        approved: !current.approved,
      });
      set((state) => ({ reviews: state.reviews.map((r) => (r.id === id ? toReview(data.review) : r)) }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to update review." });
      return false;
    }
  },

  deleteReview: async (id) => {
    try {
      await adminApi.delete(`/api/admin/reviews/${id}`);
      set((state) => ({ reviews: state.reviews.filter((r) => r.id !== id) }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to delete review." });
      return false;
    }
  },
}));
