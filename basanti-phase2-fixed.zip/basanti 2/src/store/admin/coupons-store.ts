"use client";

import { create } from "zustand";
import type { Coupon } from "@/lib/admin-types";
import { adminApi } from "@/lib/admin-api-client";
import { couponTypeToUi, couponTypeToApi } from "@/lib/admin-mappers";

interface ApiCoupon {
  id: string;
  code: string;
  type: string;
  value: number;
  minOrder: number | null;
  usageLimit: number | null;
  usedCount: number;
  expiryDate: string | null;
  enabled: boolean;
  createdAt: string;
}

function toCoupon(c: ApiCoupon): Coupon {
  return {
    id: c.id,
    code: c.code,
    type: couponTypeToUi(c.type),
    value: c.value,
    minOrder: c.minOrder ?? undefined,
    usageLimit: c.usageLimit ?? undefined,
    usedCount: c.usedCount,
    expiryDate: c.expiryDate ?? undefined,
    enabled: c.enabled,
    createdAt: c.createdAt,
  };
}

function toApiPayload(coupon: Partial<Coupon>) {
  return {
    ...coupon,
    type: coupon.type ? couponTypeToApi(coupon.type) : undefined,
    expiryDate: coupon.expiryDate ? new Date(coupon.expiryDate).toISOString() : coupon.expiryDate,
  };
}

interface CouponsState {
  coupons: Coupon[];
  isLoading: boolean;
  error: string | null;
  fetchCoupons: () => Promise<void>;
  addCoupon: (coupon: Omit<Coupon, "id" | "createdAt" | "usedCount">) => Promise<boolean>;
  updateCoupon: (id: string, updates: Partial<Coupon>) => Promise<boolean>;
  deleteCoupon: (id: string) => Promise<boolean>;
  toggleEnabled: (id: string) => Promise<boolean>;
}

export const useCouponsStore = create<CouponsState>()((set, get) => ({
  coupons: [],
  isLoading: false,
  error: null,

  fetchCoupons: async () => {
    set({ isLoading: true, error: null });
    try {
      const data = await adminApi.get<{ coupons: ApiCoupon[] }>("/api/admin/coupons");
      set({ coupons: data.coupons.map(toCoupon), isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to load coupons.", isLoading: false });
    }
  },

  addCoupon: async (coupon) => {
    try {
      const data = await adminApi.post<{ coupon: ApiCoupon }>("/api/admin/coupons", toApiPayload(coupon));
      set((state) => ({ coupons: [toCoupon(data.coupon), ...state.coupons] }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to create coupon." });
      return false;
    }
  },

  updateCoupon: async (id, updates) => {
    try {
      const data = await adminApi.put<{ coupon: ApiCoupon }>(`/api/admin/coupons/${id}`, toApiPayload(updates));
      set((state) => ({ coupons: state.coupons.map((c) => (c.id === id ? toCoupon(data.coupon) : c)) }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to update coupon." });
      return false;
    }
  },

  deleteCoupon: async (id) => {
    try {
      await adminApi.delete(`/api/admin/coupons/${id}`);
      set((state) => ({ coupons: state.coupons.filter((c) => c.id !== id) }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to delete coupon." });
      return false;
    }
  },

  toggleEnabled: async (id) => {
    const current = get().coupons.find((c) => c.id === id);
    if (!current) return false;
    try {
      const data = await adminApi.put<{ coupon: ApiCoupon }>(`/api/admin/coupons/${id}`, {
        enabled: !current.enabled,
      });
      set((state) => ({ coupons: state.coupons.map((c) => (c.id === id ? toCoupon(data.coupon) : c)) }));
      return true;
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to toggle coupon." });
      return false;
    }
  },
}));
