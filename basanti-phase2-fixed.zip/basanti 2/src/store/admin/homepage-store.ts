"use client";

import { create } from "zustand";
import type { HomepageSections } from "@/lib/admin-types";
import { adminApi } from "@/lib/admin-api-client";

interface SectionRow {
  key: string;
  enabled: boolean;
  sortOrder: number;
}

const KNOWN_KEYS: (keyof HomepageSections)[] = [
  "featuredProducts",
  "collections",
  "offers",
  "testimonials",
  "instagram",
  "newsletter",
];

const FALLBACK_SECTIONS: HomepageSections = {
  featuredProducts: true,
  collections: true,
  offers: true,
  testimonials: true,
  instagram: true,
  newsletter: true,
};

interface HomepageState {
  sections: HomepageSections;
  rows: SectionRow[];
  isLoading: boolean;
  error: string | null;
  fetchSections: () => Promise<void>;
  toggleSection: (key: keyof HomepageSections) => Promise<boolean>;
}

export const useHomepageStore = create<HomepageState>()((set, get) => ({
  sections: FALLBACK_SECTIONS,
  rows: [],
  isLoading: false,
  error: null,

  fetchSections: async () => {
    set({ isLoading: true, error: null });
    try {
      const data = await adminApi.get<{ sections: SectionRow[] }>("/api/admin/homepage-sections");
      const sections = { ...FALLBACK_SECTIONS };
      for (const row of data.sections) {
        if ((KNOWN_KEYS as string[]).includes(row.key)) {
          (sections as Record<string, boolean>)[row.key] = row.enabled;
        }
      }
      set({ sections, rows: data.sections, isLoading: false });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Failed to load homepage sections.", isLoading: false });
    }
  },

  toggleSection: async (key) => {
    const previous = get().sections;
    const nextEnabled = !previous[key];
    set({ sections: { ...previous, [key]: nextEnabled } });

    try {
      const rows = get().rows;
      const nextRows = rows.map((row) => (row.key === key ? { ...row, enabled: nextEnabled } : row));
      const payload = nextRows.length > 0 ? nextRows : [{ key, enabled: nextEnabled, sortOrder: 0 }];
      const data = await adminApi.put<{ sections: SectionRow[] }>("/api/admin/homepage-sections", {
        sections: payload,
      });
      set({ rows: data.sections });
      return true;
    } catch (err) {
      set({ sections: previous, error: err instanceof Error ? err.message : "Failed to update section." });
      return false;
    }
  },
}));
