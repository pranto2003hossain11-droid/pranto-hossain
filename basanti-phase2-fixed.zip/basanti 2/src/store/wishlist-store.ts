"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { Product } from "@/lib/types";

interface WishlistState {
  items: Product[];
  toggle: (product: Product) => void;
  has: (productId: string) => boolean;
}

export const useWishlistStore = create<WishlistState>()(
  persist(
    (set, get) => ({
      items: [],
      toggle: (product) =>
        set((state) => {
          const exists = state.items.some((p) => p.id === product.id);
          return {
            items: exists ? state.items.filter((p) => p.id !== product.id) : [...state.items, product],
          };
        }),
      has: (productId) => get().items.some((p) => p.id === productId),
    }),
    {
      name: "basanti-wishlist",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ items: state.items }),
      skipHydration: true,
    }
  )
);
