"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { Product } from "@/lib/types";

export interface CartItem {
  product: Product;
  quantity: number;
  size?: string;
}

/**
 * Cart items are keyed by product id + size, since the same product can be
 * added in multiple sizes and must be tracked as distinct line items.
 */
function isSameLine(item: CartItem, productId: string, size: string | undefined) {
  return item.product.id === productId && item.size === size;
}

interface CartState {
  items: CartItem[];
  isOpen: boolean;
  addItem: (product: Product, quantity?: number, size?: string) => void;
  removeItem: (productId: string, size?: string) => void;
  updateQuantity: (productId: string, quantity: number, size?: string) => void;
  clearCart: () => void;
  openCart: () => void;
  closeCart: () => void;
  subtotal: () => number;
  count: () => number;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      isOpen: false,
      addItem: (product, quantity = 1, size) =>
        set((state) => {
          const existing = state.items.find((i) => isSameLine(i, product.id, size));
          if (existing) {
            return {
              items: state.items.map((i) =>
                isSameLine(i, product.id, size) ? { ...i, quantity: i.quantity + quantity } : i
              ),
              isOpen: true,
            };
          }
          return { items: [...state.items, { product, quantity, size }], isOpen: true };
        }),
      removeItem: (productId, size) =>
        set((state) => ({
          items: state.items.filter((i) => !isSameLine(i, productId, size)),
        })),
      updateQuantity: (productId, quantity, size) =>
        set((state) => ({
          items: state.items.map((i) =>
            isSameLine(i, productId, size) ? { ...i, quantity: Math.max(1, quantity) } : i
          ),
        })),
      clearCart: () => set({ items: [] }),
      openCart: () => set({ isOpen: true }),
      closeCart: () => set({ isOpen: false }),
      subtotal: () => get().items.reduce((sum, i) => sum + i.product.price * i.quantity, 0),
      count: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
    }),
    {
      name: "basanti-cart",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ items: state.items }),
      skipHydration: true,
    }
  )
);
