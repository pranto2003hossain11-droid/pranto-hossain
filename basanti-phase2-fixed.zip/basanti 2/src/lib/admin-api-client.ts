"use client";

/**
 * Thin fetch wrapper used by every admin store. Centralizes credentials,
 * JSON headers, and error unwrapping so stores don't each reimplement it.
 */
export class ApiError extends Error {
  status: number;
  details?: unknown;

  constructor(message: string, status: number, details?: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.details = details;
  }
}

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(options?.headers ?? {}),
    },
    ...options,
  });

  const isJson = res.headers.get("content-type")?.includes("application/json");
  const body = isJson ? await res.json().catch(() => null) : null;

  if (!res.ok) {
    throw new ApiError(
      (body && typeof body === "object" && "error" in body ? String(body.error) : null) ??
        `Request failed with status ${res.status}`,
      res.status,
      body && typeof body === "object" ? (body as { details?: unknown }).details : undefined
    );
  }

  return body as T;
}

export const adminApi = {
  get: <T>(url: string) => request<T>(url),
  post: <T>(url: string, body?: unknown) =>
    request<T>(url, { method: "POST", body: body !== undefined ? JSON.stringify(body) : undefined }),
  put: <T>(url: string, body?: unknown) =>
    request<T>(url, { method: "PUT", body: body !== undefined ? JSON.stringify(body) : undefined }),
  patch: <T>(url: string, body?: unknown) =>
    request<T>(url, { method: "PATCH", body: body !== undefined ? JSON.stringify(body) : undefined }),
  delete: <T>(url: string) => request<T>(url, { method: "DELETE" }),
  /** For multipart/form-data uploads — no Content-Type header (browser sets the boundary). */
  upload: <T>(url: string, formData: FormData) =>
    fetch(url, { method: "POST", credentials: "include", body: formData }).then(async (res) => {
      const body = await res.json().catch(() => null);
      if (!res.ok) {
        throw new ApiError(body?.error ?? `Upload failed with status ${res.status}`, res.status);
      }
      return body as T;
    }),
};
