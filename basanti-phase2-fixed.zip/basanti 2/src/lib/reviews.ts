import { prisma } from "@/lib/prisma";

/** Recomputes and persists Product.rating/reviewCount from its approved
 * reviews. Call this after any review is approved, edited, or deleted. */
export async function recalculateProductRating(productId: string) {
  const approvedReviews = await prisma.review.findMany({
    where: { productId, approved: true },
    select: { rating: true },
  });

  const reviewCount = approvedReviews.length;
  const rating =
    reviewCount === 0
      ? 0
      : Math.round(
          (approvedReviews.reduce((sum: number, r: { rating: number }) => sum + r.rating, 0) /
            reviewCount) *
            10
        ) / 10;

  await prisma.product.update({
    where: { id: productId },
    data: { rating, reviewCount },
  });
}
