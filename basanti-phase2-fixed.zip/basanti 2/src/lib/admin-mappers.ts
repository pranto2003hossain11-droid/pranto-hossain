/**
 * The UI's existing types (admin-types.ts / types.ts) use human-readable
 * string literals ("Pending", "percentage", "active"...) while the Prisma
 * schema uses UPPERCASE enums (PENDING, PERCENTAGE, ACTIVE...). These
 * mappers are the only place that conversion happens, so every store stays
 * consistent and the existing UI components never need to know about the
 * database's enum casing.
 */
import type { OrderStatus as UiOrderStatus, AdminUser } from "@/lib/admin-types";

const ORDER_STATUS_TO_UI: Record<string, UiOrderStatus> = {
  PENDING: "Pending",
  CONFIRMED: "Confirmed",
  PROCESSING: "Processing",
  PACKED: "Packed",
  SHIPPED: "Shipped",
  DELIVERED: "Delivered",
  CANCELLED: "Cancelled",
  REFUNDED: "Refunded",
};

const ORDER_STATUS_TO_API: Record<UiOrderStatus, string> = {
  Pending: "PENDING",
  Confirmed: "CONFIRMED",
  Processing: "PROCESSING",
  Packed: "PACKED",
  Shipped: "SHIPPED",
  Delivered: "DELIVERED",
  Cancelled: "CANCELLED",
  Refunded: "REFUNDED",
};

export function orderStatusToUi(status: string): UiOrderStatus {
  return ORDER_STATUS_TO_UI[status] ?? "Pending";
}

export function orderStatusToApi(status: UiOrderStatus): string {
  return ORDER_STATUS_TO_API[status];
}

export function couponTypeToUi(type: string): "percentage" | "fixed" {
  return type === "PERCENTAGE" ? "percentage" : "fixed";
}

export function couponTypeToApi(type: "percentage" | "fixed"): string {
  return type === "percentage" ? "PERCENTAGE" : "FIXED";
}

export function customerStatusToUi(status: string): "active" | "inactive" {
  return status === "ACTIVE" ? "active" : "inactive";
}

export function customerStatusToApi(status: "active" | "inactive"): string {
  return status === "active" ? "ACTIVE" : "INACTIVE";
}

export function productStatusToUi(status: string): "published" | "draft" {
  return status === "DRAFT" ? "draft" : "published";
}

export function productStatusToApi(status: "published" | "draft"): string {
  return status === "draft" ? "DRAFT" : "PUBLISHED";
}

export function productVisibilityToUi(visibility: string): "visible" | "hidden" {
  return visibility === "HIDDEN" ? "hidden" : "visible";
}

export function productVisibilityToApi(visibility: "visible" | "hidden"): string {
  return visibility === "hidden" ? "HIDDEN" : "VISIBLE";
}

export function adminRoleToUi(role: string): AdminUser["role"] {
  if (role === "MANAGER") return "Manager";
  if (role === "STAFF") return "Staff";
  return "Owner";
}
