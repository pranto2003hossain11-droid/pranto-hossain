import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { Prisma } from "@prisma/client";

export function ok<T>(data: T, init?: number) {
  return NextResponse.json(data, { status: init ?? 200 });
}

export function created<T>(data: T) {
  return NextResponse.json(data, { status: 201 });
}

export function noContent() {
  return new NextResponse(null, { status: 204 });
}

export function badRequest(message: string, details?: unknown) {
  return NextResponse.json({ error: message, details }, { status: 400 });
}

export function unauthorized(message = "Unauthorized") {
  return NextResponse.json({ error: message }, { status: 401 });
}

export function notFound(message = "Not found") {
  return NextResponse.json({ error: message }, { status: 404 });
}

export function conflict(message: string) {
  return NextResponse.json({ error: message }, { status: 409 });
}

/**
 * Wraps a route handler body, translating known error types (Zod validation,
 * Prisma constraint violations, "not found") into consistent JSON responses
 * instead of leaking stack traces or generic 500s where a 4xx is correct.
 */
export async function handleApiError(error: unknown) {
  if (error instanceof ZodError) {
    return badRequest(
      "Validation failed",
      error.issues.map((issue) => ({
        path: issue.path.join("."),
        message: issue.message,
      }))
    );
  }

  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    if (error.code === "P2002") {
      const target = (error.meta?.target as string[] | undefined)?.join(", ");
      return conflict(
        target
          ? `A record with this ${target} already exists.`
          : "A record with these unique fields already exists."
      );
    }
    if (error.code === "P2025") {
      return notFound("Record not found.");
    }
    if (error.code === "P2003") {
      return badRequest(
        "This action references a record that doesn't exist (invalid foreign key)."
      );
    }
  }

  console.error("Unhandled API error:", error);
  return NextResponse.json(
    { error: "Something went wrong. Please try again." },
    { status: 500 }
  );
}
