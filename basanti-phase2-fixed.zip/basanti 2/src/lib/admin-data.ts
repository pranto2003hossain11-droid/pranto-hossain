import { products } from "./data";
import type {
  Category,
  Coupon,
  Customer,
  HeroSlide,
  HomepageSections,
  MediaItem,
  Order,
  StoreSettings,
} from "./admin-types";

export const seedCategories: Category[] = [
  {
    id: "cat-1",
    name: "Sarees",
    slug: "sarees",
    image: "https://images.unsplash.com/photo-1610189844058-91c6e2c92db4?w=600",
    parentId: null,
    sortOrder: 1,
    visible: true,
    createdAt: "2025-01-10T09:00:00.000Z",
  },
  {
    id: "cat-2",
    name: "Fusion Wear",
    slug: "fusion-wear",
    image: "https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=600",
    parentId: null,
    sortOrder: 2,
    visible: true,
    createdAt: "2025-01-10T09:00:00.000Z",
  },
  {
    id: "cat-3",
    name: "Accessories",
    slug: "accessories",
    image: "https://images.unsplash.com/photo-1591369822096-ffd140ec948f?w=600",
    parentId: null,
    sortOrder: 3,
    visible: true,
    createdAt: "2025-01-10T09:00:00.000Z",
  },
  {
    id: "cat-4",
    name: "Outerwear",
    slug: "outerwear",
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=600",
    parentId: null,
    sortOrder: 4,
    visible: true,
    createdAt: "2025-01-10T09:00:00.000Z",
  },
];

const customerNames = [
  { name: "Ayesha Rahman", email: "ayesha.rahman@example.com" },
  { name: "Farhan Kabir", email: "farhan.kabir@example.com" },
  { name: "Nusrat Jahan", email: "nusrat.jahan@example.com" },
  { name: "Tanvir Ahmed", email: "tanvir.ahmed@example.com" },
  { name: "Sadia Islam", email: "sadia.islam@example.com" },
  { name: "Rafiq Hasan", email: "rafiq.hasan@example.com" },
];

const orderCounts = [5, 3, 8, 1, 2, 4];
const spentAmounts = [42500, 18200, 61300, 8500, 12400, 27600];

export const seedCustomers: Customer[] = customerNames.map((c, i) => ({
  id: `cust-${i + 1}`,
  name: c.name,
  email: c.email,
  phone: `+8801${700000000 + i * 91827}`,
  address: "Dhaka, Bangladesh",
  ordersCount: orderCounts[i] ?? 1,
  totalSpent: spentAmounts[i] ?? 10000,
  status: i === 4 ? "inactive" : "active",
  joinedAt: new Date(2025, i, 12).toISOString(),
}));

const statuses: Order["status"][] = [
  "Pending",
  "Confirmed",
  "Processing",
  "Packed",
  "Shipped",
  "Delivered",
  "Cancelled",
];

export const seedOrders: Order[] = Array.from({ length: 10 }).map((_, i) => {
  const customer = seedCustomers[i % seedCustomers.length]!;
  const item1 = products[i % products.length]!;
  const item2 = products[(i + 3) % products.length]!;
  const items = [
    { productId: item1.id, name: item1.name, image: item1.image, size: item1.sizes?.[0], quantity: 1, price: item1.price },
    ...(i % 2 === 0
      ? [{ productId: item2.id, name: item2.name, image: item2.image, size: item2.sizes?.[0], quantity: 2, price: item2.price }]
      : []),
  ];
  const subtotal = items.reduce((s, it) => s + it.price * it.quantity, 0);
  const shipping = subtotal > 3000 ? 0 : 120;
  const discount = i % 4 === 0 ? Math.round(subtotal * 0.1) : 0;
  return {
    id: `order-${i + 1}`,
    orderNumber: `BB-${2026100 + i}`,
    customerId: customer.id,
    customerName: customer.name,
    customerEmail: customer.email,
    items,
    subtotal,
    shipping,
    discount,
    total: subtotal + shipping - discount,
    status: statuses[i % statuses.length]!,
    paymentMethod: i % 3 === 0 ? "Cash on Delivery" : i % 3 === 1 ? "bKash" : "Card",
    shippingAddress: "House 12, Road 5, Dhanmondi, Dhaka",
    phone: customer.phone ?? "+8801700000000",
    createdAt: new Date(2026, 5, 20 + i).toISOString(),
    updatedAt: new Date(2026, 5, 20 + i).toISOString(),
  };
});

export const seedCoupons: Coupon[] = [
  {
    id: "coup-1",
    code: "WELCOME10",
    type: "percentage",
    value: 10,
    minOrder: 2000,
    usageLimit: 500,
    usedCount: 128,
    expiryDate: "2026-12-31",
    enabled: true,
    createdAt: "2026-01-05T00:00:00.000Z",
  },
  {
    id: "coup-2",
    code: "FESTIVE500",
    type: "fixed",
    value: 500,
    minOrder: 5000,
    usageLimit: 200,
    usedCount: 54,
    expiryDate: "2026-09-30",
    enabled: true,
    createdAt: "2026-02-01T00:00:00.000Z",
  },
  {
    id: "coup-3",
    code: "FLASH20",
    type: "percentage",
    value: 20,
    minOrder: 3000,
    usageLimit: 100,
    usedCount: 100,
    expiryDate: "2026-05-01",
    enabled: false,
    createdAt: "2026-03-10T00:00:00.000Z",
  },
];

export const seedHeroSlides: HeroSlide[] = [
  {
    id: "slide-1",
    image: "/images/hero/hero-1.jpg",
    title: "Premium Two Piece Collection",
    subtitle: "Discover elegant handcrafted two-piece collections designed for modern women.",
    buttonText: "Shop Collection",
    buttonLink: "/shop",
    enabled: true,
    sortOrder: 1,
  },
  {
    id: "slide-2",
    image: "/images/hero/hero-2.jpg",
    title: "Timeless Sarees, Modern Elegance",
    subtitle: "Handwoven fabrics finished with fine zari and gold detailing.",
    buttonText: "Explore Sarees",
    buttonLink: "/category/sarees",
    enabled: true,
    sortOrder: 2,
  },
  {
    id: "slide-3",
    image: "/images/hero/hero-3.jpg",
    title: "New Season Arrivals",
    subtitle: "Fresh silhouettes crafted with premium fabrics and everyday comfort.",
    buttonText: "View New Arrivals",
    buttonLink: "/shop?filter=new",
    enabled: true,
    sortOrder: 3,
  },
];

export const defaultHomepageSections: HomepageSections = {
  featuredProducts: true,
  collections: true,
  offers: true,
  testimonials: true,
  instagram: true,
  newsletter: true,
};

export const seedMedia: MediaItem[] = products.slice(0, 8).map((p, i) => ({
  id: `media-${i + 1}`,
  url: p.image,
  name: `${p.slug}.jpg`,
  folder: "products",
  size: 240000 + i * 15000,
  type: "image/jpeg",
  uploadedAt: new Date(2026, 4, i + 1).toISOString(),
}));

export const defaultSettings: StoreSettings = {
  storeName: "Basanti Boutiques & House",
  phone: "+880 1700-000000",
  email: "hello@basantiboutiques.com",
  address: "Gulshan Avenue, Dhaka, Bangladesh",
  facebook: "https://facebook.com/basantiboutiques",
  instagram: "https://instagram.com/basantiboutiques",
  whatsapp: "+8801700000000",
  shippingCharge: 120,
  freeShippingThreshold: 3000,
  currency: "BDT",
  seoTitle: "Basanti Boutiques & House | Premium Fashion, Crafted in Bangladesh",
  seoDescription:
    "Discover Basanti Boutiques & House — premium fashion for the modern Bangladeshi wardrobe.",
};
