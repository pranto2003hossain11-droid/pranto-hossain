import type { Product, Review } from "./types";

export const products: Product[] = [
  {
    id: "1",
    slug: "maroon-zari-jamdani-saree",
    name: "Maroon Zari Jamdani Saree",
    price: 8500,
    compareAtPrice: 11000,
    image: "https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg",
    images: [
      "https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg",
      "https://images.pexels.com/photos/994523/pexels-photo-994523.jpeg",
      "https://images.pexels.com/photos/1462637/pexels-photo-1462637.jpeg",
    ],
    category: "Sarees",
    rating: 4.8,
    reviewCount: 124,
    isBestSeller: true,
    stock: 6,
    description:
      "A handwoven jamdani saree in deep maroon, finished with fine zari work along the border and pallu. Lightweight cotton-silk blend, ideal for festive occasions.",
    sizes: ["Free Size"],
  },
  {
    id: "2",
    slug: "ivory-silk-fusion-kurti",
    name: "Ivory Silk Fusion Kurti",
    price: 3200,
    image: "https://images.pexels.com/photos/985635/pexels-photo-985635.jpeg",
    images: [
      "https://images.pexels.com/photos/985635/pexels-photo-985635.jpeg",
      "https://images.pexels.com/photos/1536619/pexels-photo-1536619.jpeg",
    ],
    category: "Fusion Wear",
    rating: 4.6,
    reviewCount: 58,
    isNew: true,
    stock: 14,
    description:
      "A modern silhouette in raw silk with hand-finished seams. Pairs easily with palazzos or tailored trousers for a contemporary look.",
    sizes: ["S", "M", "L", "XL"],
  },
  {
    id: "3",
    slug: "gold-embroidered-shawl",
    name: "Gold Embroidered Shawl",
    price: 4500,
    compareAtPrice: 5400,
    image: "https://images.pexels.com/photos/934070/pexels-photo-934070.jpeg",
    images: ["https://images.pexels.com/photos/934070/pexels-photo-934070.jpeg"],
    category: "Accessories",
    rating: 4.9,
    reviewCount: 32,
    stock: 3,
    description:
      "Hand-embroidered shawl with gold thread detailing along the edges. A versatile layering piece for cooler evenings.",
    sizes: ["Free Size"],
  },
  {
    id: "4",
    slug: "charcoal-tailored-blazer",
    name: "Charcoal Tailored Blazer",
    price: 6200,
    image: "https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg",
    images: ["https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg"],
    category: "Outerwear",
    rating: 4.7,
    reviewCount: 41,
    isNew: true,
    stock: 9,
    description:
      "A structured blazer in charcoal wool-blend, tailored for a sharp silhouette. Fully lined with horn-style buttons.",
    sizes: ["S", "M", "L", "XL"],
  },
  {
    id: "5",
    slug: "rose-banarasi-saree",
    name: "Rose Banarasi Saree",
    price: 9800,
    image: "https://picsum.photos/id/1042/800/1000",
    images: ["https://picsum.photos/id/1042/1200/1500"],
    category: "Sarees",
    rating: 4.9,
    reviewCount: 76,
    isBestSeller: true,
    stock: 5,
    description: "Classic Banarasi weave in dusty rose with intricate motifs throughout the body.",
    sizes: ["Free Size"],
  },
  {
    id: "6",
    slug: "beige-linen-tunic",
    name: "Beige Linen Tunic",
    price: 2800,
    image: "https://picsum.photos/id/1043/800/1000",
    images: ["https://picsum.photos/id/1043/1200/1500"],
    category: "Fusion Wear",
    rating: 4.4,
    reviewCount: 22,
    isNew: true,
    stock: 18,
    description: "Breathable pure linen tunic with relaxed fit, perfect for everyday wear.",
    sizes: ["S", "M", "L"],
  },
  {
    id: "7",
    slug: "maroon-leather-clutch",
    name: "Maroon Leather Clutch",
    price: 2100,
    image: "https://picsum.photos/id/1044/800/1000",
    images: ["https://picsum.photos/id/1044/1200/1500"],
    category: "Accessories",
    rating: 4.5,
    reviewCount: 19,
    stock: 11,
    description: "Genuine leather clutch with gold-tone hardware and detachable chain strap.",
    sizes: ["One Size"],
  },
  {
    id: "8",
    slug: "ivory-cape-jacket",
    name: "Ivory Cape Jacket",
    price: 5400,
    compareAtPrice: 6800,
    image: "https://picsum.photos/id/1045/800/1000",
    images: ["https://picsum.photos/id/1045/1200/1500"],
    category: "Outerwear",
    rating: 4.6,
    reviewCount: 27,
    stock: 7,
    description: "A flowing cape-style jacket in ivory twill, designed to layer over fitted silhouettes.",
    sizes: ["S/M", "L/XL"],
  },
];

export const reviews: Review[] = [
  {
    id: "r1",
    productId: "1",
    author: "Nusrat J.",
    rating: 5,
    date: "2026-05-12",
    text: "Stunning fabric and the zari work is even better in person. Delivery was fast.",
    verified: true,
  },
  {
    id: "r2",
    productId: "1",
    author: "Farhana A.",
    rating: 4,
    date: "2026-04-28",
    text: "Beautiful saree, slightly heavier than expected but great quality.",
    verified: true,
  },
];

export function getProductBySlug(slug: string) {
  return products.find((p) => p.slug === slug);
}

export function getReviewsForProduct(productId: string) {
  return reviews.filter((r) => r.productId === productId);
}

export function getRelatedProducts(product: Product, limit = 4) {
  return products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, limit);
}
