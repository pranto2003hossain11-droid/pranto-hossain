/**
 * Domain types for the Admin Panel.
 *
 * These are intentionally framework-agnostic and database-ready: every
 * interface here mirrors the shape a real backend/ORM record would have
 * (string ids, ISO date strings, no client-only fields) so that swapping the
 * Zustand-backed stores in `src/store/admin` for real API calls later on is a
 * matter of changing the store implementation, not the UI.
 */

export interface Category {
  id: string;
  name: string;
  slug: string;
  image?: string;
  parentId?: string | null;
  sortOrder: number;
  visible: boolean;
  productCount?: number;
  createdAt: string;
}

export type OrderStatus =
  | "Pending"
  | "Confirmed"
  | "Processing"
  | "Packed"
  | "Shipped"
  | "Delivered"
  | "Cancelled"
  | "Refunded";

export interface OrderItem {
  productId: string;
  name: string;
  image: string;
  size?: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  items: OrderItem[];
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  status: OrderStatus;
  paymentMethod: string;
  shippingAddress: string;
  phone: string;
  couponCode?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  address?: string;
  ordersCount: number;
  totalSpent: number;
  status: "active" | "inactive";
  joinedAt: string;
}

export interface Coupon {
  id: string;
  code: string;
  type: "percentage" | "fixed";
  value: number;
  minOrder?: number;
  usageLimit?: number;
  usedCount: number;
  expiryDate?: string;
  enabled: boolean;
  createdAt: string;
}

export interface HeroSlide {
  id: string;
  image: string;
  title: string;
  subtitle?: string;
  buttonText?: string;
  buttonLink?: string;
  enabled: boolean;
  sortOrder: number;
}

export interface HomepageSections {
  featuredProducts: boolean;
  collections: boolean;
  offers: boolean;
  testimonials: boolean;
  instagram: boolean;
  newsletter: boolean;
}

export interface MediaItem {
  id: string;
  url: string;
  name: string;
  folder: string;
  size: number;
  type: string;
  uploadedAt: string;
}

export interface StoreSettings {
  storeName: string;
  logo?: string;
  favicon?: string;
  phone: string;
  email: string;
  address: string;
  facebook?: string;
  instagram?: string;
  whatsapp?: string;
  shippingCharge: number;
  freeShippingThreshold: number;
  currency: string;
  seoTitle: string;
  seoDescription: string;
  analyticsId?: string;
}

export interface AdminUser {
  name: string;
  email: string;
  role: "Owner" | "Manager" | "Staff";
  avatar?: string;
}
