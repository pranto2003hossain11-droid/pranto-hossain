import { z } from "zod";

export const specificationSchema = z.object({
  label: z.string().min(1),
  value: z.string().min(1),
});

export const productCreateSchema = z.object({
  slug: z
    .string()
    .min(1)
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Slug must be lowercase, alphanumeric, and hyphen-separated"),
  name: z.string().min(1),
  description: z.string().optional().nullable(),
  price: z.number().nonnegative(),
  compareAtPrice: z.number().nonnegative().optional().nullable(),
  sku: z.string().optional().nullable(),
  brand: z.string().optional().nullable(),
  stock: z.number().int().nonnegative().default(0),
  isNew: z.boolean().default(false),
  isBestSeller: z.boolean().default(false),
  status: z.enum(["PUBLISHED", "DRAFT"]).default("PUBLISHED"),
  visibility: z.enum(["VISIBLE", "HIDDEN"]).default("VISIBLE"),
  image: z.string().min(1),
  images: z.array(z.string()).default([]),
  sizes: z.array(z.string()).default([]),
  colors: z.array(z.string()).default([]),
  specifications: z.array(specificationSchema).default([]),
  seoTitle: z.string().optional().nullable(),
  seoDescription: z.string().optional().nullable(),
  categoryId: z.string().optional().nullable(),
  collectionIds: z.array(z.string()).optional().default([]),
});

export const productUpdateSchema = productCreateSchema.partial();

export const categoryCreateSchema = z.object({
  name: z.string().min(1),
  slug: z
    .string()
    .min(1)
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  image: z.string().optional().nullable(),
  parentId: z.string().optional().nullable(),
  sortOrder: z.number().int().default(0),
  visible: z.boolean().default(true),
});
export const categoryUpdateSchema = categoryCreateSchema.partial();

export const collectionCreateSchema = z.object({
  name: z.string().min(1),
  slug: z
    .string()
    .min(1)
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  description: z.string().optional().nullable(),
  image: z.string().optional().nullable(),
  sortOrder: z.number().int().default(0),
  visible: z.boolean().default(true),
  productIds: z.array(z.string()).optional().default([]),
});
export const collectionUpdateSchema = collectionCreateSchema.partial();

export const bannerCreateSchema = z.object({
  image: z.string().min(1),
  title: z.string().min(1),
  subtitle: z.string().optional().nullable(),
  buttonText: z.string().optional().nullable(),
  buttonLink: z.string().optional().nullable(),
  enabled: z.boolean().default(true),
  sortOrder: z.number().int().default(0),
});
export const bannerUpdateSchema = bannerCreateSchema.partial();

export const homepageSectionUpdateSchema = z.object({
  sections: z.array(
    z.object({
      key: z.string().min(1),
      enabled: z.boolean(),
      sortOrder: z.number().int(),
    })
  ),
});

export const customerCreateSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  password: z.string().min(6).optional(),
  phone: z.string().optional().nullable(),
  address: z.string().optional().nullable(),
  status: z.enum(["ACTIVE", "INACTIVE"]).default("ACTIVE"),
});
export const customerUpdateSchema = customerCreateSchema.partial().omit({ password: true });

export const customerRegisterSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  password: z.string().min(6),
  phone: z.string().optional(),
});

export const customerLoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export const orderItemInputSchema = z.object({
  productId: z.string().min(1),
  name: z.string().min(1),
  image: z.string().min(1),
  size: z.string().optional().nullable(),
  quantity: z.number().int().positive(),
  price: z.number().nonnegative(),
});

export const orderCreateSchema = z.object({
  customerId: z.string().optional().nullable(),
  customerName: z.string().min(1),
  customerEmail: z.string().email(),
  phone: z.string().min(1),
  shippingAddress: z.string().min(1),
  paymentMethod: z.string().min(1),
  couponCode: z.string().optional().nullable(),
  items: z.array(orderItemInputSchema).min(1),
});

export const orderStatusUpdateSchema = z.object({
  status: z.enum([
    "PENDING",
    "CONFIRMED",
    "PROCESSING",
    "PACKED",
    "SHIPPED",
    "DELIVERED",
    "CANCELLED",
    "REFUNDED",
  ]),
});

export const couponCreateSchema = z.object({
  code: z
    .string()
    .min(1)
    .transform((v) => v.toUpperCase().trim()),
  type: z.enum(["PERCENTAGE", "FIXED"]),
  value: z.number().positive(),
  minOrder: z.number().nonnegative().optional().nullable(),
  usageLimit: z.number().int().positive().optional().nullable(),
  expiryDate: z.string().datetime().optional().nullable(),
  enabled: z.boolean().default(true),
});
export const couponUpdateSchema = couponCreateSchema.partial();

export const couponValidateSchema = z.object({
  code: z.string().min(1),
  subtotal: z.number().nonnegative(),
});

export const reviewCreateSchema = z.object({
  productId: z.string().min(1),
  customerId: z.string().optional().nullable(),
  author: z.string().min(1),
  rating: z.number().int().min(1).max(5),
  text: z.string().min(1),
});

export const reviewUpdateSchema = z.object({
  approved: z.boolean().optional(),
  verified: z.boolean().optional(),
  rating: z.number().int().min(1).max(5).optional(),
  text: z.string().min(1).optional(),
});

export const mediaCreateSchema = z.object({
  url: z.string().min(1),
  name: z.string().min(1),
  folder: z.string().default("general"),
  size: z.number().int().nonnegative(),
  type: z.string().min(1),
});

export const settingUpdateSchema = z.object({
  storeName: z.string().min(1).optional(),
  logo: z.string().optional().nullable(),
  favicon: z.string().optional().nullable(),
  phone: z.string().min(1).optional(),
  email: z.string().email().optional(),
  address: z.string().min(1).optional(),
  facebook: z.string().optional().nullable(),
  instagram: z.string().optional().nullable(),
  whatsapp: z.string().optional().nullable(),
  shippingCharge: z.number().nonnegative().optional(),
  freeShippingThreshold: z.number().nonnegative().optional(),
  currency: z.string().optional(),
  seoTitle: z.string().min(1).optional(),
  seoDescription: z.string().min(1).optional(),
  analyticsId: z.string().optional().nullable(),
});

export const adminLoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});
