/**
 * SQLite has no native array/JSON column type usable directly with strong
 * typing in Prisma, so a few Product fields (images, sizes, colors,
 * specifications) are stored as JSON-encoded strings. These helpers are the
 * ONLY place that should read or write those columns — every API route and
 * server component should go through them rather than JSON.parse/stringify
 * inline, so the encoding stays consistent everywhere.
 */

import type { Product as PrismaProduct, Customer as PrismaCustomer } from "@prisma/client";
import type { Product } from "@/lib/types";

export interface ProductSpecification {
  label: string;
  value: string;
}

function safeParseArray<T>(value: string | null | undefined, fallback: T[] = []): T[] {
  if (!value) return fallback;
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

export function toJsonString(value: unknown): string {
  return JSON.stringify(value ?? []);
}

/** Convert a raw Prisma Product row (with optional relations already resolved) into the
 * storefront/admin-facing `Product` shape used throughout the existing UI. */
export function serializeProduct(
  product: PrismaProduct & { category?: { name: string } | null }
): Product {
  return {
    id: product.id,
    slug: product.slug,
    name: product.name,
    price: product.price,
    compareAtPrice: product.compareAtPrice ?? undefined,
    image: product.image,
    images: safeParseArray<string>(product.images),
    category: product.category?.name ?? "",
    rating: product.rating,
    reviewCount: product.reviewCount,
    isNew: product.isNew,
    isBestSeller: product.isBestSeller,
    stock: product.stock,
    description: product.description ?? undefined,
    sizes: safeParseArray<string>(product.sizes),
    sku: product.sku ?? undefined,
    brand: product.brand ?? undefined,
    colors: safeParseArray<string>(product.colors),
    specifications: safeParseArray<ProductSpecification>(product.specifications),
    seoTitle: product.seoTitle ?? undefined,
    seoDescription: product.seoDescription ?? undefined,
    status: product.status === "DRAFT" ? "draft" : "published",
    visibility: product.visibility === "HIDDEN" ? "hidden" : "visible",
    createdAt: product.createdAt.toISOString(),
    updatedAt: product.updatedAt.toISOString(),
  };
}

/** Strips `passwordHash` (and any other future sensitive fields) from a Customer
 * row before it's ever sent to a client. Always go through this rather than
 * spreading a raw Prisma Customer into a response. */
export function serializePublicCustomer(
  customer: PrismaCustomer & { _count?: { orders: number } }
) {
  return {
    id: customer.id,
    name: customer.name,
    email: customer.email,
    phone: customer.phone,
    avatar: customer.avatar,
    address: customer.address,
    status: customer.status,
    orderCount: customer._count?.orders ?? undefined,
    createdAt: customer.createdAt.toISOString(),
    updatedAt: customer.updatedAt.toISOString(),
  };
}
