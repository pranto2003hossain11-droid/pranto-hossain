export interface Product {
  id: string;
  slug: string;
  name: string;
  price: number;
  compareAtPrice?: number;
  image: string;
  images?: string[];
  hoverImage?: string;
  category: string;
  categoryId?: string;
  rating: number;
  reviewCount: number;
  isNew?: boolean;
  isBestSeller?: boolean;
  stock: number;
  description?: string;
  sizes?: string[];
  /** Admin-managed fields (optional so existing storefront data stays valid). */
  sku?: string;
  brand?: string;
  colors?: string[];
  specifications?: { label: string; value: string }[];
  seoTitle?: string;
  seoDescription?: string;
  status?: "published" | "draft";
  visibility?: "visible" | "hidden";
  createdAt?: string;
  updatedAt?: string;
}

export interface Review {
  id: string;
  productId: string;
  author: string;
  rating: number;
  date: string;
  text: string;
  verified: boolean;
}
