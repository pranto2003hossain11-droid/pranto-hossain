export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  image: string;
  date: string;
  author: string;
  content: string[];
}

export const blogPosts: BlogPost[] = [
  {
    slug: "art-of-jamdani-weaving",
    title: "The Art of Jamdani Weaving",
    excerpt: "An inside look at the centuries-old technique behind our signature sarees.",
    image: "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=1000",
    date: "2026-05-20",
    author: "Basanti Editorial",
    content: [
      "Jamdani weaving is one of the finest traditions of muslin weaving, originating in the Narayanganj region of Bangladesh.",
      "Each saree can take weeks to complete, with intricate motifs woven directly into the fabric rather than printed or embroidered afterward.",
      "At Basanti, we work directly with jamdani weaving families to ensure fair wages and preserve this craft for future generations.",
    ],
  },
  {
    slug: "styling-fusion-wear-for-work",
    title: "Styling Fusion Wear for the Office",
    excerpt: "Five ways to wear our fusion pieces for a polished, modern workday look.",
    image: "https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=1000",
    date: "2026-06-02",
    author: "Basanti Editorial",
    content: [
      "Fusion wear bridges the gap between traditional silhouettes and contemporary tailoring — perfect for a modern workday.",
      "Pair a structured kurti with tailored trousers and minimal jewelry for an effortless, professional look.",
      "Layer with our cape jackets for cooler office environments without sacrificing style.",
    ],
  },
  {
    slug: "caring-for-silk-garments",
    title: "Caring for Your Silk Garments",
    excerpt: "Simple steps to keep your silk pieces looking their best for years.",
    image: "https://images.unsplash.com/photo-1591369822096-ffd140ec948f?w=1000",
    date: "2026-06-15",
    author: "Basanti Editorial",
    content: [
      "Silk is a delicate fiber that rewards gentle care. Always dry clean or hand wash in cold water with a mild detergent.",
      "Store silk garments folded in breathable fabric bags, away from direct sunlight, to prevent fading and fiber damage.",
      "Iron on a low setting with a protective cloth between the iron and fabric.",
    ],
  },
];

export function getPostBySlug(slug: string) {
  return blogPosts.find((p) => p.slug === slug);
}
