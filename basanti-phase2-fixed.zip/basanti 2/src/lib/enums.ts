/**
 * SQLite's Prisma connector doesn't support native `enum` types, so every
 * field that would otherwise be a Prisma enum is a plain String column
 * (see prisma/schema.prisma). These are the canonical allowed values for
 * each of those columns — the single source of truth used by:
 *   - src/lib/validators.ts (Zod schemas, enforced on every write)
 *   - any route/store that needs to reference a valid value by name
 *
 * If this project later moves to Postgres/MySQL, these can become real
 * Prisma `enum` blocks with zero application code changes (the string
 * values are identical).
 */

export const ADMIN_ROLES = ["OWNER", "MANAGER", "STAFF"] as const;
export type AdminRole = (typeof ADMIN_ROLES)[number];

export const PRODUCT_STATUSES = ["PUBLISHED", "DRAFT"] as const;
export type ProductStatus = (typeof PRODUCT_STATUSES)[number];

export const PRODUCT_VISIBILITIES = ["VISIBLE", "HIDDEN"] as const;
export type ProductVisibility = (typeof PRODUCT_VISIBILITIES)[number];

export const ORDER_STATUSES = [
  "PENDING",
  "CONFIRMED",
  "PROCESSING",
  "PACKED",
  "SHIPPED",
  "DELIVERED",
  "CANCELLED",
  "REFUNDED",
] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const COUPON_TYPES = ["PERCENTAGE", "FIXED"] as const;
export type CouponType = (typeof COUPON_TYPES)[number];

export const CUSTOMER_STATUSES = ["ACTIVE", "INACTIVE"] as const;
export type CustomerStatus = (typeof CUSTOMER_STATUSES)[number];
