import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    container: {
      center: true,
      padding: {
        DEFAULT: "1.25rem",
        sm: "1.5rem",
        lg: "2rem",
        xl: "2.5rem",
      },
      screens: {
        sm: "640px",
        md: "768px",
        lg: "1024px",
        xl: "1280px",
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        maroon: {
          DEFAULT: "#6B1424",
          50: "#FBEEF0",
          100: "#F2D2D7",
          200: "#E2A4AC",
          300: "#CE7682",
          400: "#A8475A",
          500: "#6B1424",
          600: "#5A101E",
          700: "#480D18",
          800: "#360912",
          900: "#24060C",
        },
        gold: {
          DEFAULT: "#B4863C",
          50: "#FAF5EA",
          100: "#F2E4C5",
          200: "#E5C98B",
          300: "#D7AE57",
          400: "#B4863C",
          500: "#92692C",
          600: "#735121",
          700: "#543A17",
          800: "#36240E",
          900: "#1C1206",
        },
        ivory: {
          DEFAULT: "#FBF6EE",
          dark: "#F3EAD9",
        },
        beige: {
          DEFAULT: "#EFE2C9",
          dark: "#E2CFA6",
        },
        charcoal: {
          DEFAULT: "#262220",
          light: "#4A4340",
          muted: "#7A716B",
        },
      },
      fontFamily: {
        display: ["var(--font-playfair)", "serif"],
        body: ["var(--font-poppins)", "sans-serif"],
      },
      fontSize: {
        "display-xl": ["4.5rem", { lineHeight: "1.05", letterSpacing: "-0.02em" }],
        "display-lg": ["3.5rem", { lineHeight: "1.08", letterSpacing: "-0.02em" }],
        "display-md": ["2.5rem", { lineHeight: "1.12", letterSpacing: "-0.01em" }],
        "display-sm": ["1.875rem", { lineHeight: "1.2" }],
      },
      borderRadius: {
        sm: "0.25rem",
        DEFAULT: "0.5rem",
        md: "0.75rem",
        lg: "1rem",
        xl: "1.5rem",
        pill: "999px",
      },
      boxShadow: {
        soft: "0 2px 12px rgba(38, 34, 32, 0.06)",
        card: "0 4px 24px rgba(38, 34, 32, 0.08)",
        elevated: "0 12px 40px rgba(38, 34, 32, 0.14)",
        gold: "0 4px 20px rgba(180, 134, 60, 0.25)",
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-468px 0" },
          "100%": { backgroundPosition: "468px 0" },
        },
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
      },
      animation: {
        fadeIn: "fadeIn 0.6s ease-out forwards",
        shimmer: "shimmer 1.6s linear infinite",
        marquee: "marquee 28s linear infinite",
      },
      maxWidth: {
        "8xl": "90rem",
      },
    },
  },
  plugins: [],
};

export default config;
