# Basanti Boutiques & House

Premium fashion eCommerce site built with Next.js 14 (App Router), TypeScript, Tailwind CSS, and Framer Motion.

## Getting started locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## What's built so far

- **Project setup**: Next.js + TypeScript + Tailwind + ESLint + Prettier, font loading (Playfair Display + Poppins), SEO metadata defaults, image optimization config.
- **Design system**: color tokens (maroon / gold / ivory / beige / charcoal), type scale, spacing, radii, shadows, skeleton/shimmer states — all in `tailwind.config.ts` and `globals.css`.
- **Core components**: Button, Badge, Card, Skeleton, ProductCard (+ skeleton), Navbar (with sticky behavior + mobile drawer), Sticky Mobile Bottom Nav, Footer, Floating WhatsApp.
- **Homepage**: Hero, Shop by Category, New Arrivals, Flash Sale (live countdown), Best Sellers, Brand Story / Why Choose Us, Testimonials, Instagram Gallery, Newsletter.

## Still to build (in progress, continuing in this conversation)

- Shop / Category / Collection listing pages with filters & sorting
- Product Details page (gallery, variants, reviews, related products)
- Cart drawer + Cart page
- Checkout flow
- Wishlist page
- Auth (login/register) + Customer Dashboard
- About, Contact, FAQ, Policies, Blog, Article, Order Tracking, Search, 404
- Cart/wishlist global state (Zustand store)
- Structured data (Product, Breadcrumb schema), sitemap.xml, robots.txt

## Notes

- Product data in `src/lib/data.ts` is mock data — swap in a real backend/CMS later.
- Images currently point to Unsplash placeholders — replace with your own product photography before launch.
- This was generated in a sandboxed environment without network access, so dependencies haven't been installed or build-tested here. Run `npm install && npm run build` locally to verify before deploying.
