# Phase 2 — Authentication + Full API Layer

Builds directly on Phase 1 (nothing from Phase 1 was removed or redone).

## What was added

**Auth**
- `src/lib/auth.ts` — admin password hashing (bcryptjs) + signed JWT sessions (jose), httpOnly cookie.
- `src/lib/customer-auth.ts` — same pattern for storefront customer sessions (separate cookie/namespace).
- `src/middleware.ts` — protects every `/admin/*` page and every `/api/admin/*` route at the edge. Unauthenticated → redirected to `/admin/login` (pages) or `401 JSON` (API). `/admin/login` and `/api/admin/auth/*` stay reachable while logged out.

**Shared infrastructure**
- `src/lib/api-response.ts` — consistent response helpers + one error handler that turns Zod validation errors and Prisma constraint errors (unique conflicts, not-found, bad foreign keys) into proper 4xx responses instead of generic 500s.
- `src/lib/validators.ts` — one Zod schema per entity, reused by both admin and public routes.
- `src/lib/reviews.ts` — recomputes a product's `rating`/`reviewCount` from its approved reviews (called on review approve/edit/delete).

**39 API routes**, all reading/writing the real database — no fake data anywhere:

| Area | Admin routes (`/api/admin/...`, session-protected) | Public routes |
|---|---|---|
| Auth | `auth/login`, `auth/logout`, `auth/me` (+profile PATCH) | `customers/register`, `customers/login`, `customers/logout`, `customers/me` |
| Products | `products` (list/create), `products/[id]` (get/update/delete) | `products` (published+visible only, filterable/sortable), `products/[slug]` (+related products +approved reviews) |
| Categories | `categories`, `categories/[id]` | `categories` (visible only, with sub-categories) |
| Collections | `collections`, `collections/[id]` | `collections`, `collections/[slug]` |
| Homepage | `banners`, `banners/[id]`, `homepage-sections` (bulk toggle/order) | `banners` (enabled only), `homepage-sections` (enabled only) |
| Customers | `customers`, `customers/[id]` | — |
| Orders | `orders` (list/filter), `orders/[id]` (status update → auto-restocks on cancel/refund) | `orders` (checkout: re-verifies price/stock server-side, applies coupon, computes shipping), `orders/[orderNumber]` (tracking, requires email or phone match) |
| Coupons | `coupons`, `coupons/[id]` | `coupons/validate` |
| Reviews | `reviews` (moderation queue), `reviews/[id]` (approve/edit/delete) | `reviews` (GET approved by product, POST new review → held for moderation) |
| Media | `media` (real file upload to `/public/uploads`, DB-tracked), `media/[id]` (delete — blocks if the image is still referenced by a product/category/banner/etc. unless `?force=true`) | — |
| Settings | `settings` (get/update) | `settings` (safe public subset) |
| Analytics | `analytics` (revenue, orders, low stock, top products, 30-day trend) | — |
| Search | — | `search` (queries the database directly, no local filtering) |

## Verification performed (see below for the network caveat)

I still cannot run `npm install`/`prisma generate` myself (confirmed again — same `403 host_not_allowed` from the registry). What I *did* do, for real, not just assert:

1. Borrowed a compatible `next`/`typescript`/`eslint` toolchain from your other uploaded project.
2. Wrote a temporary, verification-only type stub for `@prisma/client`/`bcryptjs`/`jose` so I could isolate "errors caused by the package not being installed yet" from "errors caused by my code." This is the important part: every error the stub-free run produced was individually confirmed to be exactly that cascade, and I still went back and added explicit type annotations everywhere so the code is fully self-typed and doesn't lean on inference alone.
3. Ran the real TypeScript compiler and real ESLint against the entire `src` tree.
4. **Result: 0 TypeScript errors, 0 ESLint errors, 0 ESLint warnings.**
5. Deleted the borrowed `node_modules` and every temp file afterward — none of it is in this zip.

## What you need to run (same as Phase 1, nothing new)

```bash
npm install
npx prisma migrate dev --name init
npm run db:seed
npm run dev
```

Then sanity-check a couple of routes:
```bash
curl http://localhost:3000/api/categories
curl http://localhost:3000/api/products
curl -X POST http://localhost:3000/api/admin/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@basantiboutiques.com","password":"basanti@admin"}'
```

## What's NOT done yet (Phase 3+)

- The admin panel UI still reads/writes its local Zustand stores (`products-store.ts`, `orders-store.ts`, etc.) — none of the 20+ admin pages call these new APIs yet.
- The customer website still reads `src/lib/data.ts` static arrays.
- The `ImageDropzone` component still converts files to base64 data URLs instead of calling `/api/admin/media`.
- Login page still uses the demo Zustand check instead of `/api/admin/auth/login`.

Phase 3 is wiring the admin panel (every page above) to these APIs. Phase 4 is wiring the customer website. Nothing in Phase 3/4 requires changing this API layer — it was designed against the existing `types.ts`/`admin-types.ts` shapes specifically so the UI components won't need reshaping.
