<?php
session_start(['cookie_httponly' => true, 'cookie_samesite' => 'Lax']);
$cfg = __DIR__ . '/config.php';
$file = __DIR__ . '/data.json';
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
if (empty($_SESSION['t'])) $_SESSION['t'] = bin2hex(random_bytes(16));
$hash = is_file($cfg) ? include $cfg : null;
$post = $_SERVER['REQUEST_METHOD'] === 'POST';
$msg = '';
if ($post && !hash_equals($_SESSION['t'], $_POST['t'] ?? '')) { http_response_code(400); exit('Bad request'); }
if (isset($_GET['out'])) { session_destroy(); header('Location: admin.php'); exit; }

if (!$hash && $post && isset($_POST['newpass'])) {
  if (strlen($_POST['newpass']) >= 8) {
    file_put_contents($cfg, '<?php return ' . var_export(password_hash($_POST['newpass'], PASSWORD_DEFAULT), true) . ';');
    header('Location: admin.php'); exit;
  }
  $msg = 'Password must be at least 8 characters.';
}
if ($hash && $post && isset($_POST['pass'])) {
  if (password_verify($_POST['pass'], $hash)) {
    session_regenerate_id(true);
    $_SESSION['ok'] = 1;
    $_SESSION['t'] = bin2hex(random_bytes(16));
    header('Location: admin.php'); exit;
  }
  sleep(1);
  $msg = 'Wrong password.';
}
$in = !empty($_SESSION['ok']);
if ($in && $post && isset($_POST['up'])) { header('Content-Type: application/json'); exit(json_encode(do_up())); }
function img($v) { return preg_match('~^uploads/[a-f0-9]{16}\.(jpg|png|webp)$~', (string)$v) ? $v : ''; }
function do_up() {
  @ini_set('memory_limit', '256M');
  $f = $_FILES['f'] ?? null;
  if (!$f || $f['error'] !== UPLOAD_ERR_OK) return ['ok' => 0, 'err' => 'Upload failed (the file may be too large for the server).'];
  if ($f['size'] > 12 * 1024 * 1024) return ['ok' => 0, 'err' => 'Max 12 MB per photo.'];
  $i = @getimagesize($f['tmp_name']);
  if (!$i || !in_array($i[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) return ['ok' => 0, 'err' => 'Please use a JPG, PNG or WebP photo.'];
  $dir = __DIR__ . '/uploads';
  if (!is_dir($dir)) {
    mkdir($dir, 0755);
    file_put_contents($dir . '/.htaccess', "<FilesMatch \"\\.(php|phtml|php[0-9]|phar)\$\">\n  Require all denied\n</FilesMatch>\n");
  }
  $name = bin2hex(random_bytes(8));
  $ext = $i[2] === IMAGETYPE_PNG ? 'png' : ($i[2] === IMAGETYPE_WEBP ? 'webp' : 'jpg');
  $src = false;
  if (function_exists('imagecreatefromjpeg')) {
    if ($i[2] === IMAGETYPE_JPEG) $src = @imagecreatefromjpeg($f['tmp_name']);
    elseif ($i[2] === IMAGETYPE_PNG) $src = @imagecreatefrompng($f['tmp_name']);
    elseif (function_exists('imagecreatefromwebp')) $src = @imagecreatefromwebp($f['tmp_name']);
  }
  if ($src) {
    if ($i[2] === IMAGETYPE_JPEG && function_exists('exif_read_data')) {
      $e = @exif_read_data($f['tmp_name']);
      $ang = [3 => 180, 6 => -90, 8 => 90][$e['Orientation'] ?? 1] ?? 0;
      if ($ang) { $r = imagerotate($src, $ang, 0); if ($r) $src = $r; }
    }
    $w = imagesx($src); $h = imagesy($src); $m = 1800;
    if (max($w, $h) > $m) { $s = $m / max($w, $h); $n = imagescale($src, (int)round($w * $s), (int)round($h * $s)); if ($n) $src = $n; }
    $bg = imagecreatetruecolor(imagesx($src), imagesy($src));
    imagefill($bg, 0, 0, imagecolorallocate($bg, 8, 6, 6));
    imagecopy($bg, $src, 0, 0, 0, 0, imagesx($src), imagesy($src));
    $path = "uploads/$name.jpg";
    if (!imagejpeg($bg, __DIR__ . '/' . $path, 84)) return ['ok' => 0, 'err' => 'Could not save the photo.'];
  } else {
    $path = "uploads/$name.$ext";
    if (!move_uploaded_file($f['tmp_name'], __DIR__ . '/' . $path)) return ['ok' => 0, 'err' => 'Could not save the photo.'];
  }
  return ['ok' => 1, 'path' => $path];
}

function rows($a, $keys) {
  $o = [];
  foreach (array_slice(is_array($a) ? $a : [], 0, 60) as $r) {
    if (!is_array($r)) continue;
    $x = [];
    foreach ($keys as $k) $x[$k] = mb_substr(trim(strip_tags((string)($r[$k] ?? ''))), 0, 300);
    if (implode('', $x) !== '') $o[] = $x;
  }
  return $o;
}
function url($v) { return preg_match('~^https?://~i', $v) ? $v : ''; }

if ($in && $post && isset($_POST['json'])) {
  $d = json_decode($_POST['json'], true);
  if (is_array($d)) {
    $out = [
      'videos'  => rows($d['videos'] ?? [], ['title', 'tag', 'url']),
      'awards'  => rows($d['awards'] ?? [], ['rank', 'event', 'note']),
      'tour'    => rows($d['tour'] ?? [], ['when', 'what', 'where', 'status']),
      'members' => rows($d['members'] ?? [], ['name', 'role', 'link', 'photo']),
      'gallery' => rows($d['gallery'] ?? [], ['src', 'alt']),
    ];
    foreach ($out['videos'] as &$v) $v['url'] = url($v['url']);
    foreach ($out['members'] as &$m) { $m['link'] = url($m['link']); $m['photo'] = img($m['photo']); }
    foreach ($out['tour'] as &$t) if (!in_array($t['status'], ['upcoming', 'past'], true)) $t['status'] = 'past';
    unset($v, $m, $t);
    foreach ($out['gallery'] as &$g) $g['src'] = img($g['src']);
    unset($g);
    $out['gallery'] = array_values(array_filter($out['gallery'], function ($g) { return $g['src'] !== ''; }));
    $out['hero'] = ['image' => img($d['hero']['image'] ?? '')];
    $c = $d['contact'] ?? [];
    $mail = trim((string)($c['email'] ?? ''));
    $out['contact'] = [
      'phone'    => preg_replace('/[^0-9+\- ]/', '', (string)($c['phone'] ?? '')),
      'email'    => filter_var($mail, FILTER_VALIDATE_EMAIL) ? $mail : '',
      'facebook' => url(trim((string)($c['facebook'] ?? ''))),
    ];
    if (is_file($file)) copy($file, $file . '.bak');
    $json = json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (file_put_contents($file . '.tmp', $json, LOCK_EX) !== false && rename($file . '.tmp', $file)) $msg = 'Saved. The website is updated.';
    else $msg = 'Could not save. Check that data.json is writable.';
  } else $msg = 'Invalid data.';
}
$data = is_file($file) ? (json_decode(file_get_contents($file), true) ?: []) : [];
?><!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Echosfere Admin</title>
<style>
:root{--bg:#080606;--panel:#15100e;--line:#2a201b;--ember:#e8531d;--amber:#f4a63c;--ash:#ece2d6;--mute:#9b8f84;color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ash);font:16px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
.w{width:min(760px,100% - 28px);margin:0 auto;padding:20px 0 120px}
header{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
h1{margin:0;font-size:22px;letter-spacing:.08em;text-transform:uppercase}
h1 span{color:var(--ember)}
h2{margin:0 0 4px;font-size:18px;color:var(--amber)}
a{color:var(--mute)}
.card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:18px;margin-bottom:16px}
.hint{margin:0 0 12px;color:var(--mute);font-size:14px}
.row{display:grid;grid-template-columns:1fr;gap:8px;padding:12px 0;border-top:1px solid var(--line);position:relative}
.row:first-child{border-top:0}
input,select{width:100%;font:inherit;color:var(--ash);background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:11px 12px}
input:focus,select:focus{outline:none;border-color:var(--ember)}
button{font:inherit;cursor:pointer;border-radius:10px;border:1px solid var(--line);background:transparent;color:var(--ash);padding:10px 16px}
.x{justify-self:end;color:#ff7b5c;padding:6px 12px}
.add{border-color:var(--ember);color:var(--amber);margin-top:6px}
.save{position:fixed;left:0;right:0;bottom:0;padding:12px 14px calc(12px + env(safe-area-inset-bottom,0px));background:rgba(8,6,6,.94);border-top:1px solid var(--line);display:flex;justify-content:center}
.save button{background:var(--ember);border-color:var(--ember);color:#fff;font-weight:600;width:min(760px,100%);padding:14px}
.msg{padding:12px 14px;border-radius:10px;background:#2a1710;border:1px solid var(--ember);margin-bottom:16px}
form.c{max-width:380px;margin:12vh auto;display:grid;gap:12px}
.pic{display:flex;align-items:center;gap:10px}.pic img{width:56px;height:56px;object-fit:cover;border-radius:8px;border:1px solid var(--line)}.pic button{padding:8px 12px;font-size:14px}
@media(min-width:640px){.row{grid-template-columns:1fr 1fr 1fr auto;align-items:center}.row.f{grid-template-columns:1fr 1fr 1fr}.row.m{grid-template-columns:1fr 1fr 1.2fr 1fr}.row.g{grid-template-columns:auto 1fr auto}.row.h{grid-template-columns:1fr}.row.t{grid-template-columns:.7fr 1.3fr 1fr .8fr auto}}
</style></head><body><div class="w">
<?php if (!$hash): ?>
  <form class="c" method="post"><h1>Echo<span>sfere</span> Admin</h1>
    <p class="hint">First time setup. Choose an admin password (at least 8 characters).</p>
    <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>
    <input type="hidden" name="t" value="<?= h($_SESSION['t']) ?>">
    <input type="password" name="newpass" placeholder="New password" autocomplete="new-password" required>
    <button class="add">Create password</button></form>
<?php elseif (!$in): ?>
  <form class="c" method="post"><h1>Echo<span>sfere</span> Admin</h1>
    <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>
    <input type="hidden" name="t" value="<?= h($_SESSION['t']) ?>">
    <input type="password" name="pass" placeholder="Password" autocomplete="current-password" required autofocus>
    <button class="add">Log in</button></form>
<?php else: ?>
  <header><h1>Echo<span>sfere</span> Admin</h1><span><a href="./" target="_blank">View site</a> · <a href="?out=1">Log out</a></span></header>
  <?php if ($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?>
  <form method="post" id="f">
    <input type="hidden" name="t" value="<?= h($_SESSION['t']) ?>">
    <input type="hidden" name="json" value="">
    <div id="root"></div>
    <div class="card"><h2>Contact</h2><p class="hint">Shown in the Book Echosfere section.</p>
      <div class="row f"><input id="c_phone" placeholder="Phone" aria-label="Phone"><input id="c_email" placeholder="Email" aria-label="Email"><input id="c_facebook" placeholder="Facebook page link" aria-label="Facebook link"></div></div>
    <div class="save"><button type="submit">Save changes</button></div>
  </form>
  <script>
  var D = <?= json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>, T = <?= json_encode($_SESSION['t']) ?>;
  var S = [
    ['hero', 'Hero photo', 'The big photo at the top of the website. A wide (landscape) photo works best.', [['image', 'Photo', 'img']], 1, 'h'],
    ['members', 'Members', 'Upload one photo per member. If a photo is empty, the website uses a crop of the group photo. Do not reorder.', [['name', 'Name'], ['role', 'Role'], ['link', 'Facebook link'], ['photo', 'Photo', 'img']], 1, 'm'],
    ['videos', 'Videos', 'Paste the YouTube link (watch link or youtu.be link).', [['title', 'Title'], ['tag', 'Tag, e.g. Live'], ['url', 'YouTube link']], 0, ''],
    ['awards', 'Awards', 'Example: Champion, event name, year.', [['rank', 'Award'], ['event', 'Event'], ['note', 'Year / host']], 0, ''],
    ['tour', 'Tour dates', 'Upcoming shows appear first on the website.', [['when', 'Date'], ['what', 'Event'], ['where', 'Venue, city'], ['status', 'Status', 's']], 0, 't'],
    ['gallery', 'Gallery', 'Photos in the On stage section. If you add none, the website keeps its original photos.', [['src', 'Photo', 'img'], ['alt', 'Short description']], 0, 'g', 1]
  ];
  function el(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
  function shrink(file, cb) {
    var u = URL.createObjectURL(file), im = new Image();
    im.onload = function () {
      var s = Math.min(1, 1800 / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement('canvas');
      c.width = Math.round(im.naturalWidth * s); c.height = Math.round(im.naturalHeight * s);
      var x = c.getContext('2d'); x.fillStyle = '#080606'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height);
      URL.revokeObjectURL(u); c.toBlob(function (b) { cb(b || file); }, 'image/jpeg', .86);
    };
    im.onerror = function () { URL.revokeObjectURL(u); cb(file); };
    im.src = u;
  }
  function up(file, ok, fail) {
    shrink(file, function (b) {
      var fd = new FormData(); fd.append('t', T); fd.append('up', '1'); fd.append('f', b, 'photo.jpg');
      fetch('admin.php', { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); })
        .then(function (j) { if (j.ok) ok(j.path); else { alert(j.err || 'Upload failed'); fail(); } })
        .catch(function () { alert('Upload failed. Check your connection and try again.'); fail(); });
    });
  }
  function pic(k, v) {
    var w = el('div', 'pic'), im = el('img'), hid = el('input'), b = el('button', null, 'Change photo'), fi = el('input');
    hid.type = 'hidden'; hid.dataset.k = k[0]; hid.value = v[k[0]] || '';
    im.alt = ''; if (hid.value) im.src = hid.value; else im.style.display = 'none';
    b.type = 'button'; fi.type = 'file'; fi.accept = 'image/*'; fi.hidden = true;
    b.onclick = function () { fi.click(); };
    fi.onchange = function () {
      if (!fi.files[0]) return;
      b.textContent = 'Uploading...';
      up(fi.files[0], function (p) { hid.value = p; im.src = p + '?' + Date.now(); im.style.display = ''; b.textContent = 'Change photo'; }, function () { b.textContent = 'Change photo'; });
    };
    w.appendChild(im); w.appendChild(b); w.appendChild(fi); w.appendChild(hid);
    return w;
  }
  function row(f, v, fixed, cls) {
    var r = el('div', 'row ' + cls);
    f.forEach(function (k) {
      var i;
      if (k[2] === 'img') { r.appendChild(pic(k, v)); return; }
      if (k[2] === 's') { i = el('select'); ['upcoming', 'past'].forEach(function (o) { var p = el('option', null, o); p.value = o; i.appendChild(p); }); i.value = v[k[0]] || 'upcoming'; }
      else { i = el('input'); i.value = v[k[0]] || ''; }
      i.placeholder = k[1]; i.setAttribute('aria-label', k[1]); i.dataset.k = k[0]; r.appendChild(i);
    });
    if (!fixed) { var b = el('button', 'x', 'Remove'); b.type = 'button'; b.onclick = function () { r.remove(); }; r.appendChild(b); }
    return r;
  }
  var root = document.getElementById('root');
  S.forEach(function (s) {
    var sec = el('section', 'card'); sec.appendChild(el('h2', null, s[1])); sec.appendChild(el('p', 'hint', s[2]));
    var box = el('div'); box.id = 'b_' + s[0];
    var list = s[0] === 'hero' ? [D.hero || {}] : (D[s[0]] || []);
    list.forEach(function (v) { box.appendChild(row(s[3], v, s[4], s[5])); });
    sec.appendChild(box);
    if (s[6]) {
      var mb = el('button', 'add', '+ Add photos'), mf = el('input');
      mb.type = 'button'; mf.type = 'file'; mf.accept = 'image/*'; mf.multiple = true; mf.hidden = true;
      mb.onclick = function () { mf.click(); };
      mf.onchange = function () {
        var fs = [].slice.call(mf.files); mb.textContent = 'Uploading...';
        (function nx() {
          var f = fs.shift();
          if (!f) { mb.textContent = '+ Add photos'; mf.value = ''; return; }
          up(f, function (p) { box.appendChild(row(s[3], { src: p }, 0, 'g')); nx(); }, nx);
        })();
      };
      sec.appendChild(mb); sec.appendChild(mf);
    } else if (!s[4]) {
      var a = el('button', 'add', '+ Add'); a.type = 'button';
      a.onclick = function () { box.appendChild(row(s[3], {}, 0, s[5])); }; sec.appendChild(a);
    }
    root.appendChild(sec);
  });
  var C = D.contact || {};
  ['phone', 'email', 'facebook'].forEach(function (k) { document.getElementById('c_' + k).value = C[k] || ''; });
  document.getElementById('f').onsubmit = function () {
    var o = {};
    S.forEach(function (s) {
      o[s[0]] = [].map.call(document.querySelectorAll('#b_' + s[0] + ' .row'), function (r) {
        var x = {}; [].forEach.call(r.querySelectorAll('[data-k]'), function (i) { x[i.dataset.k] = i.value; }); return x;
      });
    });
    o.hero = o.hero[0] || {};
    o.contact = { phone: c_phone.value, email: c_email.value, facebook: c_facebook.value };
    this.json.value = JSON.stringify(o);
  };
  </script>
<?php endif; ?>
</div></body></html>
