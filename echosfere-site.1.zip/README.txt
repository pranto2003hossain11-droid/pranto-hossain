ECHOSFERE WEBSITE: UPLOAD GUIDE

1. cPanel > File Manager > public_html. Upload echosfere-site.zip and Extract it
   (index.html, admin.php, data.json, .htaccess must sit directly in public_html).
2. Open yourdomain.com/admin.php RIGHT AWAY and create the admin password.
3. Log in and edit: hero photo, member photos, videos, awards, tour, gallery, contact. Press Save changes.
4. Photos are uploaded to the "uploads" folder (created automatically).
5. If saving or uploading fails: File Manager > set data.json to 644/664 and the main folder to 755.

data.json.bak is the previous saved version.
